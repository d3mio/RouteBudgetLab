#include "rbl_resumable_engine.hpp"
#include "rbl_constraint_validator.hpp"

#include <iostream>
#include <cassert>
#include <algorithm>
#include <unordered_set>

namespace rbl {

// Local deterministic node structure for cooperative Space-Time A*
struct RBL_AStarNode : public LLNode {
    typedef boost::heap::pairing_heap<RBL_AStarNode*, boost::heap::compare<LLNode::secondary_compare_node>>::handle_type focal_handle_t;
    focal_handle_t focal_handle;

    RBL_AStarNode() : LLNode() {}
    RBL_AStarNode(const RBL_AStarNode& other) : LLNode(other) {}
    RBL_AStarNode(int loc, int g, int h, LLNode* p, int t, int conflicts)
        : LLNode(loc, g, h, p, t, conflicts) {}
    ~RBL_AStarNode() = default;

    struct Hasher {
        size_t operator()(const RBL_AStarNode* n) const {
            size_t loc_h = std::hash<int>()(n->location);
            size_t t_h = std::hash<int>()(n->timestep);
            return (loc_h ^ (t_h << 1));
        }
    };

    struct Equal {
        bool operator()(const RBL_AStarNode* s1, const RBL_AStarNode* s2) const {
            return (s1 == s2) || (s1 && s2 &&
                                  s1->location == s2->location &&
                                  s1->timestep == s2->timestep &&
                                  s1->wait_at_goal == s2->wait_at_goal &&
                                  s1->is_goal == s2->is_goal);
        }
    };
};

ResumableRepairEngine::ResumableRepairEngine(const Instance& instance, bool use_sipp, int checkpoint_capacity)
    : instance(instance), use_sipp(use_sipp), num_agents(instance.getDefaultNumberOfAgents()),
      path_table(instance.map_size), checkpoint_store(checkpoint_capacity) {
    // Instantiate single agent solvers
    single_agent_solvers.resize(num_agents, nullptr);
    for (int i = 0; i < num_agents; ++i) {
        if (use_sipp) {
            single_agent_solvers[i] = new SIPP(instance, i);
        } else {
            single_agent_solvers[i] = new SpaceTimeAStar(instance, i);
        }
    }
}

ResumableRepairEngine::~ResumableRepairEngine() {
    for (auto* s : single_agent_solvers) delete s;
    single_agent_solvers.clear();
}

void ResumableRepairEngine::setInitialSolution(const std::vector<Path>& initial_paths) {
    assert((int)initial_paths.size() == num_agents);
    incumbent_paths = initial_paths;
    path_table.reset();
    incumbent_sum_of_costs = 0;
    for (int i = 0; i < num_agents; ++i) {
        path_table.insertPath(i, incumbent_paths[i]);
        incumbent_sum_of_costs += (int)incumbent_paths[i].size() - 1;
    }
    incumbent_version = 1;
    agent_trajectory_versions.assign(num_agents, 1);
    checkpoint_store.clear();
}

int ResumableRepairEngine::computeCost(const std::vector<Path>& paths) {
    int cost = 0;
    for (const auto& p : paths) {
        cost += std::max(0, (int)p.size() - 1);
    }
    return cost;
}

bool ResumableRepairEngine::validateIncumbent(std::string& error_msg) const {
    if ((int)incumbent_paths.size() != num_agents) {
        error_msg = "Incumbent path count does not match agent count";
        return false;
    }
    int max_t = 0;
    for (const auto& p : incumbent_paths) {
        if (p.empty()) {
            error_msg = "Incumbent contains empty path";
            return false;
        }
        max_t = std::max(max_t, (int)p.size());
    }

    // Check vertex & edge collisions at each timestep
    for (int t = 0; t < max_t; ++t) {
        for (int i = 0; i < num_agents; ++i) {
            int loc_i = (t < (int)incumbent_paths[i].size()) ? incumbent_paths[i][t].location : incumbent_paths[i].back().location;
            int next_i = (t + 1 < (int)incumbent_paths[i].size()) ? incumbent_paths[i][t + 1].location : incumbent_paths[i].back().location;

            for (int j = i + 1; j < num_agents; ++j) {
                int loc_j = (t < (int)incumbent_paths[j].size()) ? incumbent_paths[j][t].location : incumbent_paths[j].back().location;
                int next_j = (t + 1 < (int)incumbent_paths[j].size()) ? incumbent_paths[j][t + 1].location : incumbent_paths[j].back().location;

                if (loc_i == loc_j) {
                    error_msg = "Vertex collision at t=" + std::to_string(t) + " between agent " + std::to_string(i) + " and " + std::to_string(j);
                    return false;
                }
                if (loc_i == next_j && next_i == loc_j && loc_i != next_i) {
                    error_msg = "Edge collision at t=" + std::to_string(t) + "->" + std::to_string(t+1) + " between agent " + std::to_string(i) + " and " + std::to_string(j);
                    return false;
                }
            }
        }
    }
    return true;
}

void ResumableRepairEngine::resetStats() {
    total_accepted_repairs = 0;
    total_non_improving_repairs = 0;
    total_failed_repairs = 0;
    total_interrupted_slices = 0;
    total_expansions = 0;
    total_repeated_expansions = 0;
}

// Low-level Space-Time A* search with cooperative budget checking and deterministic tie-breaking
Path ResumableRepairEngine::findPathWithBudget(int agent_id,
                                              const ConstraintTable& constraint_table,
                                              SearchBudget& budget,
                                              unsigned int rng_seed) {
    SingleAgentSolver* planner = single_agent_solvers[agent_id];
    planner->reset();
    Path path;

    // Check if start location is occupied at t=0 without triggering upstream PathTable buffer overflow at t=0
    if (path_table.table[planner->start_location].size() > 0 &&
        path_table.table[planner->start_location][0] != NO_AGENT) {
        return path;
    }

    // Deterministic tie-breaking RNG seed
    if (rng_seed != 0) {
        srand(rng_seed);
    }

    auto holding_time = constraint_table.getHoldingTime(planner->goal_location, constraint_table.length_min);
    auto static_timestep = constraint_table.getMaxTimestep() + 1;
    auto last_target_collision_time = constraint_table.getLastCollisionTimestep(planner->goal_location);

    auto h = std::max(std::max(planner->my_heuristic[planner->start_location], holding_time),
                      last_target_collision_time + 1);

    auto* start = new RBL_AStarNode(planner->start_location, 0, h, nullptr, 0, 0);
    start->in_openlist = true;

    boost::heap::pairing_heap<RBL_AStarNode*, boost::heap::compare<LLNode::secondary_compare_node>> focal_list;
    std::unordered_set<RBL_AStarNode*, RBL_AStarNode::Hasher, RBL_AStarNode::Equal> allNodes_table;

    start->focal_handle = focal_list.push(start);
    allNodes_table.insert(start);

    auto cleanup = [&]() {
        for (auto* n : allNodes_table) delete n;
        allNodes_table.clear();
        focal_list.clear();
    };

    while (!focal_list.empty()) {
        // COOPERATIVE INTERRUPTION CHECK INSIDE LOW-LEVEL SEARCH
        if (!budget.checkNodeExpansion()) {
            total_expansions += budget.current_expansions;
            cleanup();
            return {}; // cleanly aborted mid-search
        }

        auto* curr = focal_list.top();
        focal_list.pop();
        curr->in_openlist = false;

        auto updatePath = [&](const LLNode* goal_node) {
            const LLNode* p = goal_node;
            if (p->is_goal)
                p = p->parent;
            path.clear();
            path.reserve(p->g_val + 1);
            while (p != nullptr) {
                path.emplace_back(p->location);
                p = p->parent;
            }
            std::reverse(path.begin(), path.end());
        };

        if (curr->is_goal) {
            updatePath(curr);
            break;
        } else if (curr->location == planner->goal_location &&
                   !curr->wait_at_goal &&
                   curr->timestep >= holding_time) {
            int future_collisions = constraint_table.getFutureNumOfCollisions(curr->location, curr->timestep);
            if (future_collisions == 0) {
                updatePath(curr);
                break;
            }
            auto goal = new RBL_AStarNode(*curr);
            goal->is_goal = true;
            goal->parent = curr;
            goal->num_of_conflicts += future_collisions;
            goal->h_val = 0;

            auto it = allNodes_table.find(goal);
            if (it == allNodes_table.end()) {
                goal->focal_handle = focal_list.push(goal);
                goal->in_openlist = true;
                allNodes_table.insert(goal);
            } else {
                auto existing = *it;
                if (existing->num_of_conflicts > goal->num_of_conflicts ||
                    (existing->num_of_conflicts == goal->num_of_conflicts && existing->getFVal() > goal->getFVal())) {
                    assert(existing->in_openlist);
                    existing->copy(*goal);
                    focal_list.update(existing->focal_handle);
                }
                delete goal;
            }
        }

        if (curr->timestep >= constraint_table.length_max)
            continue;

        auto next_locations = instance.getNeighbors(curr->location);
        next_locations.emplace_back(curr->location);

        for (int next_loc : next_locations) {
            int next_timestep = curr->timestep + 1;
            if (static_timestep < next_timestep) {
                if (next_loc == curr->location) continue;
                next_timestep--;
            }

            if (constraint_table.constrained(next_loc, next_timestep) ||
                constraint_table.constrained(curr->location, next_loc, next_timestep)) {
                continue;
            }

            int next_g = curr->g_val + 1;
            int next_h = planner->my_heuristic[next_loc];
            if (next_g + next_h > constraint_table.length_max) continue;

            int num_conflicts = curr->num_of_conflicts +
                                constraint_table.getNumOfConflictsForStep(curr->location, next_loc, next_timestep);
            if (num_conflicts == 0) {
                next_h = std::max(next_h, curr->getFVal() - next_g);
            } else {
                next_h = std::max(next_h, holding_time - next_g);
            }

            auto next = new RBL_AStarNode(next_loc, next_g, next_h, curr, next_timestep, num_conflicts);
            if (next_loc == planner->goal_location && curr->location == planner->goal_location) {
                next->wait_at_goal = true;
            }

            auto it = allNodes_table.find(next);
            if (it == allNodes_table.end()) {
                next->focal_handle = focal_list.push(next);
                next->in_openlist = true;
                allNodes_table.insert(next);
            } else {
                auto existing = *it;
                if (existing->num_of_conflicts > next->num_of_conflicts ||
                    (existing->num_of_conflicts == next->num_of_conflicts && existing->getFVal() > next->getFVal())) {
                    if (!existing->in_openlist) {
                        existing->copy(*next);
                        existing->focal_handle = focal_list.push(existing);
                        existing->in_openlist = true;
                    } else {
                        existing->copy(*next);
                        focal_list.update(existing->focal_handle);
                    }
                }
                delete next;
            }
        }
    }

    cleanup();
    total_expansions += budget.current_expansions;
    return path;
}

RepairOutcome ResumableRepairEngine::attemptFreshRepair(const std::vector<int>& neighborhood,
                                                        SearchBudget& budget,
                                                        unsigned int rng_seed) {
    RepairOutcome outcome;
    outcome.neighborhood_size = (int)neighborhood.size();

    // Check global deadline before starting
    if (budget.deadline_exceeded || budget.isGlobalDeadlineExceeded() || budget.getElapsedSeconds() >= budget.max_time_seconds) {
        outcome.type = RepairOutcomeType::STOPPED_DEADLINE;
        return outcome;
    }

    // 1. Transaction Isolation: Extract old incumbent paths
    std::vector<Path> old_paths(neighborhood.size());
    int old_cost = 0;
    for (size_t i = 0; i < neighborhood.size(); ++i) {
        int a = neighborhood[i];
        old_paths[i] = incumbent_paths[a];
        path_table.deletePath(a, incumbent_paths[a]);
        old_cost += (int)incumbent_paths[a].size() - 1;
    }
    outcome.old_cost = old_cost;

    // 2. Setup priority permutation
    std::vector<int> priority_order = neighborhood;
    if (rng_seed != 0) {
        std::mt19937 g(rng_seed);
        std::shuffle(priority_order.begin(), priority_order.end(), g);
    }

    std::vector<Path> prefix_paths;
    prefix_paths.reserve(priority_order.size());

    int r_done = 0;
    ConstraintTable constraint_table(instance.num_of_cols, instance.map_size, &path_table);

    // Rollback helper on failure / non-improvement / interruption
    auto rollback = [&]() {
        // Delete candidate prefix paths from table
        for (int i = 0; i < r_done; ++i) {
            path_table.deletePath(priority_order[i], prefix_paths[i]);
        }
        // Reinsert old incumbent paths
        for (size_t i = 0; i < neighborhood.size(); ++i) {
            path_table.insertPath(neighborhood[i], old_paths[i]);
        }
    };

    auto t_start = std::chrono::steady_clock::now();

    while (r_done < (int)priority_order.size()) {
        // Cooperative check at agent boundary
        if (!budget.checkAgentBoundary()) {
            break;
        }

        int agent_id = priority_order[r_done];
        unsigned int agent_seed = rng_seed + r_done * 10007;

        uint64_t exp_before = budget.current_expansions;
        Path path = findPathWithBudget(agent_id, constraint_table, budget, agent_seed);

        if (budget.interrupted) {
            // Cutoff reached inside single-agent search
            outcome.interruption.current_agent_expansions = budget.current_expansions - exp_before;
            break;
        }

        if (path.empty()) {
            // Search failed to find a path
            rollback();
            outcome.type = RepairOutcomeType::FAILED_NO_PATH;
            total_failed_repairs++;
            return outcome;
        }

        prefix_paths.push_back(path);
        path_table.insertPath(agent_id, path);
        r_done++;

        // Pruning check: if accumulated prefix cost already >= old_cost, cannot improve
        if (computeCost(prefix_paths) >= old_cost) {
            rollback();
            outcome.type = RepairOutcomeType::COMPLETED_NOT_IMPROVING;
            total_non_improving_repairs++;
            return outcome;
        }
    }

    auto t_end = std::chrono::steady_clock::now();
    outcome.duration_s = std::chrono::duration<double>(t_end - t_start).count();
    outcome.total_expansions = budget.current_expansions;

    // Check if interrupted by slice cutoff
    if (budget.interrupted || r_done < (int)priority_order.size()) {
        outcome.type = RepairOutcomeType::INTERRUPTED_SLICE;
        outcome.interruption.neighborhood_size = (int)priority_order.size();
        outcome.interruption.completed_prefix_len = r_done;
        outcome.interruption.unfinished_agent_id = (r_done < (int)priority_order.size()) ? priority_order[r_done] : -1;
        outcome.interruption.has_reusable_prefix = (r_done > 0);

        // Macro-prefix contract:
        // Assemble checkpoint C_i
        MacroPrefixCheckpoint cp;
        cp.checkpoint_id = next_checkpoint_id++;
        cp.lifecycle = CheckpointLifecycle::ACTIVE;
        cp.neighborhood_agents = neighborhood;
        cp.priority_order = priority_order;
        cp.r_done = r_done;
        cp.prefix_paths = prefix_paths;
        cp.old_paths = old_paths;
        cp.old_neighborhood_cost = old_cost;
        cp.prefix_accumulated_cost = computeCost(prefix_paths);
        cp.incumbent_version = incumbent_version;
        cp.incumbent_sum_of_costs = incumbent_sum_of_costs;
        cp.agent_versions_at_save = agent_trajectory_versions;
        cp.rng_seed_at_unfinished_agent = rng_seed + r_done * 10007;
        cp.accumulated_active_time_s = outcome.duration_s;
        outcome.repeated_expansions = outcome.interruption.current_agent_expansions;
        cp.repeated_expansions = outcome.interruption.current_agent_expansions;
        total_repeated_expansions += outcome.repeated_expansions;

        // Rollback candidate paths from path_table so incumbent is untouched
        rollback();

        if (budget.isGlobalDeadlineExceeded()) {
            outcome.type = RepairOutcomeType::STOPPED_DEADLINE;
            return outcome;
        }

        // Save into bounded checkpoint store (K in {0, 1, 2})
        checkpoint_store.saveCheckpoint(cp);
        total_interrupted_slices++;
        return outcome;
    }

    // All agents in neighborhood routed!
    int new_cost = computeCost(prefix_paths);
    outcome.new_cost = new_cost;
    outcome.cost_delta = new_cost - old_cost;

    last_completed_candidate = incumbent_paths;
    for (size_t i = 0; i < priority_order.size(); ++i)
        last_completed_candidate[priority_order[i]] = prefix_paths[i];

    if (new_cost < old_cost) {
        if (!planIsCollisionFree(last_completed_candidate)) {
            rollback();
            outcome.type = RepairOutcomeType::REJECTED_INVALID;
            total_failed_repairs++;
            return outcome;
        }
        if (budget.isGlobalDeadlineExceeded()) {
            rollback();
            outcome.type = RepairOutcomeType::REJECTED_LATE_COMMIT;
            return outcome;
        }
        // Accept and commit to incumbent!
        for (size_t i = 0; i < priority_order.size(); ++i) {
            int a = priority_order[i];
            incumbent_paths[a] = prefix_paths[i];
            agent_trajectory_versions[a]++;
        }
        incumbent_sum_of_costs += outcome.cost_delta;
        incumbent_version++;
        outcome.type = RepairOutcomeType::COMPLETED_ACCEPTED;
        total_accepted_repairs++;
    } else {
        rollback();
        outcome.type = RepairOutcomeType::COMPLETED_NOT_IMPROVING;
        total_non_improving_repairs++;
    }

    return outcome;
}

bool ResumableRepairEngine::planIsCollisionFree(const std::vector<Path>& plan) const {
    // Hash-per-timestep vertex/edge-swap check with stay-at-goal semantics (O(T * |A|)).
    int max_len = 0;
    for (const auto& p : plan) {
        if (p.empty()) return false;
        max_len = std::max(max_len, (int)p.size());
    }
    auto pos = [&](int a, int t) {
        const Path& p = plan[a];
        return p[std::min<size_t>((size_t)t, p.size() - 1)].location;
    };
    std::unordered_map<int, int> occ;
    occ.reserve(plan.size() * 2);
    for (int t = 0; t < max_len; ++t) {
        occ.clear();
        for (int a = 0; a < (int)plan.size(); ++a) {
            if (!occ.emplace(pos(a, t), a).second) return false;   // vertex conflict
        }
        if (t + 1 < max_len) {
            for (int a = 0; a < (int)plan.size(); ++a) {
                int u = pos(a, t), v = pos(a, t + 1);
                if (u == v) continue;
                auto it = occ.find(v);                              // who was at v at time t?
                if (it != occ.end() && it->second != a && pos(it->second, t + 1) == u) return false; // swap
            }
        }
    }
    return true;
}

bool ResumableRepairEngine::commitExternalTrajectory(int agent_id, const Path& new_path, bool allow_worsening) {
    if (agent_id < 0 || agent_id >= num_agents || new_path.empty()) return false;
    if (new_path.front().location != instance.getStarts()[agent_id]) return false;
    if (new_path.back().location != instance.getGoals()[agent_id]) return false;

    // Check grid-step validity (no obstacles, valid moves)
    for (size_t t = 0; t < new_path.size(); ++t) {
        int loc = new_path[t].location;
        if (loc < 0 || loc >= instance.map_size || instance.isObstacle(loc)) return false;
        if (t + 1 < new_path.size()) {
            int next_loc = new_path[t + 1].location;
            if (!instance.validMove(loc, next_loc)) return false;
        }
    }

    int old_c = std::max(0, (int)incumbent_paths[agent_id].size() - 1);
    int new_c = std::max(0, (int)new_path.size() - 1);
    if (!allow_worsening && new_c >= old_c) {
        return false; // Reject worsening paths in production/enforced mode
    }

    // Verify candidate whole plan is collision-free
    std::vector<Path> cand = incumbent_paths;
    cand[agent_id] = new_path;
    if (!planIsCollisionFree(cand)) return false;

    // Apply update to path_table and incumbent state
    path_table.deletePath(agent_id, incumbent_paths[agent_id]);
    path_table.insertPath(agent_id, new_path);

    incumbent_sum_of_costs += (new_c - old_c);

    incumbent_paths[agent_id] = new_path;
    agent_trajectory_versions[agent_id]++;
    incumbent_version++;
    return true;
}

CompatibilityReport ResumableRepairEngine::validateCheckpoint(int slot_idx, bool selective_retention) const {
    const MacroPrefixCheckpoint* cp = checkpoint_store.getCheckpoint(slot_idx);
    if (!cp) {
        CompatibilityReport rep;
        rep.detail = "No checkpoint in slot";
        return rep;
    }
    return ConservativeConstraintValidator::validate(
        *cp, incumbent_paths, agent_trajectory_versions, incumbent_version, selective_retention);
}

RepairOutcome ResumableRepairEngine::resumeCheckpoint(int slot_idx, SearchBudget& budget, bool selective_retention) {
    RepairOutcome outcome;

    // Check global deadline before resuming
    if (budget.deadline_exceeded || budget.isGlobalDeadlineExceeded() || budget.getElapsedSeconds() >= budget.max_time_seconds) {
        outcome.type = RepairOutcomeType::STOPPED_DEADLINE;
        return outcome;
    }

    MacroPrefixCheckpoint* cp = checkpoint_store.getCheckpoint(slot_idx);
    if (!cp) {
        outcome.type = RepairOutcomeType::FAILED_NO_PATH;
        return outcome;
    }

    // Conservative constraint compatibility validation (Phase 4: Component 2)
    CompatibilityReport rep = ConservativeConstraintValidator::validate(
        *cp, incumbent_paths, agent_trajectory_versions, incumbent_version, selective_retention);
    last_compat_report = rep;

    if (!rep.isCompatible()) {
        checkpoint_store.markDiscarded(slot_idx);
        outcome.type = RepairOutcomeType::DISCARDED_INCOMPATIBLE;
        return outcome;
    }

    auto t0 = std::chrono::steady_clock::now();

    outcome.neighborhood_size = (int)cp->priority_order.size();
    outcome.repeated_expansions = cp->repeated_expansions;

    std::vector<int> neighborhood = cp->neighborhood_agents;
    std::vector<int> priority_order = cp->priority_order;
    std::vector<Path> old_paths = cp->old_paths;
    std::vector<Path> prefix_paths = cp->prefix_paths;
    int r_done = cp->r_done;
    uint32_t agent_seed = cp->rng_seed_at_unfinished_agent;

    // Calculate CURRENT cost of the neighbourhood in the incumbent (acceptance baseline)
    int current_neighborhood_cost = 0;
    for (int a : neighborhood) {
        current_neighborhood_cost += std::max(0, (int)incumbent_paths[a].size() - 1);
    }
    outcome.old_cost = current_neighborhood_cost;

    // Remove old paths of neighborhood from path_table
    for (size_t i = 0; i < neighborhood.size(); ++i) {
        path_table.deletePath(neighborhood[i], incumbent_paths[neighborhood[i]]);
    }

    // Rebuild reservations from saved prefix paths P_{1..r_done}
    for (int i = 0; i < r_done; ++i) {
        path_table.insertPath(priority_order[i], prefix_paths[i]);
    }

    auto t1 = std::chrono::steady_clock::now();
    double restore_us = std::chrono::duration<double, std::micro>(t1 - t0).count();
    cp->restore_time_us = restore_us;

    ConstraintTable constraint_table(instance.num_of_cols, instance.map_size, &path_table);

    auto rollback = [&]() {
        for (size_t i = 0; i < prefix_paths.size(); ++i) {
            path_table.deletePath(priority_order[i], prefix_paths[i]);
        }
        for (size_t i = 0; i < neighborhood.size(); ++i) {
            path_table.insertPath(neighborhood[i], incumbent_paths[neighborhood[i]]);
        }
    };

    while (r_done < (int)priority_order.size()) {
        if (!budget.checkAgentBoundary()) {
            break;
        }

        int agent_id = priority_order[r_done];
        uint64_t exp_before = budget.current_expansions;
        Path path = findPathWithBudget(agent_id, constraint_table, budget, agent_seed);

        if (budget.interrupted) {
            outcome.interruption.current_agent_expansions = budget.current_expansions - exp_before;
            break;
        }

        if (path.empty()) {
            rollback();
            checkpoint_store.markDiscarded(slot_idx);
            outcome.type = RepairOutcomeType::FAILED_NO_PATH;
            total_failed_repairs++;
            return outcome;
        }

        prefix_paths.push_back(path);
        path_table.insertPath(agent_id, path);
        r_done++;
        agent_seed += 10007;

        if (computeCost(prefix_paths) >= current_neighborhood_cost) {
            rollback();
            checkpoint_store.markDiscarded(slot_idx);
            outcome.type = RepairOutcomeType::COMPLETED_NOT_IMPROVING;
            total_non_improving_repairs++;
            return outcome;
        }
    }

    auto t_end = std::chrono::steady_clock::now();
    outcome.duration_s = std::chrono::duration<double>(t_end - t0).count();
    outcome.total_expansions = budget.current_expansions;

    if (budget.interrupted || r_done < (int)priority_order.size()) {
        outcome.type = RepairOutcomeType::INTERRUPTED_SLICE;
        outcome.interruption.neighborhood_size = (int)priority_order.size();
        outcome.interruption.completed_prefix_len = r_done;
        outcome.interruption.unfinished_agent_id = (r_done < (int)priority_order.size()) ? priority_order[r_done] : -1;
        outcome.interruption.has_reusable_prefix = (r_done > 0);

        // Update checkpoint
        if (r_done == cp->r_done) {
            cp->consecutive_stagnant_attempts++;
        } else {
            cp->consecutive_stagnant_attempts = 0;
        }
        cp->r_done = r_done;
        cp->prefix_paths = prefix_paths;
        cp->prefix_accumulated_cost = computeCost(prefix_paths);
        cp->rng_seed_at_unfinished_agent = agent_seed;
        cp->accumulated_active_time_s += outcome.duration_s;
        outcome.repeated_expansions = outcome.interruption.current_agent_expansions;
        cp->repeated_expansions += outcome.interruption.current_agent_expansions;
        total_repeated_expansions += outcome.repeated_expansions;

        rollback();
        if (budget.isGlobalDeadlineExceeded()) {
            checkpoint_store.markExpired(slot_idx);
            outcome.type = RepairOutcomeType::STOPPED_DEADLINE;
            return outcome;
        }
        total_interrupted_slices++;
        return outcome;
    }

    // All agents finished!
    int new_cost = computeCost(prefix_paths);
    outcome.new_cost = new_cost;
    outcome.cost_delta = new_cost - current_neighborhood_cost;

    if (outcome.cost_delta < 0) {
        // Independent final-path validation before commitment
        std::vector<Path> candidate_paths = incumbent_paths;
        for (size_t i = 0; i < priority_order.size(); ++i) {
            candidate_paths[priority_order[i]] = prefix_paths[i];
        }

        bool valid = true;
        int max_len = 0;
        for (const auto& p : candidate_paths) max_len = std::max(max_len, (int)p.size());
        for (int t = 0; t < max_len && valid; ++t) {
            for (int a1 = 0; a1 < num_agents && valid; ++a1) {
                int loc1 = (t < (int)candidate_paths[a1].size()) ? candidate_paths[a1][t].location : candidate_paths[a1].back().location;
                for (int a2 = a1 + 1; a2 < num_agents; ++a2) {
                    int loc2 = (t < (int)candidate_paths[a2].size()) ? candidate_paths[a2][t].location : candidate_paths[a2].back().location;
                    if (loc1 == loc2) { valid = false; break; }
                    if (t + 1 < max_len) {
                        int next1 = (t + 1 < (int)candidate_paths[a1].size()) ? candidate_paths[a1][t + 1].location : candidate_paths[a1].back().location;
                        int next2 = (t + 1 < (int)candidate_paths[a2].size()) ? candidate_paths[a2][t + 1].location : candidate_paths[a2].back().location;
                        if (loc1 == next2 && next1 == loc2 && loc1 != next1) { valid = false; break; }
                    }
                }
            }
        }

        if (valid) {
            if (budget.isGlobalDeadlineExceeded()) {
                checkpoint_store.markExpired(slot_idx);
                outcome.type = RepairOutcomeType::REJECTED_LATE_COMMIT;
                return outcome;
            }
            for (size_t i = 0; i < priority_order.size(); ++i) {
                int a = priority_order[i];
                incumbent_paths[a] = prefix_paths[i];
                agent_trajectory_versions[a]++;
            }
            incumbent_sum_of_costs += outcome.cost_delta;
            incumbent_version++;
            checkpoint_store.markCommitted(slot_idx);
            outcome.type = RepairOutcomeType::COMPLETED_ACCEPTED;
            total_accepted_repairs++;
        } else {
            rollback();
            checkpoint_store.markDiscarded(slot_idx);
            outcome.type = RepairOutcomeType::FAILED_NO_PATH;
            total_failed_repairs++;
        }
    } else {
        rollback();
        checkpoint_store.markDiscarded(slot_idx);
        outcome.type = RepairOutcomeType::COMPLETED_NOT_IMPROVING;
        total_non_improving_repairs++;
    }

    return outcome;
}

} // namespace rbl
