#pragma once
// RouteBudget Lab - Cooperative Search Budget & Outcome Tracking (O1, WP1, FR-02)
//
// Provides:
// 1. SearchBudget: Cooperative interruption accounting inside low-level search and between agents.
// 2. RepairOutcome: Five distinct, mutually-exclusive repair outcomes:
//    - COMPLETED_ACCEPTED
//    - COMPLETED_NOT_IMPROVING
//    - FAILED_NO_PATH
//    - INTERRUPTED_SLICE (with prefix metrics: |N|, r_done, current-agent work, reusable prefix boolean)
//    - STOPPED_DEADLINE

#include <chrono>
#include <cstdint>
#include <string>

namespace rbl {

enum class RepairOutcomeType {
    COMPLETED_ACCEPTED,      // All agents routed; sum of costs strictly improved
    COMPLETED_NOT_IMPROVING, // All agents routed or cost-pruned; cost >= old_cost
    FAILED_NO_PATH,          // Search failed to find a feasible path for an agent
    INTERRUPTED_SLICE,       // Active slice budget expired during repair
    STOPPED_DEADLINE,        // Global solver deadline expired
    DISCARDED_INCOMPATIBLE,  // Resume refused: checkpoint failed the compatibility validator (Phase 4)
    REJECTED_INVALID,        // Completed candidate failed final whole-plan validation; not committed
    REJECTED_LATE_COMMIT     // Validation finished after global deadline; commit rejected to preserve deadline
};

inline const char* toString(RepairOutcomeType o) {
    switch (o) {
        case RepairOutcomeType::COMPLETED_ACCEPTED: return "COMPLETED_ACCEPTED";
        case RepairOutcomeType::COMPLETED_NOT_IMPROVING: return "COMPLETED_NOT_IMPROVING";
        case RepairOutcomeType::FAILED_NO_PATH: return "FAILED_NO_PATH";
        case RepairOutcomeType::INTERRUPTED_SLICE: return "INTERRUPTED_SLICE";
        case RepairOutcomeType::STOPPED_DEADLINE: return "STOPPED_DEADLINE";
        case RepairOutcomeType::DISCARDED_INCOMPATIBLE: return "DISCARDED_INCOMPATIBLE";
        case RepairOutcomeType::REJECTED_INVALID: return "REJECTED_INVALID";
        case RepairOutcomeType::REJECTED_LATE_COMMIT: return "REJECTED_LATE_COMMIT";
        default: return "UNKNOWN";
    }
}

inline std::ostream& operator<<(std::ostream& os, RepairOutcomeType o) {
    return os << toString(o);
}

struct InterruptionRecord {
    int neighborhood_size = 0;
    int completed_prefix_len = 0; // r_done
    int unfinished_agent_id = -1;
    uint64_t current_agent_expansions = 0;
    double current_agent_time_s = 0.0;
    bool has_reusable_prefix = false; // true if r_done > 0
};

struct RepairOutcome {
    RepairOutcomeType type = RepairOutcomeType::FAILED_NO_PATH;
    int neighborhood_size = 0;
    int old_cost = 0;
    int new_cost = 0;
    int cost_delta = 0; // new_cost - old_cost (negative is improvement)
    double duration_s = 0.0;
    uint64_t total_expansions = 0;
    uint64_t repeated_expansions = 0; // Work repeated upon restarting unfinished agents
    InterruptionRecord interruption;
};

// Cooperative Search Budget
// Supports deterministic expansion cutoffs (for E1 equivalence tests)
// and wall-clock monotonic time cutoffs (for real-time performance evaluation).
class SearchBudget {
public:
    uint64_t max_expansions = UINT64_MAX;
    double max_time_seconds = 1e9;
    std::chrono::steady_clock::time_point start_time;
    uint64_t current_expansions = 0;
    std::chrono::steady_clock::time_point global_deadline_time;
    bool has_global_deadline = false;
    bool interrupted = false;
    bool deadline_exceeded = false;

    SearchBudget() {
        start_time = std::chrono::steady_clock::now();
    }

    SearchBudget(uint64_t max_exp, double max_time_s)
        : max_expansions(max_exp), max_time_seconds(max_time_s) {
        start_time = std::chrono::steady_clock::now();
    }

    void setGlobalDeadline(std::chrono::steady_clock::time_point deadline) {
        global_deadline_time = deadline;
        has_global_deadline = true;
    }

    inline bool isGlobalDeadlineExceeded() const {
        if (!has_global_deadline) return false;
        return std::chrono::steady_clock::now() >= global_deadline_time;
    }

    void reset(uint64_t max_exp, double max_time_s) {
        max_expansions = max_exp;
        max_time_seconds = max_time_s;
        current_expansions = 0;
        interrupted = false;
        deadline_exceeded = false;
        start_time = std::chrono::steady_clock::now();
    }

    // Cooperative check called inside search loops
    // Returns true if search is allowed to proceed, false if cutoff reached.
    inline bool checkNodeExpansion() {
        current_expansions++;
        if (current_expansions > max_expansions) {
            interrupted = true;
            return false;
        }

        // Periodically check clock every 64 expansions to minimize chrono overhead
        if ((current_expansions & 63) == 0) {
            if (isGlobalDeadlineExceeded()) {
                interrupted = true;
                deadline_exceeded = true;
                return false;
            }
            if (max_time_seconds < 1e8) {
                auto now = std::chrono::steady_clock::now();
                double elapsed = std::chrono::duration<double>(now - start_time).count();
                if (elapsed >= max_time_seconds) {
                    interrupted = true;
                    return false;
                }
            }
        }
        return true;
    }

    // Explicit check between agents
    inline bool checkAgentBoundary() {
        if (current_expansions >= max_expansions) {
            interrupted = true;
            return false;
        }
        if (isGlobalDeadlineExceeded()) {
            interrupted = true;
            deadline_exceeded = true;
            return false;
        }
        if (max_time_seconds < 1e8) {
            auto now = std::chrono::steady_clock::now();
            double elapsed = std::chrono::duration<double>(now - start_time).count();
            if (elapsed >= max_time_seconds) {
                interrupted = true;
                return false;
            }
        }
        return true;
    }

    double getElapsedSeconds() const {
        auto now = std::chrono::steady_clock::now();
        return std::chrono::duration<double>(now - start_time).count();
    }
};

} // namespace rbl
