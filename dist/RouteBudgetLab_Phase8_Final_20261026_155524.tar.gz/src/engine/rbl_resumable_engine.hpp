#pragma once
// RouteBudget Lab - Resumable Repair Engine (Phase 3: Macro-Prefix Resumable Repair)
//
// Implementation of Component 1 (O2, FR-02, NFR-02, NFR-03):
// - Cooperative interruption checks inside low-level search and between agents.
// - Macro-prefix checkpointing contract:
//   * Preserves completed prefix paths P_{1..r_done}.
//   * Discards unfinished agent frontier.
//   * Preserves committed incumbent unchanged via transactional isolation.
//   * Restores prefix reservations and deterministic RNG state on resumption.
// - Bounded checkpoint storage (K in {0, 1, 2}) with explicit lifecycle states.
// - Outcome separation: COMPLETED_ACCEPTED, COMPLETED_NOT_IMPROVING, FAILED_NO_PATH,
//   INTERRUPTED_SLICE, STOPPED_DEADLINE.

#include <vector>
#include <string>
#include <memory>
#include <random>
#include <chrono>

#include "Instance.h"
#include "PathTable.h"
#include "ConstraintTable.h"
#include "SingleAgentSolver.h"
#include "SpaceTimeAStar.h"
#include "SIPP.h"

#include "rbl_checkpoint.hpp"
#include "rbl_search_budget.hpp"
#include "rbl_constraint_validator.hpp"

namespace rbl {

class ResumableRepairEngine {
public:
    ResumableRepairEngine(const Instance& instance, bool use_sipp = false, int checkpoint_capacity = 2);
    ~ResumableRepairEngine();

    // Set initial incumbent solution paths
    void setInitialSolution(const std::vector<Path>& initial_paths);

    // Incumbent solution access
    const std::vector<Path>& getIncumbentPaths() const { return incumbent_paths; }
    int getIncumbentCost() const { return incumbent_sum_of_costs; }
    uint64_t getIncumbentVersion() const { return incumbent_version; }

    // Checkpoint store access
    BoundedCheckpointStore& getCheckpointStore() { return checkpoint_store; }
    const BoundedCheckpointStore& getCheckpointStore() const { return checkpoint_store; }

    // Attempt a fresh repair on neighborhood N_i with budget
    RepairOutcome attemptFreshRepair(const std::vector<int>& neighborhood,
                                     SearchBudget& budget,
                                     unsigned int rng_seed = 0);

    // Attempt to resume a suspended checkpoint with budget
    // selective_retention: if false, uses reference Policy 0 (Discard-on-Change);
    //                      if true, uses Phase 4 two-stage conservative validation (Policy 1).
    RepairOutcome resumeCheckpoint(int slot_idx,
                                   SearchBudget& budget,
                                   bool selective_retention = false);

    // Get per-agent trajectory versions
    const std::vector<uint64_t>& getAgentVersions() const { return agent_trajectory_versions; }

    // Side-effect-free compatibility check of a stored checkpoint against the CURRENT incumbent.
    CompatibilityReport validateCheckpoint(int slot_idx, bool selective_retention) const;

    // Report produced by the most recent resumeCheckpoint() call (stage reached, verdict, latency).
    const CompatibilityReport& getLastCompatibilityReport() const { return last_compat_report; }

    // Full plan (all agents) of the most recent repair whose neighbourhood was completely routed,
    // whether or not it was accepted. Empty if no repair completed yet.
    const std::vector<Path>& getLastCompletedCandidate() const { return last_completed_candidate; }

    // Read-only reservation table (reflects the committed incumbent between repair calls).
    const PathTable& getPathTable() const { return path_table; }
    const Instance& getInstance() const { return instance; }

    // Diagnostic & Controlled Perturbation / Testing API only:
    // Directly commit a valid, collision-free trajectory for an external agent (used in E4/E8 perturbation fixtures).
    // Verifies start/goal, valid moves, and absence of collisions with current incumbent.
    // Production planner execution strictly uses attemptFreshRepair() and resumeCheckpoint(),
    // which enforce strict cost improvement (new_cost < old_cost) and candidate collision-checking before commitment.
    // If allow_worsening is false, worsening paths (new_cost >= old_cost) are rejected.
    bool commitExternalTrajectory(int agent_id, const Path& new_path, bool allow_worsening = true);

    // Validation: checks whether current incumbent paths are collision-free internally
    bool validateIncumbent(std::string& error_msg) const;

    // Reset statistics
    void resetStats();

    // Cumulative statistics
    int getAcceptedRepairs() const { return total_accepted_repairs; }
    int getNonImprovingRepairs() const { return total_non_improving_repairs; }
    int getFailedRepairs() const { return total_failed_repairs; }
    int getInterruptedSlices() const { return total_interrupted_slices; }
    uint64_t getTotalExpansions() const { return total_expansions; }
    uint64_t getRepeatedExpansions() const { return total_repeated_expansions; }
    bool isUsingSipp() const { return use_sipp; }

private:
    const Instance& instance;
    bool use_sipp = false;
    int num_agents = 0;

    // Incumbent state
    std::vector<Path> incumbent_paths;
    int incumbent_sum_of_costs = 0;
    uint64_t incumbent_version = 1;
    std::vector<uint64_t> agent_trajectory_versions;

    // Global collision and path table for incumbent
    PathTable path_table;

    // Low-level single agent solvers (one per agent)
    std::vector<SingleAgentSolver*> single_agent_solvers;

    // Bounded checkpoint store (K in {0, 1, 2})
    BoundedCheckpointStore checkpoint_store;

    // Unique checkpoint ID counter
    uint64_t next_checkpoint_id = 1;

    CompatibilityReport last_compat_report;
    std::vector<Path> last_completed_candidate;

    // Independent-of-search whole-plan collision check used before any commit.
    bool planIsCollisionFree(const std::vector<Path>& plan) const;

    // Statistics
    int total_accepted_repairs = 0;
    int total_non_improving_repairs = 0;
    int total_failed_repairs = 0;
    int total_interrupted_slices = 0;
    uint64_t total_expansions = 0;
    uint64_t total_repeated_expansions = 0;

    // Internal low-level search with budget check
    Path findPathWithBudget(int agent_id,
                            const ConstraintTable& ct,
                            SearchBudget& budget,
                            unsigned int rng_seed);

    // Helper: compute sum of costs for a vector of paths
    static int computeCost(const std::vector<Path>& paths);
};

} // namespace rbl
