# RouteBudget Lab

**RouteBudget Lab (RBL)** is an experimental research system for deadline-aware Multi-Agent Pathfinding with Large Neighborhood Search (MAPF-LNS). It investigates constraint-validated checkpoint resumption, remaining-work estimation, and overhead-aware decision-making under strict monotonic wall-clock deadlines.

---

## 1. Project Status & Evaluation Coverage

- **Current Status:** **ALL 8 PHASES COMPLETED, AUDITED, AND VERIFIED (FULL 768 RUNS & OFFLINE REPLAY VIEWER).**
- **Verified Dataset (Full 768 Runs):** 768 of 768 reference runs completed sequentially, with full final trajectories persisted to disk, independently validated as collision-free with exact cost matches, and cryptographically recorded via SHA-256 hashes (`results/phase7/verified_reference/`).
- **Full Reference Design (768 runs):** 4 maps $\times$ 3 scenarios $\times$ 2 agent counts $\times$ 4 budgets $\times$ 8 method/protocol combinations. 100% completed and independently validated.
- **Phase 8 Replay Viewer:** Fully operational offline 2D HTML5 Canvas interactive inspector for all 768 verified trajectories with zero external CDN dependencies.
- **Academic Demarcation:** Implementation, experimental evaluation, automated verification, and reproducible packaging are complete. Dissertation writing, document preparation, and university thesis submission remain independent academic activities outside software development.

---

## 2. Quick-Start Guide

### Prerequisites
- macOS (arm64/Apple Silicon) or Linux (x86_64)
- C++17 compliant compiler (`clang++` or `g++`)
- CMake 3.20+
- Boost C++ Libraries (program_options, filesystem, system)
- Python 3.9+ (standard library only; zero pip requirements for viewer and verification)

### Step 1: Build Binaries (Release Mode)
```bash
# Build baseline solver (C++14 Release)
scripts/build_baseline.sh Release

# Build RouteBudget Lab benchmark suite, validator, and test suites (C++17 Release)
mkdir -p build/bench-release
cmake -B build/bench-release -DCMAKE_BUILD_TYPE=Release
cmake --build build/bench-release -j4
```
*(Building with `-j4` compiles all benchmark binaries and test targets so CTest executes immediately).*

### Step 2: Run Verification Test Suite
```bash
# Run C++ unit and integration tests (7/7 tests)
ctest --test-dir build/bench-release --output-on-failure

# Verify safe independent validator on initial plan fixtures
python3 tests/test_safe_validation.py

# Verify replay dataset and viewer integrity across all 768 runs (5/5 test groups)
python3 tests/test_viewer_and_replays.py
```

### Step 3: Launch the Offline Replay Viewer
```bash
# Launch lightweight local server (zero external CDN dependencies)
python3 viewer/server.py --port 8080

# Open in your browser:
# http://127.0.0.1:8080
```

---

## 3. Benchmark Execution Commands

All reference benchmarks execute in **strict sequential single-worker mode** to prevent CPU preemption and core-migration contention between concurrent solver processes.

### Re-verifying Reference Runs
The entire 768-run reference evaluation is complete and recorded in `results/phase7/verified_reference/verified_reference_manifest.json`. To execute or re-verify:
```bash
# Verifies all 768 conditions sequentially (skips already-verified runs in 0.0s)
python3 scripts/run_phase7_verified_reference.py --scenarios 1,2,3
```
*Resume notice:* The runner records every completed run immediately to `verified_reference_manifest.json`. If interrupted, running the command automatically resumes from the last completed run without re-executing verified tasks.

---

## 4. Replay Export & Offline Viewer (Phase 8)

### Export Versioned Replays
Converts verified benchmark runs and retained trajectories into self-contained, versioned JSON replay packages (`results/phase8/replays/*.replay.json`):
```bash
python3 scripts/export_replays.py
```
*Export features:*
- **Coordinate Normalization:** Automatically maps upstream BALANCE `(row, col)` and RBL `(col, row)` to canonical `(x, y)` Cartesian coordinates (`COL_ROW_XY`).
- **Obstacle & Geometry Extraction:** Captures full traversability grid and boundary dimensions.
- **Cryptographic Provenance:** Records source `.paths` file path, SHA-256 hash, and independent validation status.
- **Catalog Index:** Builds `results/phase8/replays/replays_index.json` containing all 768 replays for UI filtering.

### Launching the Offline Viewer
```bash
python3 viewer/server.py --port 8080
```
- **Local Address:** `http://127.0.0.1:8080`
- **Zero CDN Dependencies:** All fonts, styling, canvas rendering, and scripts are bundled locally.
- **Offline Mode:** Replays saved, validated trajectories; does not attach live solver execution.

### Viewer Capabilities & Features
1. **Multi-Condition Filtering:** Dropdown selectors for Map, Scenario, Agent Scale (50, 100), Budget (1.0s, 5.0s, 10.0s, 30.0s), Method, and Protocol.
2. **Interactive Viewport:** Canvas pan (drag) and smooth zoom (scroll wheel) with "Fit View" auto-centering.
3. **Non-Square Geometry Support:** Accurately renders non-square maps (e.g., `warehouse-20-40-10-2-1` at $321 \times 123$) without aspect distortion.
4. **Playback Engine:** Play, pause, single-step forward/backward, rewind reset, and variable speed multipliers ($0.25\times$ to $10\times$).
5. **Stay-at-Goal Simulation:** Agents reaching their goals remain stationary at their destination cell, modeling physical MAPF vertex occupancy.
6. **Agent Inspector:** Click any agent on the canvas or quick-select chip to inspect start, goal, current position, path length, and exact arrival step.
7. **Metric HUD:** Displays planning solve time vs. wall-clock budget alongside discrete movement steps vs. makespan.
8. **Filter Validation:** Gracefully handles invalid/empty filter combinations (e.g. mismatched method and protocol) by displaying an explicit notice.

---

## 5. Statistical Analysis & Reporting

To generate paired statistical comparisons, bootstrap confidence intervals, and leave-one-map-out sensitivity across all 96 problem conditions:
```bash
python3 scripts/analyze_phase7_verified.py
```
*Evaluation reports:*
- Full empirical analysis: `docs/phase7_evaluation_report.md`
- Audited implementation status: `IMPLEMENTATION_STATUS.md`
- Architectural decisions: `docs/decisions.md`

---

## 6. Demonstration Walkthrough & Manual Browser Checklist

### Automated Verification
1. **Verify Binary Builds:**
   ```bash
   ls -la build/bench-release/rbl_eval_runner build/bench-release/rbl_validate
   ```
2. **Inspect Verified Replays:**
   ```bash
   python3 tests/test_viewer_and_replays.py
   ```
   *Expected output:* All 768 replays verified for coordinates, obstacle clearance, bounds, and makespan (5/5 test groups passed).

### Manual Browser Verification Checklist
Open `http://127.0.0.1:8080` in Safari, Chrome, or Firefox and verify the following visual interactions:
- [ ] **Catalog Parity:** Dropdown selects Map, Scenario (1–3), Agents (50, 100), Budget (1.0s–30.0s), and Method.
- [ ] **Non-Square Map Rendering:** Select `warehouse-20-40-10-2-1`, Scenario `1`, Agents `50`, Budget `1.0s`, Method `SCORE_BASED_ADAPTIVE`. Click **Load Replay**. Verify the $321 \times 123$ warehouse geometry auto-fits to the canvas without horizontal stretching.
- [ ] **Complex Bottleneck Terrain:** Select Map `ost003d`, Scenario `1`, Agents `100`, Budget `30.0s`. Press **Play** and observe smooth collision-free coordination through narrow bottlenecks.
- [ ] **Interactive Viewport:** Click and drag the canvas to pan; use the scroll wheel to zoom in on clusters; click **Fit View** to restore full map centering.
- [ ] **Playback Controls:** Test **Play**, **Pause**, **Step Forward**, **Step Back**, and **Reset**. Adjust speed slider from $0.25\times$ to $10\times$.
- [ ] **Stay-at-Goal Physical Occupancy:** Advance playback past step 50; verify that agents reaching their goal remain visible and stationary as physical obstacles.
- [ ] **Agent Inspection HUD:** Click any agent on the canvas or an agent chip in the inspector panel; verify the selected agent is highlighted and its coordinates and path metrics are displayed.
- [ ] **Empty Filter Handling:** Select Method `BASELINE_BALANCE` and Protocol `Protocol A (Refinement Only)`. Verify the UI displays *"No replay matches selected filters."* without crashing.

---

## 7. Reproducible Packaging

Generate a self-contained source, dataset, and replay distribution archive:
```bash
./scripts/package_archive.sh
```
Produces `dist/RouteBudgetLab_Phase8_Final_<timestamp>.tar.gz` containing all source code, tests, documentation, viewer assets, verified manifest, and 768 replays.

To verify archive checksum:
```bash
shasum -a 256 dist/RouteBudgetLab_Phase8_Final_*.tar.gz
```

---

## 8. License & Attribution

- **Upstream Baseline:** Upstream BALANCE (`third_party/anytime-mapf`) is vendored under USC research license (see `third_party/anytime-mapf/license.txt`).
- **RouteBudget Lab Components:** Developed as part of the final-year research project on constraint-validated resumption and deadline-aware MAPF-LNS.

