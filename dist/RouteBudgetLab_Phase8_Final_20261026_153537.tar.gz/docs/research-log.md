# Research & Engineering Log

**Project:** RouteBudget Lab  
**Author:** P. G. Disas Sethnada (IIT: 20231323, UoW: w2119964)

---

## 2026-10-21: Phase 1 — Environment, Backbone Selection, and Baseline Verification

### 1. Backbone Selection
- Reviewed candidate repositories:
  - `thomyphan/anytime-mapf` (BALANCE): ~5.0k lines of clean C++, standard MAPF-LNS2 lineage, USC research license (`license.txt`).
  - `JimyZ13/ADDRESS`: ~5.9k lines, built on BALANCE, adds address/grouping logic. Retained as an unmodified external baseline for Experiment E6.
  - `thomyphan/counterfactual-mapf-lns`: No license file. Rejected for modifications.
  - `ChristinaTan0704/mapf-lns-unified`: Heavy Python/ML dependencies, unsuitable for standalone C++ MAPF-LNS research workbench.
- Selected `thomyphan/anytime-mapf` pinned at commit `47bb25e9ba58b22172e1531cb26f25af8a4531e9`.
- Captured byte-exact SHA-256 hash manifest in `third_party/anytime-mapf/UPSTREAM_FILES.sha256` and verification script `scripts/verify_upstream.sh`.

### 2. Platform & Toolchain Hardening
- Target Machine: Apple Silicon MacBook (Apple M3, arm64, 8 GB RAM), macOS 26.3.
- Discovered issue: Xcode license unaccepted on system level, which blocks `/usr/bin/g++`, `/usr/bin/clang++`, `/usr/bin/git`, and Homebrew shims.
- Implemented non-privileged toolchain wrapper in `scripts/common.sh` using `/Library/Developer/CommandLineTools/usr/bin/clang++` and explicit SDKROOT pointing to `MacOSX.sdk`. No `sudo` or license bypass required.
- Eigen 3.4.0 (MPL2) vendored header-only into `third_party/eigen` to avoid Homebrew dependency.
- Upstream C++ Standard: Upstream uses C++14 and `std::random_shuffle` (removed in C++17). Implemented `scripts/build_baseline.sh` supporting both C++14 reference (`build/baseline-release-cxx14/balance`) and C++17 with `-D_LIBCPP_ENABLE_CXX17_REMOVED_RANDOM_SHUFFLE` (`build/baseline-release-cxx17/balance`), plus ASan/UBSan sanitizer configuration (`build/baseline-asan-cxx14/balance`).
- Discovered upstream trap: `--maxIterations` defaults to 0 in `driver.cpp`. Without passing `--maxIterations`, the solver exits after 1 iteration. Fixed by mandating `--maxIterations=1000000` in all harnesses.
- Executed smoke run on `random-32-32-20` (50 agents, seed 0). Verified final cost 1147 across runs and zero ASan/UBSan errors.

---

## 2026-10-21: Phase 2 — Data, Independent Validator, Profiling, and Gate 1

### 1. Independent Path & Collision Validator (`src/validator/`)
- Implemented C++17 validator with zero external solver dependencies:
  - `rbl_validator.hpp` (header library): Moving AI map/scenario parser, path parser, grid transition checks, vertex collisions, edge swaps, stay-at-goal occupancy checks, and independent sum-of-costs accumulator.
  - `rbl_validate.cpp` (CLI): JSON and human-readable reporting with POSIX exit codes (0 = VALID, 1 = INVALID, 2 = USAGE/IO ERROR).
- Unit Tests (`tests/validator_tests.cpp`):
  - 54 assertions testing valid plans, edge swaps, parked collisions, out-of-bounds moves, diagonal steps, multi-cell jumps, duplicate agents, malformed files.
  - Cross-checked against a naive pairwise oracle over 4,000 randomized test plans with 100% agreement.
  - Executed cleanly under both Release and AddressSanitizer/UBSan.
- **Critical Coordinate Finding:**
  - Upstream `LNS::writePathsToFile` outputs `(row, col)` = `(y, x)` rather than standard `(col, row)` = `(x, y)`.
  - Configured `rbl_validate` to default to `(row, col)` for solver paths, with `--coords xy` for fixture/scenario coordinate checks.
  - Baseline paths `paths1.txt` and `paths2.txt` independently verified as `VALID` with cost = 1147 matching reported cost.

### 2. Moving AI Dataset Ingestion & Partition Isolation (DR-01)
- Downloaded official Moving AI zips (`mapf-map.zip`, `mapf-scen-random.zip`, `mapf-scen-even.zip`) into `data/raw/` with verified SHA-256 hashes.
- Extracted and structured into 3 isolated partitions:
  - `data/training/`: 4 maps (`warehouse-10-20-10-2-1`, `random-32-32-20`, `maze-32-32-2`, `empty-32-32`) with 25 scenarios each (100 total).
  - `data/validation/`: 2 maps (`warehouse-10-20-10-2-2`, `random-64-64-10`) with 25 scenarios each (50 total).
  - `data/test/`: 4 maps (`warehouse-20-40-10-2-1`, `random-64-64-20`, `room-64-64-8`, `ost003d`) with 25 scenarios each (100 total).
- All 10 maps and 250 scenarios verified via `scripts/verify_datasets.py` for dimensions, valid characters, and obstacle-free agent starts/goals.

### 3. Checkpoint Feasibility Spike (`src/profiler/profile_checkpoint_feasibility.cpp`)
- Evaluated Micro-Frontier Cloning vs. Macro-Prefix Checkpointing:
  - Macro-Prefix: $0.10 - 0.32\ \mu\text{s}$ save latency, $0.11 - 0.33\ \mu\text{s}$ restore latency, $1.4 - 7.6\ \text{KB}$ memory. Overheads $< 0.01\%$ of a 10 ms slice.
  - Micro-Frontier: $15.4 - 429.3\ \mu\text{s}$ save latency, $3.6 - 123.2\ \mu\text{s}$ deallocation latency, $7.5 - 670\ \text{KB}$ memory. Fragile pointer remapping.
- Recorded in `results/profiling/checkpoint_feasibility.json`.

### 4. Training Partition Profiling (`scripts/profile_training_maps.py`)
- Profiled baseline repair dynamics across all 4 training partition maps for 50 and 100 agents (5.0s budget, seed 0).
- Key observations:
  - 100% of plans verified as `VALID` by independent validator.
  - Rejection rates exceed 98.5% across all instances.
  - Per-iteration median durations are $0.07 - 0.65\ \text{ms}$.
  - Constrained maps (`warehouse` and `maze` with 100 agents) have heavy tails: p95 reaches $1.36 - 1.53\ \text{ms}$, with maximum durations reaching $56.33\ \text{ms}$ (warehouse) and $87.89\ \text{ms}$ (maze).
  - Recorded in `results/profiling/training_dynamics_summary.json`.

### 5. Gate 1 Feasibility Verdict
- Gate 1 formally passed in `docs/gate1-feasibility-report.md`.
- Adopted Fallback 1A (Macro-Prefix Checkpointing) as the verified technical architecture for Phase 3.
- State tuple $C_i$ formally defined and recorded in `docs/decisions.md` (D5).

---

## 2026-10-21: Gate 1 Audit & Phase 3 — Macro-Prefix Resumable Repair Engine

### 1. Gate 1 Audit & Overhead Corrections
- **Overhead Calculation Audit:** Identified exact numerator ($T_{snap}, T_{rest}, T_{free}$) and denominator ($\Delta \in \{5\text{ ms}, 10\text{ ms}\}$). Corrected the preliminary claim that micro-frontier cloning failed the 10% snapshot target on a 10 ms slice (measured: 4.29% to 6.78% for 10k nodes). However, combined save+restore reaches 14.41% on 10 ms and 28.82% on 5 ms, and carries severe pointer-invalidation hazards. Fallback 1A (Macro-Prefix) was adopted for simpler ownership, lower engineering complexity, sub-microsecond latency (<0.7 $\mu$s), and zero dangling pointer risk.
- **Repair Outcome Separation:** Disentangled whole-iteration durations from active repair search times. Built `src/profiler/profile_repair_outcomes.cpp` and `scripts/profile_repair_outcomes.py`. Profiled across all 4 training partition maps under unconstrained and artificial slices ($\Delta \in \{5\text{ ms}, 10\text{ ms}\}$):
  - In unconstrained search, 0% of repairs time out. 64%–100% of iterations are non-improving (`COMPLETED_NOT_IMPROVING`), proving that rejection rate $\ne$ timeout rate.
  - Slices cut off primarily during dense, long-tail repairs (`maze-32-32-2`, 100 agents), where 30%–40% of repairs exceed 5–10 ms.
  - In 100% of interrupted cases, $r_{done} \ge 1$ (`has_reusable_prefix = true`).
- Gate 1 verdict recorded as **PASSED (CONDITIONAL on Macro-Prefix Fallback 1A)** in `docs/gate1-feasibility-report.md` and `docs/decisions.md` (D5).

### 2. Phase 3: Macro-Prefix Resumable Repair Engine (`src/engine/`)
- Implemented core components:
  - `src/engine/rbl_checkpoint.hpp`: State tuple $C_i = \langle \text{id}, \text{state}, \mathcal{N}_i, \text{ord}(\mathcal{N}_i), r_{done}, P_{done}, P_{old}, c_{old}, v_{inc}, \text{seed}_{unfinished}, t_{active}, \text{exp}_{active} \rangle$, bounded checkpoint store for $K \in \{0, 1, 2\}$, lifecycle states (`EMPTY, ACTIVE, SUSPENDED, COMMITTED, DISCARDED, EXPIRED`), and deterministic FIFO eviction.
  - `src/engine/rbl_search_budget.hpp`: Cooperative budget checking with monotonic chrono and expansion limits, and 5 distinct outcome types.
  - `src/engine/rbl_resumable_engine.hpp` and `.cpp`: Resumable repair engine with cooperative interruption checks inside low-level Space-Time $A^*$ and between agents, transactional incumbent rollback, reservation rebuilding on resumption, and deterministic tie-breaking RNG propagation.
- Discovered and resolved upstream buffer overflow in `PathTable.cpp:46` at $t=0$ by safely handling start-location occupancy checks in `findPathWithBudget` and `createInitialPaths`.

### 3. Experiment E1 Execution & Verification (`tests/e1_resumption_tests.cpp`)
- Automated test suite executes 6 comprehensive test cases:
  1. Uninterrupted Repair Baseline
  2. Interruption After 2 Agents ($r_{done}=2$) & Resumption Equivalence (cost and outcome match baseline)
  3. Interruption Before Any Prefix ($r_{done}=0$) & Clean Resumption
  4. Multiple Pause/Resume Cycles (identical cost reached)
  5. Bounded Store Eviction and $K=0$ Configuration
  6. Independent Path Validity via `rbl_validator` (100% VALID, independent cost matches engine incumbent cost)
- Verified cleanly under both Release (`build/audit-release`) and AddressSanitizer/UBSan (`build/audit-asan`) with zero memory leaks, zero heap buffer overflows, and zero undefined behavior.

### 4. Focused E1 Test Coverage Enhancements
- Expanded `tests/e1_resumption_tests.cpp` to 10 comprehensive test categories:
  1. Uninterrupted Repair Baseline.
  2. Interruption at agent boundary ($r_{done}=2$) with cell-by-cell path equality against baseline.
  3. Interruption inside low-level Space-Time $A^*$ search (mid-search cutoff on agent 1 with active node expansions; verifies completed prefix survives, unfinished frontier is discarded in macro-prefix mode, agent restarts with deterministic state, repeated work recorded, incumbent untouched until valid accepted commit).
  4. Repeated interruption on same difficult agent (verifies lack of progress reported accurately, 0 progress, frontier discarded).
  5. Interruption before prefix ($r_{done}=0$).
  6. Multiple pause/resume cycles.
  7. Bounded store lifecycle ($K=0, K=1, K=2$ FIFO eviction).
  8. Global deadline expiry (`STOPPED_DEADLINE` returned with 0 state mutations).
  9. Independent path validation via `rbl_validator` (`VALID`, cost matches engine).
  10. Live integrated performance measurement: save latency = $0.79\ \mu$s (Release) / $3.75\ \mu$s (ASan), restore latency = $3.12\ \mu$s (Release) / $11.88\ \mu$s (ASan), combined save+restore = $3.92\ \mu$s Release (0.039% of 10 ms slice), retained checkpoint memory = 1024 bytes (1.0 KB).

---

## 2026-10-21: Phase 4 — Two-Stage Conservative Constraint Compatibility Validator & Experiment E4

### 1. Two-Stage Validator Architecture (Component 2: `src/engine/rbl_constraint_validator.hpp`)
- Implemented `ConservativeConstraintValidator` and `CompatibilityReport` with explicit diagnostic verdicts:
  - `COMPATIBLE_UNCHANGED`: Fast Stage 1 $O(|A|)$ version check match ($0.29 - 0.42\ \mu$s latency).
  - `COMPATIBLE_PREFIX_VALID`: Stage 2 spatio-temporal reservation check passed against modified external agents.
  - `DISCARD_NEIGHBORHOOD_MUTATED`: Check 1 detected overlapping repair in $\mathcal{N}_i$ in intervening iteration.
  - `DISCARD_COST_BOUND_EXCEEDED`: Check 2 detected prefix accumulated cost $\ge$ current neighborhood incumbent cost.
  - `DISCARD_VERTEX_CONFLICT`: Check 3 detected vertex collision at $(x, y, t)$.
  - `DISCARD_EDGE_SWAP`: Check 3 detected edge swap transition $(u \leftrightarrow v)$.
  - `DISCARD_STAY_AT_GOAL`: Check 3 detected collision with parked external agent at $t \ge t_{goal}$.
  - `DISCARD_POLICY_DISABLED`: Reference Policy 0 (Discard-on-Change) discarded due to incumbent version increment.
- Theoretical Justification: Macro-prefix mode only retains completed concrete trajectories $P_{0..r_{done}-1}$. It discards the unfinished search frontier. Compatibility is strictly established for the concrete trajectories actually retained, without implying correctness for an unexpanded frontier checkpoint.
- Explicit Stage Tracking: `CompatibilityReport` tracks `stage_reached` (0 = Policy-0 version check only, 1 = Stage 1 version match, 2 = Stage 2 spatio-temporal check) and `modified_external_agents`.

### 2. Integration with Resumable Repair Engine
- Updated `rbl_resumable_engine.hpp` and `.cpp` with per-agent trajectory versions (`agent_trajectory_versions`), checkpoint context recording, reservation rebuilding from current external paths and retained prefix, re-evaluation of candidate improvement against the *current* neighborhood cost, and independent final-path validation before commitment.
- Implemented `commitExternalTrajectory(agent, new_path)` to safely verify invariants and commit external updates.

### 3. Experiment E4 Test Suite Execution (`tests/e4_compatibility_tests.cpp`)
- Built and registered `rbl_e4_tests` in `CMakeLists.txt`.
- Executed 8 automated test categories:
  1. Unchanged Context (Stage 1 match, sub-microsecond latency: $0.29\ \mu$s).
  2. Irrelevant External Changes: Verified genuine external trajectory modification on agent 8, version increment ($V_{inc}: 1 \to 2$), Policy 0 rejection (`DISCARD_POLICY_DISABLED`, `stage_reached = 0`), Policy 1 Stage 2 execution (`stage_reached = 2`, `COMPATIBLE_PREFIX_VALID`), and strictly valid final solution upon resumption.
  3. Conflicting Changes (Vertex conflict detected and discarded).
  4. Edge Swap & Stale Reservation Clearing (Edge swap detected and discarded).
  5. Changed Goal Occupancy (Stay-at-goal collision detected and discarded).
  6. Overlapping Neighborhood Repairs (Neighborhood mutation detected and discarded).
  7. Cost Bound Pruning (Prefix cost $\ge$ neighborhood cost detected and discarded).
  8. Comprehensive Policy Comparison: Evaluated across 20 controlled MAPF scenarios with external perturbations. Policy 0 retained 8 eligible checkpoints; Policy 1 retained 14 eligible checkpoints (75% higher retention). Mean validation latency: $0.24\ \mu$s (Policy 0) vs $0.71\ \mu$s (Policy 1). Verified 0 invalid solution commits across all runs.
- 100% tests passing in both Release (`build/audit-release`) and AddressSanitizer/UBSan (`build/audit-asan`).

---

## 2026-10-21: Phase 5 Implementation (Feature Extraction, Trace Collection, Honest Estimator Evaluation & C++ Inference)

### 1. Controlled Perturbation Hardening & Feature Contract
- Hardened `commitExternalTrajectory(agent, new_path, allow_worsening = true)`:
  - Default `allow_worsening = false`: Rejects any path increasing sum of costs or causing collisions in production planner mode.
  - Test mode `allow_worsening = true`: Explicitly designated and isolated for controlled perturbation testing (Experiment E4).
- Defined 13 decision-time features in `src/engine/rbl_feature_extractor.hpp`:
  - `action_type`, `neighborhood_size`, `completed_prefix_ratio`, `cumulative_expansions`, `cumulative_active_time_s`, `repeated_expansions`, `remaining_agents_count`, `remaining_agents_lowerbound_cost`, `current_neighborhood_cost`, `prefix_cost_ratio`, `local_congestion_density`, `requested_slice_duration_s`, `remaining_global_budget_ratio`.
  - In strict accordance with the macro-prefix contract, live open-list size is omitted (frontier is discarded on suspension).
  - Defined two prediction targets: Target A (Expected Accepted Improvement $\hat{E}[\text{AcceptedImprovement}(a, \Delta)] \ge 0.0$) and Target B (Expected Active Search Time $\hat{E}[\min(T_{rem}, \Delta)] \in [0.0, \Delta]$). Overhead is cleanly excluded from search time.

### 2. Real Trace Collection & Partition Isolation (`src/profiler/collect_progress_traces.cpp`)
- Built `rbl_collect_traces` and executed on Moving AI benchmark partitions:
  - Training dataset (`results/traces/training_traces.csv`): 1,280 samples collected from 4 training maps (`random-32-32-20`, `empty-32-32`, `maze-32-32-2`, `warehouse-10-20-10-2-1`). Fresh: 1,159, Resumed: 121. Outcomes: 42 accepted, 1,103 non-improving, 135 interrupted, 0 failed.
  - Validation dataset (`results/traces/validation_traces.csv`): 640 samples collected from 2 validation maps (`random-64-64-10`, `warehouse-10-20-10-2-2`). Fresh: 529, Resumed: 111. Outcomes: 0 accepted, 516 non-improving, 124 interrupted, 0 failed.
  - Partition isolation verified: zero map overlap between train and validation; test maps 100% untouched.

### 3. Transparent Baselines & Honest Offline Evaluation (`scripts/train_estimator.py`)
- Standard scaler and models fit on training data only.
- Zero-Inflation finding: 96.72% of training labels and 100.00% of validation labels have zero accepted improvement. This is inherent to MAPF LNS operating near optimal initializations. A trivial zero predictor appears deceptively accurate in terms of MAE.
- Target A Results (Validation MAE / RMSE):
  - Constant Baseline: MAE = 0.38281, RMSE = 0.38281
  - Tabular Baseline: MAE = 0.42312, RMSE = 0.64305
  - Fitted Ridge: MAE = 0.52418, RMSE = 0.89021
- Target B Results (Validation MAE / RMSE):
  - Constant Baseline: MAE = 0.00078 s, RMSE = 0.00154 s
  - Tabular Baseline: MAE = **0.00066 s (0.66 ms)**, RMSE = 0.00151 s
  - Fitted Ridge: MAE = 0.00094 s (0.94 ms), RMSE = 0.00159 s
- Crucial scientific finding: The simple Tabular baseline outperforms the fitted Ridge regression model on held-out validation maps. In accordance with honest evaluation principles, the baseline is retained as a first-class estimator option.

### 4. C++ Inference Engine & Numerical Parity (`src/engine/rbl_estimator.hpp` & `tests/estimator_tests.cpp`)
- Implemented `SearchProgressEstimator` supporting `RIDGE_REGRESSION`, `TABULAR_BASELINE`, and `CONSTANT_BASELINE`.
- Embedded default weights and scaling parameters with robust fallbacks for missing files or non-finite inputs (NaN, Inf).
- Verified Python vs C++ Parity: Absolute error $< 10^{-5}$ across all test cases.
- Measured inference latency in Release build on Apple M3: **$0.0744\ \mu\text{s}$ per prediction** ($7.44 \times 10^{-5}\ \text{ms}$), well below the $0.1\ \text{ms}$ proposal target.
- Sanitizer verification: 6/6 tests passing in both Release and ASan/UBSan builds.

---

## 2026-10-21: Phase 6 — Overhead-Aware Resume-or-Start Controller & Gate 2 Audit

### 1. Proposed Controller Integration (`src/engine/rbl_controller.hpp`)
- Implemented `ResumeOrStartController` supporting Component 4 (O4, FR-05, WP4).
- Evaluates the proposed scoring equation:
  $$\text{Score}(a, \Delta) = \frac{\hat{E}[\text{AcceptedImprovement}(a, \Delta)]}{\hat{E}[\min(T_{\text{rem}}(a), \Delta)] + \widehat{\text{Overhead}}(a)}$$
  subject to strict admissibility:
  $$\Delta + \widehat{\text{Overhead}}(a) + t_{\text{reserve}} \le b_k$$
- Cost Separation:
  - Incurred overheads (validation, candidate generation, feature extraction, scoring) are treated strictly as elapsed wall-clock time already deducted from remaining budget $b_k$.
  - Prospective overhead $\widehat{\text{Overhead}}(a)$ models only prospective future costs: prospective restore/init latency plus conditional checkpoint-saving cost ($p_{\text{interrupt}} \cdot \hat{t}_{\text{save}}$).
  - Avoids double-counting.
- Strict Monotonic Wall-Clock Accounting:
  - Uses `std::chrono::steady_clock` throughout.
  - Remaining budget refreshed immediately before action execution.
  - Late commit rejection (`REJECTED_LATE_COMMIT`): if search or validation finishes after deadline $B$, candidate is rejected without mutating incumbent.
  - Incumbent preserved on interruption, invalidity, non-improvement, or exhausted budget.

### 2. Fair Policy Controls & Weak Prediction Handling
- Implemented three matched policy modes:
  1. `RESTART_ONLY_K0`: $K=0$, fresh repairs only, 10 ms fixed slice.
  2. `FIXED_FIFO_RESUME`: $K=2$, unconditional FIFO resumption whenever a compatible checkpoint exists, 10 ms fixed slice.
  3. `SCORE_BASED_ADAPTIVE`: $K=2$, overhead-aware score-based selection across candidate actions and candidate slices $\Delta \in \{0.002, 0.005, 0.010, 0.020, 0.050\}$ s.
- Deterministic Fallback: When all predicted improvements are zero (reflecting the zero-positive-validation finding), invokes documented deterministic fallback prioritizing compatible resumed actions with highest completed prefix ratio $r_{\text{done}} / |A_c|$ and allocating the smallest admissible slice $\Delta$.
- Bounded Response to Macro-Prefix Stagnation: Checkpoints failing to advance $r_{\text{done}}$ for $\ge 2$ consecutive resumption attempts are evicted from active storage (`stagnant_checkpoints_evicted`), bounding wasted computation. Repeated expansions upon restart are measured and accumulated.

### 3. Focused Integration Test Suite (`tests/controller_tests.cpp`)
- Automated test suite exercises 6 categories:
  1. Controller initialization & missing initial solution rejection.
  2. Matched policy modes ($K=0$ vs $K=2$ FIFO vs adaptive).
  3. Deterministic fallback on all-zero predicted improvements.
  4. Stagnation eviction after repeated non-advancing resumptions.
  5. Late commit rejection with strict incumbent preservation.
  6. Decision pipeline latency audit.
- 100% tests passing in both Release (`build/audit-release`) and AddressSanitizer/UBSan (`build/audit-asan`).

### 4. Gate 2 Integration & Overhead Audit (`src/profiler/profile_gate2_controller.cpp`)
- Evaluated on training maps (`random-32-32-20` and `warehouse-10-20-10-2-1`, 20 agents, $B = 1.0$ s deadline); held-out test maps kept 100% untouched.
- Complete Decision Pipeline Latency Audit (100 steps over varying budgets, varying checkpoint states, extracting 13 features $\times$ 5 actions $\times$ 5 slices = 25 evaluations per step):
  - Median: **$15.83\ \mu\text{s}$ (0.016 ms)**
  - P90: $39.75\ \mu\text{s}$ (0.040 ms)
  - P95: $74.67\ \mu\text{s}$ (0.075 ms)
  - P99: $200.92\ \mu\text{s}$ (0.201 ms)
  - Max: $200.92\ \mu\text{s}$ (0.201 ms)
  - Proposal target $\le 1.0\ \text{ms}$ is comfortably satisfied (even P99 is $\sim 5\times$ faster than target).
- Matched Policy Comparison Results:
  - `random-32-32-20`: Initial cost 464, Final cost 413, Improvement 51 across all policies. Valid: 100% PASS. Repeated work: `RESTART_ONLY_K0` = 0%, `FIXED_FIFO_RESUME` = 75.2%, `SCORE_BASED_ADAPTIVE` = 0%. Overshoot = 0.00 ms.
  - `warehouse-10-20-10-2-1`: Initial cost 1616, Final cost 1505, Improvement 111 across all policies. Valid: 100% PASS. Repeated work: `RESTART_ONLY_K0` = 0%, `FIXED_FIFO_RESUME` = 88.7%, `SCORE_BASED_ADAPTIVE` = 36.1%. Overshoot = 0.00 ms.
- Explicit Gate 2 Criteria:
  1. [Correctness & Validity] 100% independent whole-plan collision check: PASS.
  2. [Strict Monotonic Accounting] Bounded deadline overshoot (< 50 ms): PASS (0.00 ms).
  3. [Overhead Target] Complete decision pipeline median <= 1.0 ms: PASS ($15.83\ \mu$s).
  4. [Fair Controls & Bounded Response] Stagnation eviction & late commit recheck: PASS.
- Verdict: **GATE 2 PASSED** (Recorded in `docs/gate2_results.json`).

---

## 2026-10-23: Phase 7 — Controlled Experimental Evaluation (E1–E6, RQ1–RQ3)

### 1. Benchmark Binary & Reproducibility Audit
- Built fresh Release executables in ignored directory `build/bench-release/` (`rbl_eval_runner`, `rbl_controller_tests`, etc.) using Command Line Tools clang++ (`-O3 -DNDEBUG -std=c++17`).
- Built pristine upstream baseline in `build/baseline-release-cxx14/balance` (C++14 Release) and `build/baseline-release-cxx17/`.
- Captured machine details (Apple M3, 8 cores, 16 GB, Darwin 25.3.0) and SHA-256 binary manifests.
- Verified 100% CTest pass across all 7 test suites (2.51s real runtime).

### 2. Component Separation via Matched Experimental Controls
- Established seven matched configurations to disentangle action-selection from slice-selection effects:
  1. `RESTART_ONLY_K0` ($K=0$, fixed 10 ms slice).
  2. `FIXED_FIFO_RESUME` ($K=2$, fixed 10 ms slice).
  3. `SCORE_BASED_FIXED` ($K=2$, matched fixed 10 ms slice).
  4. `SCORE_BASED_ADAPTIVE` ($K=2$, variable slice grid $\{2, 5, 10, 20, 50\}$ ms).
  5. `ELAPSED_TIME_ONLY` ($K=2$, variable slice grid, search-progress features masked).
  6. `DISCARD_ON_CHANGE` ($K=2$, variable slice grid, Policy 0 discard-on-change).
  7. `BASELINE_BALANCE` (upstream published baseline).

### 3. Representative Development Pilot Diagnosis
- Executed 100 runs across 5 training/validation maps at 50 and 100 agents under 1s and 5s budgets.
- Diagnosed why Phase 6 had 0/4 resumptions: 20-agent subproblems solved in $<0.05$ ms, virtually never hitting slice cutoffs. At 50/100 agents, crowding and congestion cause searches to routinely hit slice cutoffs (173,948 interruptions observed; 59.2% with non-empty prefixes; over 103,291 resumptions executed).
- Confirmed that zero observed validation gains reflect near-optimal initial plans, whereas zero predicted gain is handled safely via deterministic heuristic fallback.

### 4. Protocol Freeze (Decision D10) & Stratified Matrix Execution
- Reserved four designated held-out test maps strictly untouched until protocol freeze: `warehouse-20-40-10-2-1`, `random-64-64-20`, `room-64-64-8`, and `ost003d`.
- Stratified sampling: 3 scenarios per test map, 4 maps, 2 agent scales (50 and 100 agents), across 4 budgets (1.0s, 5.0s, 10.0s, 30.0s) = 24 scenario-agent pairs $\times$ 4 budgets = 96 evaluation conditions $\times$ 7 matched configurations = 672 total runs.
- Initial plans pre-computed and cached in `results/phase7/init_paths/`, guaranteeing 100% identical starting points for all compared methods.
- Executed in parallel across 6 worker processes on Apple M3 in 1,306.6 seconds (21.8 minutes). 100% runs completed successfully (exit code 0).

### 5. Key Empirical Findings (E1–E6, RQ1–RQ3)
- **100% Validity & Monotonic Deadlines:** 672 / 672 runs valid (PASS). Max deadline overshoot was 0.000 ms for RBL methods, compared to 1.93–3.99 ms for upstream BALANCE.
- **RQ1 (Resumption vs. Restart, E2):**
  - Matched 10 ms comparison: FIFO resumption achieved -8.64 mean cost reduction across all 96 instances, expanding to **-36.4 points at 30.0s** (8065.9 vs 8102.3).
  - Strong domain dependency: on organic terrain with severe bottlenecks (`ost003d`), FIFO resumption beat restart-only by **-125.0 points** (-79.1 points for score-based fixed). On uniform random grids (`random-64-64-20`), resumption and restart tied identically (0.0 points difference).
  - Checkpoint utility: Resumption directly harvested 62 accepted solution improvements from saved prefixes that restart-only discarded.
- **RQ2 (Action Selection & Compatibility Validation, E3, E4):**
  - Action selection: `SCORE_BASED_FIXED` vs `FIXED_FIFO_RESUME` yielded +11.59 points difference ($p=0.87$, not statistically significant). Score-based selection accepted 71 improvements from resumptions (vs 62 for FIFO) and reduced repeated work in 10s runs.
  - Selective compatibility validation: `SCORE_BASED_ADAPTIVE` outperformed Discard-on-Change by **-1.99 points** (95% CI: [-4.7, -0.1]), safely retaining compatible checkpoints across intervening incumbent updates.
- **RQ3 (Progress Features vs. Elapsed Time Only, E5):**
  - Full progress features vs elapsed-time-only yielded virtually identical final cost (-1.34 points difference, $p=1.00$).
  - However, progress features yielded 11 accepted improvements from resumed actions vs 7 for elapsed time only.
- **Separated Slice-Selection Effect:** Variable slice grid $\{2, 5, 10, 20, 50\}$ ms selected 2 ms slices heavily, adding decision churn without improving final cost over a steady 10 ms slice (+15.15 points cost difference).
- **Published Baseline Comparison (E6):** Published `BASELINE_BALANCE` achieved lower final cost (+237.30 points, $p < 0.0001$) by executing uninstrumented, monolithic LNS without per-slice preemption, feature extraction, or safety reserve margins, but at the expense of deadline overshoots (up to 3.99 ms).
- Comprehensive evaluation report compiled in `docs/phase7_evaluation_report.md`.

---

## 2026-10-23: Phase 7 Sequential Reference Benchmark, Protocol Separation & Safe Validation Audit

### 1. Safe Independent Validator & Regression Test Suite
- Identified critical defect in earlier validation scripts: `status = 'PASS' if 'VALID' in out else 'FAIL'` is vulnerable because substring `"VALID"` matches inside `"INVALID"` and `"INVALID_PLAN"`.
- Implemented `scripts/safe_validator.py` enforcing validator exit code == 0, strict JSON decoding, exact `status == "VALID"`, and reported cost match.
- Created `tests/test_safe_validation.py` with 6 automated tests:
  1. Valid result passes.
  2. Invalid result fails.
  3. The text `INVALID` cannot pass (proves naive check fails).
  4. Missing/malformed output fails.
  5. Process error fails.
  6. Real binary integration on valid and mutated colliding MAPF fixtures.
- All 6 tests pass cleanly.

### 2. Independent Initial Fixture & Sample Final Solution Revalidation
- Created `scripts/revalidate_initial_fixtures.py` converting RouteBudget Lab linear paths (`i:(loc)->...`) to Moving AI coordinate format (`Agent i:(col,row)->...`).
- Revalidated all 24 initial plan fixtures with `rbl_validate`: **24/24 (100.0%) independently verified as VALID** (`results/phase7/initial_fixtures_validation_report.json`).
- Added `--dump-final-paths` to `rbl_eval_runner`.
- Executed `scripts/validate_sample_final_solutions.py` on representative conditions across all 4 benchmark maps (`warehouse`, `random`, `room`, `ost003d`), dumping final paths and validating via `rbl_validate`: **4/4 (100.0%) independently verified as VALID** (`results/phase7/sample_final_validation_report.json`).
- Manifest explicitly designates runs without persisted path files as `UNVERIFIED_PATH_NOT_RETAINED`.

### 3. Upstream BALANCE Clock Semantics & Protocol Boundaries
- Audited `third_party/anytime-mapf`: confirmed outer LNS budget loop uses `std::chrono::high_resolution_clock` wall-clock time; `clock()` references are strictly subroutine diagnostic counters.
- Both RBL and BALANCE operate on wall-clock time.
- Implemented `--timing-protocol [refinement|end_to_end]` in `rbl_eval_runner.cpp`:
  - **Protocol A (Controlled Refinement, 192 runs):** 6 internal methods start from identical hash-verified initial plan fixtures, with initialization excluded from the refinement budget.
  - **Protocol B (End-to-End Planning, 64 runs):** `RBL_END_TO_END` and `BASELINE_BALANCE` generate initial solutions on-the-fly, with initialization charged to the budget.

### 4. Sequential Reference Benchmark Execution (256 runs)
- Executed strictly single-worker sequential runner `scripts/run_phase7_sequential.py` on Apple M3 (2,966.7 seconds / 49.4 minutes):
  - 4 test maps, 1 scenario (Scenario 1), 2 agent scales (50, 100), 4 budgets (1.0s, 5.0s, 10.0s, 30.0s), 8 configurations = 256 runs.
  - 100% completed (256/256), 0 failures, 0 timeouts.
  - Manifest generated by `scripts/verify_phase7_sequential_manifest.py` at `results/phase7/sequential_reference_manifest.json`.
  - Archived 672-run concurrent batch preserved in `results/phase7/concurrent_batch/`.

### 5. Preliminary Paired Statistical Evaluation Findings (Scenario 1 Batch)
- Computed in `scripts/analyze_phase7_sequential.py` (`results/phase7/sequential_statistical_analysis.json`):
  - **E2 (Resumption Effect, Protocol A):** `FIXED_FIFO_RESUME` vs `RESTART_ONLY_K0` achieved mean cost reduction of **+49.06 points** (10 wins, 6 losses, 16 ties).
  - **E3a (Controller Scoring, Protocol A):** `SCORE_BASED_FIXED` vs `FIXED_FIFO_RESUME` yielded mean difference of **-26.25 points** (95% CI: [-81.56, +15.72]). Finding: **INCONCLUSIVE**.
  - **E3b (Adaptive Slicing, Protocol A):** `SCORE_BASED_ADAPTIVE` vs `SCORE_BASED_FIXED` yielded mean difference of **-37.03 points** (95% CI: [-94.44, +15.25], 8 wins, 8 losses). Finding: **INCONCLUSIVE**.
  - **E4 (Selective Compatibility, Protocol A):** `SCORE_BASED_ADAPTIVE` vs `DISCARD_ON_CHANGE` yielded mean difference of **0.00 points** (32 ties). Finding: **NEUTRAL / INCONCLUSIVE**.
  - **E5 (Progress Features, Protocol A):** `SCORE_BASED_ADAPTIVE` vs `ELAPSED_TIME_ONLY` yielded mean difference of **-2.19 points** (95% CI: [-17.28, +11.19]). Finding: **INCONCLUSIVE**.
  - **E6 (End-to-End Baseline Comparison, Protocol B):** `BASELINE_BALANCE` outperformed `RBL_END_TO_END` on 21 of 32 conditions (mean difference **-261.00 points**, 95% CI: [-399.13, -138.75]). Finding: **UNSUPPORTED**.

---

## 2026-10-23: Phase 7 Evidence Package & Reporting Corrections Audit

### 1. Final-Solution Validation Audit & Trajectory Retention
- Audited previous sample solution validation: established that the 4 solutions evaluated in `sample_final_validation` came from separate exploratory reruns and cannot retroactively validate earlier benchmark runs.
- Strict run categorization established:
  - Process-completed runs.
  - Solver-reported valid runs.
  - Independently validated retained final trajectories.
  - Unavailable final trajectories (`UNVERIFIED_PATH_NOT_RETAINED`).
- Configured both solvers to retain final trajectories outside declared planning timers (zero planning overhead):
  - Upstream BALANCE: native `--outputPaths <file>` writes `(row, col)` via `LNS::writePathsToFile` after `lns.run()` exits.
  - RouteBudget Lab: `--dump-final-paths <file>` writes `(col, row)` via `saveMovingAIPathsToFile` after `controller.run()` exits.
- Recompiled Release binary `build/bench-release/rbl_eval_runner`.
- Completed verified replacement reference benchmark via `scripts/run_phase7_verified_reference.py` saving trajectories into `results/phase7/verified_reference/paths/` with immediate SHA-256 hashing and independent validation using `safe_validator.py` (`rbl_validate`):
  * **256 of 256 runs (100.0%)** completed, retained on disk, verified `VALID`, and cost-matched against independent sum of arrival times.
  * 0 runs unverified or missing.

### 2. Scenario-Coverage Transparency & Protocol Reconciliation
- Audited runner `scripts/run_phase7_sequential.py`: established that `SCENARIO_IDS = [1]` was selected specifically to keep single-worker sequential runtime bounded to ~49.4 minutes rather than running all 3 scenarios (~2.5 hours).
- The authorized reference design is: 4 maps $\times$ 3 scenarios $\times$ 2 agent counts $\times$ 4 budgets $\times$ 8 configurations = 768 runs.
- The single-scenario batch is designated strictly as "Preliminary Single-Scenario Sequential Benchmark (Scenario 1)".
- Recorded scenario IDs (`scenario_id = 1`) and seeds (`seed = 42` for RBL, `seed = 0` for BALANCE) separately across all manifest records.

### 3. Deadline Reporting Corrections & Monotonicity Verification
- Removed unsupported claims:
  - Sequential execution reduces contention but does NOT eliminate scheduling jitter or OS preemption.
  - RBL does not guarantee zero deadline overshoot; observed 11.8 ms overshoot on `room-64-64-8` at 30.0s demonstrates lack of hard guarantee.
  - A 0.5 ms reserve reduces overshoot frequency (99.55% compliance) but does not guarantee timely completion under tail congestion.
- Clock verification: inspected `std::chrono::high_resolution_clock` and `std::chrono::steady_clock` on Apple Clang 17 libc++. Verified `is_steady == 1` for both; both are strictly monotonic.
- Matched Protocol B Deadline Comparison (32 runs vs 32 runs, 1.0 $\mu$s tolerance):
  - `BASELINE_BALANCE`: 26 of 32 runs overran (81.2%); mean overshoot across all runs: 184.37 $\mu$s; mean among overrunning runs: 226.92 $\mu$s; max: 2,100.00 $\mu$s (2.10 ms); P50: 100.0 $\mu$s, P90: 298.0 $\mu$s, P95: 539.5 $\mu$s, P99: 1,669.1 $\mu$s.
  - `RBL_END_TO_END`: 0 of 32 runs overran (0.0%); mean overshoot: 0.00 $\mu$s; max: 0.00 $\mu$s.

### 4. Reassessment of Statistical Claims & Leave-One-Map-Out Sensitivity
- Replaced naive i.i.d. bootstrap with Clustered Bootstrap resampling at the map level ($B = 5,000$).
- Cluster-by-map bootstrap 95% CI for E2 spans zero: `[-17.16, +171.38]`.
- Per-map breakdown for E2:
  - `warehouse-20-40-10-2-1` (n=8): Mean = -22.88
  - `random-64-64-20` (n=8): Mean = +0.00 (8 ties)
  - `room-64-64-8` (n=8): Mean = -4.50
  - `ost003d` (n=8): Mean = +230.00
- Leave-One-Map-Out (LOMO) sensitivity:
  - Omitting `warehouse`: Mean = +75.17
  - Omitting `random`: Mean = +67.54
  - Omitting `room`: Mean = +69.04
  - **Omitting `ost003d`**: Mean = **-9.12** (resumption is worse on average).
- Qualified Finding: "FIFO resumption achieved a positive average improvement in the evaluated sample, concentrated on ost003d." A CI spanning zero does not prove equivalence.

### 5. Research Question Alignment & E4 Mechanistic Telemetry
- Aligned reporting directly with original approved research questions (RQ1, RQ2, RQ3).
- Mechanistic E4 audit: telemetry counters confirmed internal search execution differed between `DISCARD_ON_CHANGE` and `SCORE_BASED_ADAPTIVE` (e.g. 102k vs 103k decisions; 898 vs 919 resumes). However, in low-yield repair regimes (~14.8 accepted repairs, ~0.19 accepted from resumes), saved checkpoints reached stagnation age (mean 3,422 evictions) without discovering lower-cost global incumbents than fresh repairs, resulting in nearly identical final plateau costs ($\Delta = -0.09$, 29 ties, 1 win, 2 losses).
- Marked untested causal explanations as hypotheses.
- **Phase 7 Status:** Scenario 1 verified evaluation complete; Scenarios 2–3 pending; Phase 8 implementation can proceed.

---

## 2026-10-26: Phase 7 Completion (Full 768 Runs) & Phase 8 Verification & Closure

### 1. Full 768-Run Evaluation Execution & Validation
- Executed sequential reference benchmarks across all 3 scenarios:
  - 4 held-out maps $\times$ 3 scenarios $\times$ 2 agent scales (50, 100) $\times$ 4 budgets (1.0s, 5.0s, 10.0s, 30.0s) $\times$ 8 methods = 768 runs.
  - 100% completed (768/768), 0 failures, 0 timeouts.
- **Run Accounting & Independent Path Validation:**
  - 768 / 768 processes completed.
  - 768 / 768 solver reported valid.
  - 768 / 768 retained complete trajectory `.paths` files on disk (`results/phase7/verified_reference/paths/`).
  - 768 / 768 independently validated as collision-free via `safe_validator.py` (`rbl_validate`).
  - 768 / 768 exact cost matches between solver-reported and independently computed sum of arrival times.
  - 768 / 768 cryptographic SHA-256 hashes recorded and verified in `verified_reference_manifest.json`.
  - 0 unverified or unavailable trajectories.

### 2. Refreshed Statistical Analysis (N=96 Paired Conditions)
- Updated `scripts/analyze_phase7_verified.py` and output `results/phase7/verified_statistical_analysis.json`:
  - **E2 (Resumption Effect):** Wins: 23, Losses: 24, Ties: 49. Mean $\Delta\text{Cost} = +13.36$ (+0.145%). Clustered bootstrap 95% CI: `[-9.30, +52.15]` (spans zero).
    * Map breakdown ($n=24$ each): `warehouse` (-12.50), `random` (+0.29), `room` (-5.79), `ost003d` (+71.46).
    * Leave-One-Map-Out (LOMO) sensitivity: Omitting `ost003d` yields Mean $\Delta\text{Cost} = \mathbf{-6.00}$, proving that the resumption advantage is strictly confined to organic bottleneck terrain and does not generalize across open or regular grids.
  - **E3a & E3b (Scoring & Adaptive Slicing):** Inconclusive (CIs span zero: `[-39.53, +10.80]` and `[-40.42, +4.19]`).
  - **E4 (Selective Compatibility):** 86 ties out of 96 conditions ($\Delta\text{Cost} = -0.59$) due to incumbent plateauing and low yield from retained checkpoints.
  - **E5 (Progress Features):** Mean $\Delta\text{Cost} = -2.49$ (CI: `[-6.48, +0.14]`).
  - **E6 (Protocol B Baseline Comparison):** Published BALANCE achieves lower cost (-232.65 points, CI: `[-434.78, -72.16]`), but overran deadlines on 79.2% of runs (76/96, max overshoot 5.65 ms). RouteBudget Lab achieved 0.0% overshoot rate (100.0% zero-overshoot compliance within $\le 1.0\ \mu$s tolerance).

### 3. Engine Bug Fix & Clean Build Verification
- Resolved engine issue in `src/engine/rbl_resumable_engine.cpp`: `resumeCheckpoint` was resetting `outcome.repeated_expansions = 0` instead of carrying forward `cp->repeated_expansions`. Corrected to `outcome.repeated_expansions = cp->repeated_expansions;`.
- Clean test builds verified: 7/7 CTest tests pass in `build/bench-release` (1.87s).

### 4. Phase 8 Replay Exporter, Viewer, & Automated Regression Suite
- Generated all 768 self-contained, versioned JSON replays (`results/phase8/replays/*.replay.json`) via `scripts/export_replays.py` with catalog index `results/phase8/replays/replays_index.json`.
- Implemented standalone offline HTML5 Canvas replay viewer in `viewer/` with zero external CDN dependencies, non-square map rendering, stay-at-goal simulation, speed controls, agent inspection HUD, and empty filter protection.
- Developed automated test suite `tests/test_viewer_and_replays.py` verifying manifest/index parity, coordinate bounds, obstacle clearance, makespan validity, stay-at-goal occupancy collision checks, cryptographic SHA-256 matches, and empty/corrupted file handling. All 5/5 test groups passed (100%).
- Updated distribution packaging script `scripts/package_archive.sh` to package code, tests, documentation, verified manifest, statistical analysis, and all 768 replays.

### 5. Final Project Status & Academic Demarcation
- **Status:** **ALL 8 PHASES COMPLETED, AUDITED, AND VERIFIED.**
- Implementation, experimental evaluation, automated verification, and reproducible packaging are complete. Dissertation writing, document preparation, and university thesis submission remain independent academic activities outside software development.


