# Decisions log

## D1 — Backbone: `thomyphan/anytime-mapf` (BALANCE), commit `47bb25e9`

**Candidates inspected (cloned 2026-10-21, shallow):**

| Repo | Commit | Licence | Notes |
|---|---|---|---|
| thomyphan/anytime-mapf | 47bb25e9 (2023-12-15) | USC research licence (`license.txt`) | MAPF-LNS2 lineage, ~5.0k lines in `src/*.cpp`; ships `random-32-32-20` map+scen; Boost + Eigen only |
| JimyZ13/ADDRESS | b3d35c43 (2025-05-28) | same USC licence | Same lineage, extends BALANCE (~5.9k lines); more code to maintain |
| thomyphan/counterfactual-mapf-lns | 02f091a3 (2025-11-14) | **no licence file found** | Cannot safely modify/redistribute |
| ChristinaTan0704/mapf-lns-unified | d8fab81b (2025-08-17) | none found | Python/NN/SVM tooling, not a plain C++ backbone |

**Why anytime-mapf:** smallest of the buildable, licensed options; ADDRESS and
TACKLE are built on it so it stays comparable for E6. Repair solver is the
standard PP + SIPP / space-time A* (`LNS.cpp`, `SIPP.cpp`, `SpaceTimeAStar.cpp`).
ADDRESS stays as an *unmodified* separate baseline for E6 only.

**Licence:** research/non-profit use and modification is permitted if copyright
notice and licence text are kept. Kept verbatim in `third_party/anytime-mapf/license.txt`.
Redistribution rules to be rechecked in Phase 8.

**Vendoring:** a snapshot (no upstream `.git`) is copied into `third_party/anytime-mapf/`.
Phase 1 does not modify it. Later modifications will be recorded as a diff against the pinned commit.

## D2 — Compiler on this Mac
Xcode licence is not accepted, so `/usr/bin/g++`, `git` shims and `brew` refuse to run.
`scripts/build_baseline.sh` calls Command Line Tools clang directly with `SDKROOT`.
Needs no sudo. (The user may still run `sudo xcodebuild -license accept` to remove the need.)

## D3 — Eigen vendored
`brew install eigen` was blocked by the same licence issue. Eigen 3.4.0 (header-only, MPL2)
is downloaded to `third_party/eigen` (tarball SHA-256 `8586084f71f9bde545ee7fa6d00288b264a2b7ac3607b974e54d13e7162c1c72`).

## D4 — Upstream quirks found
- `--maxIterations` defaults to **0**, so the README command stops after one LNS iteration
  (observed: 0.006 s run). Always pass `--maxIterations=1000000`.
- Upstream builds with `CMAKE_CXX_STANDARD 14`; the proposal says C++17. Left unchanged for the pristine baseline; to be raised when our own code is added (Phase 3).
- Upstream includes `<eigen3/Eigen/Core>`; handled with a symlinked include dir, not by editing source.
- Boost is 1.92 (upstream tested 1.81); it still builds.

## D5 — Gate 1 Feasibility Verdict: Adopt Macro-Prefix Checkpointing (Fallback 1A)
- **Feasibility Spike Audit & Overhead Breakdown:** Audited in `src/profiler/profile_checkpoint_feasibility.cpp` and recorded in `results/profiling/checkpoint_feasibility.json`.
  - Micro-frontier snapshot latency is 678.3 $\mu$s at 10,000 nodes (670.4 KB heap), which is 6.78% of a 10 ms slice in isolation (< 10%). Earlier preliminary reports of 429.3 $\mu$s were 4.29% of 10 ms. Frontier snapshotting does NOT fail the 10% target in isolation.
  - However, when factoring in restore latency (762.7 $\mu$s), the combined save+restore cost is 1,440.9 $\mu$s (14.41% of 10 ms, 28.82% of 5 ms).
  - Crucially, micro-frontier cloning was a synthetic container-copy benchmark; in the live solver, raw node parent pointers, FOCAL heap pairing handles, and dynamic allocations introduce severe pointer invalidation and sanitizer overhead.
  - Macro-prefix checkpointing achieves low latency (0.34–1.15 $\mu$s on synthetic container benchmarks across $|N| \in [4, 32]$, representing $<0.012\%$ of a 10 ms slice: specifically 0.34 $\mu$s at $|N|=4$, 0.67 $\mu$s at $|N|=16$, and 1.15 $\mu$s at $|N|=32$; and 3.92 $\mu$s in live Release integration / 15.62 $\mu$s under ASan), small memory footprint (1.4–7.6 KB synthetic, 1.0 KB live measured vs 670 KB), and clean C++ value semantics (`std::vector<Path>`).
  - Fallback 1A was therefore adopted for simpler ownership, lower engineering complexity, and avoiding raw pointer hazards, not because single-shot frontier snapshotting exceeded 10%.
- **Repair Outcome Separation:** Audited in `src/profiler/profile_repair_outcomes.cpp` and `scripts/profile_repair_outcomes.py` across all 4 training partition maps:
  - In unconstrained search, 0% of repairs time out. 64%–100% of iterations are non-improving (`COMPLETED_NOT_IMPROVING`), which is standard LNS neighborhood rejection, NOT timeout or failure.
  - Slices cut off primarily during dense, long-tail repairs (`maze-32-32-2`, 100 agents), where 30%–40% of repairs exceed 5–10 ms.
  - Potentially reusable prefix existence: across all sampled configurations, in 43 / 43 (100%) of interrupted cases, at least one agent had finished routing ($r_{done} \ge 1$, `has_reusable_prefix = true`). This indicates prefix availability, not a proven solution quality benefit; RQ1 evaluates whether prefix reuse improves solution quality over restart ($K=0$).
- **Verdict:** Gate 1 is PASSED (CONDITIONAL on Macro-Prefix Fallback 1A).

## D6 — Phase 3: Macro-Prefix Resumable Repair Engine & Experiment E1
- **Checkpoint Contract:** State tuple $C_i = \langle \text{id}, \text{state}, \mathcal{N}_i, \text{ord}(\mathcal{N}_i), r_{done}, P_{done}, P_{old}, c_{old}, v_{inc}, v_{agents}, \text{seed}_{unfinished}, t_{active}, \text{exp}_{active}, \text{exp}_{repeated} \rangle$.
- **Cooperative Slice Handling:** Implemented inside low-level Space-Time $A^*$ (`budget.checkNodeExpansion()`) and between agents (`budget.checkAgentBoundary()`). Unfinished agent's frontier is discarded in macro-prefix mode and restarted from scratch on resumption, while completed prefix $P_{done}$ is preserved. Repeated node expansions upon restart are explicitly measured and accumulated.
- **Transactional Incumbent Isolation:** Incumbent paths are never mutated in-place during repair attempts; candidate paths reside in isolated candidate vectors and are only committed if $c_{new} < c_{old}$.
- **Bounded Checkpoint Store:** Configurable capacity $K \in \{0, 1, 2\}$ with deterministic FIFO eviction, lifecycle states (`EMPTY, ACTIVE, SUSPENDED, COMMITTED, DISCARDED, EXPIRED`), and memory calculation.
- **Buffer Overflow Diagnosis ($t=0$):** Upstream `PathTable::constrained(from, to, to_time)` accesses `table[to][to_time - 1]` without asserting `to_time > 0`. Calling it at $t=0$ produced out-of-bounds indexing (`data()[-1]`). Handled safely in `rbl_resumable_engine.cpp` by directly querying `table[loc][0]` and `goals[loc] <= 0`.
- **Baseline Fixture Reconciliation:** The regression fixture `tests/fixtures/real/baseline_50agents_seed0.paths` achieved cost 1147 under Thompson bandit selection (`--banditAlgo=Thompson --neighborCandidateSizes=5`, SHA256: `1029deda...`), verified independently by `rbl_validate --reported-cost 1147`. Default Random bandit achieves cost 1155. Both are valid.
- **Experiment E1 Verification:** Automated test suite `tests/e1_resumption_tests.cpp` executes 10 test categories: uninterrupted baseline, interruption at agent boundary with cell-by-cell path equality, mid-search cutoff with frontier discard and repeated work recording, repeated interruption on same difficult agent, interruption before prefix, multiple pause/resume cycles, store lifecycle ($K=0, 1, 2$), global deadline expiry (`STOPPED_DEADLINE`), independent path validation (`rbl_validator`), and live integrated performance (save: $0.79\ \mu$s Release / $3.75\ \mu$s ASan; restore: $3.12\ \mu$s Release / $11.88\ \mu$s ASan; combined: $3.92\ \mu$s Release; memory: 1024 bytes). 100% passing in both Release and ASan/UBSan modes.

## D7 — Phase 4: Two-Stage Conservative Constraint Compatibility Validator (Component 2: O3, FR-03, RQ2, E4)
- **Problem:** When an interrupted checkpoint $C_i$ is suspended in the manager, subsequent repair iterations may accept modifications to the incumbent solution. Stale checkpoints can cause collisions or invalid heuristic assumptions if resumed without validation.
- **Theoretical Scope Distinction:** Because macro-prefix mode discards the unfinished search frontier, compatibility validation is strictly defined and proven for the *concrete prefix trajectories actually retained* ($P_0, \dots, P_{r_{done}-1}$). We do NOT claim that this establishes correctness for an unexpanded frontier checkpoint (which would require re-evaluating heuristic admissibility and dynamic reservation intervals).
- **Two-Stage Validation Contract:**
  1. **Stage 1 (Fast $O(|A|)$ Version Check):** If `cp.incumbent_version == current_incumbent_version`, no incumbent trajectories have changed. Checkpoint is immediately compatible with sub-microsecond latency ($0.04 - 0.38\ \mu$s).
  2. **Stage 2 (Spatio-Temporal Reservation & Constraint Check):**
     - *Check 1 (Overlapping Neighborhood Mutations):* If any agent $a \in \mathcal{N}_i$ was replanned in an intervening iteration (`current_agent_versions[a] != cp.agent_versions_at_save[a]`), the neighborhood structure is invalidated. Verdict: `DISCARD_NEIGHBORHOOD_MUTATED`.
     - *Check 2 (Cost Bound Pruning):* If the accumulated prefix cost $c(P_{done}) \ge \text{cost}_{current}(\mathcal{N}_i)$, no strict improvement is possible. Verdict: `DISCARD_COST_BOUND_EXCEEDED`.
     - *Check 3 (Spatio-Temporal Collision Detection):* Compares each retained prefix path against each modified external agent ($a \notin \mathcal{N}_i$ where version changed) across all timesteps:
       * Vertex collision: `DISCARD_VERTEX_CONFLICT`
       * Edge swap: `DISCARD_EDGE_SWAP`
       * Stay-at-goal occupancy: `DISCARD_STAY_AT_GOAL`
  3. **Policy 0 vs Policy 1:** Policy 0 (Discard-on-Change) unconditionally discards checkpoints whenever `cp.incumbent_version != current_incumbent_version`. Policy 1 (Selective Retention) runs Stage 2 and retains compatible checkpoints.
  4. **Reservation Rebuilding & Independent Validation:** Upon resuming a compatible checkpoint, reservations for $\mathcal{N}_i$ are rebuilt from current external paths and retained prefix paths. Completed candidate solutions are re-evaluated against the *current* incumbent cost, and independently validated prior to commitment.
- **Experiment E4 Verification:** Automated test suite `tests/e4_compatibility_tests.cpp` executes 8 test categories: unchanged context, irrelevant changes, vertex conflicts, edge swap & stale reservation clearing, stay-at-goal occupancy, overlapping neighborhood repairs, cost ceiling pruning, and comprehensive policy comparison. 100% passing in both Release and ASan/UBSan modes with 0 invalid commits.

## D8 — Phase 5: Search-Progress Feature Extraction & Remaining-Work Estimator (Component 3: O4, FR-04, WP4)
- **External Perturbation vs Production Invariant:** `commitExternalTrajectory(agent, new_path, allow_worsening = true)` explicitly guarded. In normal planner operation (`allow_worsening = false`), paths that worsen solution cost or create collisions are rejected. The perturbation flag is strictly reserved for compatibility and stress-testing harnesses (Experiment E4).
- **Decision-Time Feature Contract (13 Features):** Features are strictly extracted prior to executing fresh or resumed repairs.
  - Action characteristics: `action_type` (0.0 fresh, 1.0 resumed), `neighborhood_size` ($|A_c|$), `completed_prefix_ratio` ($r_{done} / |A_c|$).
  - Search progress & repeated work: `cumulative_expansions`, `cumulative_active_time_s`, `repeated_expansions` (work discarded at cutoff needing re-expansion).
  - Neighborhood context & heuristic lower bounds: `remaining_agents_count` ($|A_c| - r_{done}$), `remaining_agents_lowerbound_cost` (Manhattan lower bound sum of unrouted agents), `current_neighborhood_cost` (incumbent sum of costs), `prefix_cost_ratio` (prefix cost / neighborhood cost).
  - Environment congestion & budget: `local_congestion_density` (external paths in spatial bounding box / cell count), `requested_slice_duration_s` ($\Delta \in [0.002, 0.050]$ s), `remaining_global_budget_ratio` ($b_k / B$).
- **Open-List Contract Compliance:** In macro-prefix mode, the unfinished low-level search frontier is discarded upon suspension. A live open-list size does NOT exist for a saved checkpoint. In strict compliance with the contract, live open-list size is omitted.
- **Targets Defined:**
  - Target A: Expected Accepted Improvement $\hat{E}[\text{AcceptedImprovement}(a, \Delta)]$, relative to the decision-point incumbent ($= 0.0$ if non-improving, interrupted, or failed; $> 0$ only if accepted).
  - Target B: Expected Active Search Time $\hat{E}[\min(T_{rem}, \Delta)]$, censored at $\Delta$ for slice interruptions. Overhead (validation, saving, restoration) is strictly separated from low-level search time.
- **Trace Collection & Partition Isolation:** Real traces collected via `rbl_collect_traces` on Moving AI benchmark partitions:
  - Training dataset (`results/traces/training_traces.csv`): 1,280 samples across 4 training maps (`random-32-32-20`, `empty-32-32`, `maze-32-32-2`, `warehouse-10-20-10-2-1`). Fresh: 1,159, Resumed: 121. Outcomes: 42 accepted, 1,103 non-improving, 135 interrupted.
  - Validation dataset (`results/traces/validation_traces.csv`): 640 samples across 2 validation maps (`random-64-64-10`, `warehouse-10-20-10-2-2`). Fresh: 529, Resumed: 111. Outcomes: 0 accepted, 516 non-improving, 124 interrupted.
  - Held-out test maps kept 100% untouched.
- **Honest Model Evaluation & Zero-Inflation Audit:**
  - Target A label distribution: 96.72% zero in training, 100% zero in validation (due to near-optimal prioritized planning initializations). Trivial zero-predictors achieve deceptive low MAE simply because improvements are rare. Ridge regression over-predicts improvements on unseen maps (Validation MAE: 0.524 vs 0.423 for Tabular).
  - Target B prediction: Simple Tabular baseline achieves lower MAE (**0.66 ms**) on held-out validation maps than fitted Ridge regression (0.94 ms) or Constant baseline (0.78 ms).
  - Decision: Per project guidance, the simple Tabular baseline is retained as a primary estimator choice rather than forcing a complex linear model that underperforms on held-out instances.
- **C++ Inference Engine & Numerical Parity (`src/engine/rbl_estimator.hpp`):**
  - Fully implemented C++ estimator supporting `RIDGE_REGRESSION`, `TABULAR_BASELINE`, and `CONSTANT_BASELINE`.
  - Compiled-in default weights, parameters, and deterministic fallback for missing model files or non-finite inputs (NaN, Inf).
  - Exact numerical parity: C++ predictions match Python `scikit-learn` output to within $< 10^{-5}$ error across all verification cases.
  - Latency: Measured at **$0.0744\ \mu\text{s}$ per inference** (over 1300x faster than the $0.1\ \text{ms}$ proposal target).

## D9 — Phase 6: Overhead-Aware Resume-or-Start Controller & Gate 2 Audit (Component 4: O4, FR-05, WP4)
- **Proposed Scoring Equation Integration:**
  $$\text{Score}(a, \Delta) = \frac{\hat{E}[\text{AcceptedImprovement}(a, \Delta)]}{\hat{E}[\min(T_{\text{rem}}(a), \Delta)] + \widehat{\text{Overhead}}(a)}$$
  subject to strict admissibility:
  $$\Delta + \widehat{\text{Overhead}}(a) + t_{\text{reserve}} \le b_k$$
  where $b_k$ is the current remaining global wall-clock budget and $t_{\text{reserve}}$ (default 1.0 ms) safeguards against deadline overshoot.
- **Overhead Accounting & Cost Separation:**
  - Incurred overhead (prior validation, candidate generation, feature extraction, scoring) is treated strictly as elapsed wall-clock time already deducted from $b_k$.
  - Prospective overhead $\widehat{\text{Overhead}}(a)$ accounts only for expected future costs: prospective restore/init latency plus conditional checkpoint-saving cost ($p_{\text{interrupt}} \cdot \hat{t}_{\text{save}}$).
  - Eliminates double-counting of search overheads.
- **Strict Monotonic Wall-Clock Accounting:**
  - Governed by `std::chrono::steady_clock` monotonic time throughout.
  - Remaining budget $b_k$ refreshed immediately before execution.
  - Recheck before commit: if low-level search or independent validation finishes after deadline $B$, candidate is rejected (`REJECTED_LATE_COMMIT`) and incumbent is strictly preserved.
  - Recheck before saving: checkpoints are not written if global budget is exhausted.
- **Three Matched Policy Controls:**
  - `RESTART_ONLY_K0`: $K=0$, fresh repairs only, fixed slice (10 ms).
  - `FIXED_FIFO_RESUME`: $K=2$, unconditional FIFO resumption whenever a compatible checkpoint exists, fixed slice (10 ms).
  - `SCORE_BASED_ADAPTIVE`: $K=2$, score-based resume-or-start selection across candidate actions and candidate slices $\Delta \in \{0.002, 0.005, 0.010, 0.020, 0.050\}$ s.
  - Neighborhood selection, agent counts, instances, and total wall-clock budgets are held strictly identical to isolate controller decision effects.
- **Handling Weak Predictions & Stagnation Eviction:**
  - Given the zero-positive-validation finding from Phase 5, when all predicted improvements are zero, the controller deterministically invokes a documented fallback policy: prioritizes compatible resumed actions with highest completed prefix ratio $r_{\text{done}} / |A_c|$, and allocates the smallest admissible slice $\Delta$ to conserve budget.
  - Macro-prefix mode discards the unfinished agent's frontier upon interruption. When repeated resumptions of a checkpoint fail to advance $r_{\text{done}}$ for $\ge 2$ consecutive attempts, the checkpoint is evicted (`stagnant_checkpoints_evicted`), bounding wasted computation. All repeated expansions upon restart are measured and recorded.
- **Gate 2 Integration & Overhead Audit (`docs/gate2_results.json`):**
  - Evaluated on training maps (`random-32-32-20` and `warehouse-10-20-10-2-1`) under $B=1.0$ s deadline; held-out test maps kept 100% untouched.
  - Complete Decision Pipeline Latency (including candidate generation, compatibility checks, feature extraction for all actions $\times$ slices, estimator queries, and scoring) measured at:
    - Median: **$15.83\ \mu\text{s}$ (0.016 ms)**
    - P90: $39.75\ \mu\text{s}$ (0.040 ms)
    - P95: $74.67\ \mu\text{s}$ (0.075 ms)
    - P99: $200.92\ \mu\text{s}$ (0.201 ms)
    - Proposal target $\le 1.0\ \text{ms}$ is comfortably satisfied (even P99 is $\sim 5\times$ faster than target).
  - Solution validity: 100% collision-free verified by independent whole-plan collision check across all policies and runs.
  - Deadline overshoot: 0.00 ms (zero late commits accepted; incumbent strictly preserved).
  - Repeated work: `FIXED_FIFO_RESUME` incurred 75.2%–88.7% repeated work due to blind resumption, whereas `SCORE_BASED_ADAPTIVE` incurred 0.0%–36.1% repeated work.
  - Gate 2 Verdict: **PASSED**.

## D10 — Phase 7: Evaluation Protocol Freeze and Matched Experimental Matrix (E1–E6)
- **Protocol Freeze Status:** FROZEN prior to executing any evaluations on the four designated held-out test maps.
- **Held-Out Test Partitions:**
  1. `warehouse-20-40-10-2-1` (large warehouse topology, 10x20 blocks, narrow corridors)
  2. `random-64-64-20` (dense random obstacle grid, 64x64, 20% obstacles)
  3. `room-64-64-8` (64x64 grid partitioned into 8x8 rooms with 1-cell doorways)
  4. `ost003d` (Dragon Age benchmark map, organic open/chokepoint terrain)
  The remaining six maps remain strictly training/validation data.
- **Component Separation & Matched Controls (RQ1, RQ2, RQ3):**
  To avoid confounding action-selection effects with slice-duration adaptation, the following matched controls are established:
  1. `RESTART_ONLY_K0`: $K=0$, fixed 10 ms slice, fresh repairs only. Baseline for E2.
  2. `FIXED_FIFO_RESUME`: $K=2$, fixed 10 ms slice, FIFO resumption. Baseline for E2 and E3.
  3. `SCORE_BASED_FIXED`: $K=2$, matched fixed 10 ms slice, score-based resume-or-start selection. Isolates scoring effect in E3 from slice adaptation.
  4. `SCORE_BASED_ADAPTIVE`: $K=2$, variable slice grid $\Delta \in \{2, 5, 10, 20, 50\}$ ms. Isolates slice-selection effect when compared against `SCORE_BASED_FIXED`.
  5. `ELAPSED_TIME_ONLY`: $K=2$, variable slice grid, search-progress features masked to zero (elapsed time only). Primary ablation for E5.
  6. `DISCARD_ON_CHANGE`: $K=2$, variable slice grid, Policy 0 (unconditional discard on incumbent change). Primary ablation for E4.
  7. `BALANCE`: Upstream baseline executable (`build/baseline-release-cxx14/balance`), evaluated on identical map/scenario instances for E6.
- **Execution Matrix & Protocol Reduction Rationale:**
  - The theoretical matrix of 600 runs per budget per method across 4 budgets and 7 configurations yields 16,800 runs (~215 CPU hours).
  - Protocol reduction: Stratified sampling of 3 scenarios per map (scenarios 1, 2, 3), 4 test maps, 2 agent scales (50 and 100 agents), across all 4 budgets (1s, 5s, 10s, 30s) = 24 scenario-agent pairs $\times$ 4 budgets = 96 evaluation benchmark conditions $\times$ 7 methods = 672 total runs.
  - Initial solutions are computed via `InitLNS` (PIBT/PPS) and cached in `results/experiments/init_paths/`, guaranteeing 100% identical starting points for all compared algorithms.
  - Multi-process parallel execution across CPU cores with resumable JSON caching.
- **Statistical Testing:**
  - Paired comparisons on identical instances.
  - Two-sided Wilcoxon signed-rank test and paired Student's t-test.
  - Effect size via Cohen's $d$ and Cliff's $\delta$.
  - 95% Confidence Intervals via 1,000 bootstrap resamples.
  - Multiple comparison correction: Holm-Bonferroni adjusted $p$-values.
  - Zero-prediction fallback and failures explicitly tracked and reported.

## D11 — Phase 7: Validation Defect Correction, Clock Semantics Audit & Sequential Protocol Separation
- **Validation Flaw Correction:**
  - Flaw: Previous scripts utilized `status = 'PASS' if 'VALID' in out else 'FAIL'`, which unsafely allowed strings like `"INVALID"` or `"INVALID_PLAN"` to pass as valid.
  - Correction: Implemented `safe_validator.py` enforcing validator exit code == 0, strict JSON decoding, exact `status == "VALID"`, and reported cost match. Verified via 6-part regression suite (`tests/test_safe_validation.py`). All 24 initial plan fixtures and 4 representative final solutions were revalidated and independently verified as `VALID` (100%). Runs without retained paths are explicitly marked `UNVERIFIED_PATH_NOT_RETAINED`.
- **Clock Semantics & Timing Boundaries:**
  - Audited upstream `anytime-mapf` (BALANCE): confirmed that outer LNS budget loop cutoff uses `std::chrono::high_resolution_clock` wall-clock time. Internal `clock()` references are purely diagnostic counters for low-level subroutines. Both RBL and BALANCE operate on wall-clock time.
- **Protocol Separation:**
  - **Protocol A (Controlled Refinement):** Evaluates internal algorithmic contributions (E2–E5) starting from identical, hash-verified initial plan fixtures. Initial solution generation time is excluded from the refinement budget.
  - **Protocol B (End-to-End Planning):** Evaluates overall system capability against published BALANCE (E6). Both systems generate their initial solutions on-the-fly and charge initialization to the budget.
- **Sequential Reference Benchmark (256 runs):**
  - Executed strictly sequential single-worker reference runs across 4 held-out test maps, Scenario 1, 2 agent scales (50, 100), 4 budgets (1.0s, 5.0s, 10.0s, 30.0s), and 8 configurations (192 Protocol A + 64 Protocol B). 100% completed, zero failures, zero timeouts.
  - Maintained separate from the archived 672-run concurrent batch (`results/phase7/concurrent_batch/`).

## D12 — Phase 7: Trajectory Retention, Provenance Auditing, Matched Deadline Metrics & Clustered Sensitivity Analysis
- **Independent Validation Provenance & Retention Architecture:**
  - Audited previous validation claims: the 4 sample solutions in `sample_final_validation` originated from separate exploratory reruns and cannot retroactively validate earlier runs. Validation evidence must link directly to an exact run identity and retained trajectory hash.
  - Configured native trajectory retention for both solvers outside the planning timer:
    * BALANCE: invokes native `--outputPaths <file>` which writes trajectories via `LNS::writePathsToFile` after `lns.run()` returns (0 planning overhead). Coordinates are `(row, col)`, validated with `coords_xy=False`.
    * RouteBudget Lab: invokes `--dump-final-paths <file>` which writes Moving AI trajectories via `saveMovingAIPathsToFile` after `controller.run()` completes (0 planning overhead). Coordinates are `(col, row)`, validated with `coords_xy=True`.
  - Recompiled Release binaries in `build/bench-release/` ensuring full coordinate parity with Moving AI format.
  - Established `scripts/run_phase7_verified_reference.py` with immediate post-run SHA-256 hashing and independent validation using `safe_validator.py` (`rbl_validate`).
  - Separated run accounting into 4 explicit categories: (1) Process completions, (2) Solver-reported valid, (3) Independently validated retained trajectories, and (4) Unavailable trajectories (`UNVERIFIED_PATH_NOT_RETAINED`).
- **Scenario Coverage Transparency & Reference Design:**
  - Preceding protocol specified 3 scenarios per map, but the sequential reference batch evaluated only Scenario 1.
  - Reason established: `scripts/run_phase7_sequential.py` set `SCENARIO_IDS = [1]` to limit single-worker sequential runtime to ~49.4 minutes instead of running all 3 scenarios (~2.5 hours).
  - Protocol definition: The authorized reference design is 4 maps $\times$ 3 scenarios $\times$ 2 agent counts $\times$ 4 budgets $\times$ 8 configurations = 768 runs. The single-scenario batch is strictly designated as "Preliminary Single-Scenario Sequential Benchmark (Scenario 1)".
  - Execution constraint: Sequential single-process execution of 768 runs requires ~2.5 hours. Replacement reference runs with trajectory retention and independent validation are executed in `results/phase7/verified_reference/`. Concurrent and sequential datasets are strictly never merged.
- **Deadline Reporting Corrections & Clock Monotonicity:**
  - Removed all unsupported claims:
    * Removed claim that sequential execution eliminates scheduling jitter, OS preemption, or core migration (it reduces process contention, but cannot eliminate OS scheduling jitter or background preemption).
    * Removed claim that RBL guarantees deadline compliance.
    * Removed claim that a 0.5 ms reserve guarantees timely completion.
    * Documented the observed 11.8 ms overshoot on `room-64-64-8` at 30.0s, which proves that a prospective reserve margin ($t_{\text{reserve}} = 0.5$ ms) reduces overshoot frequency but does not provide a hard mathematical guarantee.
  - Clock monotonicity verification: compiled and ran clock inspection on Apple Clang 17 libc++. Verified `std::chrono::high_resolution_clock::is_steady == 1` and `std::chrono::steady_clock::is_steady == 1` (both are identical monotonic steady clocks in libc++).
  - Matched Protocol B Deadline Comparison: Compared exactly matched Protocol B runs (96 runs of `BASELINE_BALANCE` vs 96 runs of `RBL_END_TO_END`). RBL achieved 0.00 $\mu$s mean overshoot (0.0% overrunning > 1 $\mu$s, 100.0% compliance), whereas BALANCE exhibited 224.79 $\mu$s mean overshoot (79.2% overrunning > 1 $\mu$s; max 5.65 ms).
- **Clustered Bootstrap & Leave-One-Map-Out (LOMO) Sensitivity Analysis:**
  - Conditions sharing a map and scenario across multiple budgets are not independent replicates. Implemented cluster bootstrap resampling at the map level ($B = 5,000$).
  - Cluster-by-map bootstrap 95% CI for E2 (Resumption effect) spans zero across all 96 conditions: `[-9.30, +52.15]`.
  - Leave-One-Map-Out sensitivity reveals that the overall +13.36 mean improvement is overwhelmingly driven by `ost003d` (+71.46 points). When `ost003d` is omitted, the mean difference drops to **-6.00 points** (a net loss).
  - Replaced "statistically significant and supported" with the qualified descriptive finding:
    *"FIFO resumption achieved a positive average improvement in the evaluated sample, concentrated on ost003d."*
- **Mechanistic Telemetry Explanation for E4 Ties:**
  - Telemetry audit revealed that internal execution differed between `DISCARD_ON_CHANGE` and `SCORE_BASED_ADAPTIVE` (e.g. decision counts, resumed actions, and discards).
  - Because repair yields are low, saved checkpoints predominantly reached stagnation age without discovering lower-cost global incumbents than fresh repairs, resulting in nearly identical final plateau costs ($\Delta = -0.59$, 86 ties, 3 wins, 7 losses across 96 conditions).
- **Completion & Verification Status:**
  - All 768 reference runs completed sequentially with 100% retained `.paths` files on disk, cryptographic SHA-256 hashes, and 100% independent validation pass rate via `safe_validator.py` (`rbl_validate`).
  - Phase 7 evaluation and Phase 8 offline replay viewer and packaging are fully completed, audited, and verified.


