# IMPLEMENTATION_STATUS

Last updated: 2026-10-21. Only real, executed results and verified empirical evidence are recorded here.

| Phase | Status | Key Artifacts & Verification |
|---|---|---|
| **Phase 1: Environment and Baseline** | **COMPLETED & VERIFIED** | Pristine BALANCE backbone vendored @ `47bb25e9` with hash manifest (`UPSTREAM_FILES.sha256`); Eigen 3.4.0 vendored; C++14 reference, C++17, and ASan/UBSan builds verified (`scripts/build_baseline.sh`); exit codes tracked in `logs/exit_codes.tsv`. Smoke runs executed with zero ASan/UBSan reports. Baseline fixture pinned to Thompson bandit run with cost 1147 (`tests/fixtures/real/baseline_50agents_seed0.paths`, SHA256 `1029deda...`). |
| **Phase 2: Data, Validator, Telemetry, Gate 1** | **COMPLETED & VERIFIED (AUDITED)** | Full independent C++17 plan & collision validator (`rbl_validate`); 54 unit assertions + 4000 randomized plans matching naive pairwise oracle; Moving AI data downloaded, verified, partitioned (10 maps, 250 scenarios); checkpoint spike audited (0.34–1.15 $\mu$s synthetic); repair outcomes separated across 5 distinct states; Gate 1 passed with Fallback 1A (`docs/gate1-feasibility-report.md`). |
| **Phase 3: Resumable Repair Engine & E1** | **COMPLETED & VERIFIED** | Macro-Prefix Resumable Repair Engine implemented (`src/engine/`); cooperative slice interruption inside Space-Time $A^*$ and between agents; bounded checkpoint store ($K \in \{0, 1, 2\}$) with lifecycle states and FIFO eviction; transactional incumbent rollback; Experiment E1 automated suite (`tests/e1_resumption_tests.cpp`) passing 100% (10/10 test categories) with independent validation under both Release and AddressSanitizer/UBSan. Live integrated latency: $3.92\ \mu$s (Release) / $15.62\ \mu$s (ASan); memory: 1024 bytes (1 KB). |
| **Phase 4: Constraint Compatibility & E4** | **COMPLETED & VERIFIED** | Two-stage conservative constraint compatibility validator implemented (`src/engine/rbl_constraint_validator.hpp`, Component 2); Stage 1 fast $O(|A|)$ version check ($0.04 - 0.38\ \mu$s latency) + Stage 2 spatio-temporal check (vertex conflicts, edge swaps, stay-at-goal occupancy, cost ceiling, overlapping repairs); reservation rebuilding from current external paths and retained prefix; independent validation before commit; Experiment E4 suite (`tests/e4_compatibility_tests.cpp`, 8 test categories) passing 100% in Release and ASan/UBSan with 0 invalid commits. |
| **Phase 5: Remaining-Work Estimator** | **COMPLETED & VERIFIED** | Guarded `commitExternalTrajectory` (controlled perturbation/testing API with production worsening rejection); 13 decision-time features extracted for both fresh repairs and resumed checkpoints (live open-list omitted as required by macro-prefix contract); real trace collector (`rbl_collect_traces`) executed on training partition (1280 samples) and validation partition (640 samples); honest evaluation of constant, tabular, and fitted Ridge models; zero-inflation audit (96.7% zero labels); Tabular baseline retained as superior predictor for search time (0.66 ms vs 0.94 ms MAE); C++ inference engine (`src/engine/rbl_estimator.hpp`) with compiled-in weights, deterministic fallbacks, and exact Python/C++ numerical parity (< 1e-5 error); measured C++ inference latency: **0.0744 $\mu$s** (0.000074 ms), well under 0.1 ms target; 6/6 tests passing in Release and ASan/UBSan. |
| **Phase 6: Overhead-Aware Controller & Gate 2** | **COMPLETED & VERIFIED (AUDITED)** | Overhead-Aware Resume-or-Start Controller implemented (`src/engine/rbl_controller.hpp`, Component 4: O4, FR-05, WP4); proposed scoring equation integrated with prospective overhead modeling and safety reserve; strict monotonic wall-clock accounting via `std::chrono::steady_clock`; late commit rejection (`REJECTED_LATE_COMMIT`) with strict incumbent preservation; 3 matched policy modes (`RESTART_ONLY_K0`, `FIXED_FIFO_RESUME`, `SCORE_BASED_ADAPTIVE`); deterministic fallback for all-zero predictions; stagnation eviction for macro-prefix bounded response; 7/7 automated tests passing in Release and ASan/UBSan; Gate 2 audit passed: full decision pipeline latency measured at **median 15.83 $\mu$s** (0.016 ms, well under 1.0 ms proposal target), 100% collision-free validity, 0.00 ms deadline overshoot (`docs/gate2_results.json`). |
| **Phase 7: Controlled Experimental Evaluation** | **SCENARIO 1 VERIFIED EVALUATION COMPLETE; SCENARIOS 2–3 PENDING; PHASE 8 IMPLEMENTATION CAN PROCEED** | Reproducible benchmark environment in `build/bench-release/`; safe independent validator (`safe_validator.py`) verified with 6-part regression suite; 24/24 initial plan fixtures verified `VALID`; clock monotonicity verified on Apple Clang libc++ (`high_resolution_clock::is_steady == 1`); protocol separation enforced: Protocol A (controlled refinement) vs Protocol B (end-to-end); honest run categorization (preliminary 256 runs labeled `UNVERIFIED_PATH_NOT_RETAINED`; verified replacement runs retaining full trajectories with SHA-256 hashes and independent validation passing 256/256); matched Protocol B deadline metrics (RBL 0.00 $\mu$s vs BALANCE 184.37 $\mu$s mean overshoot; 11.8 ms tail overshoot documented on `room-64-64-8` in preliminary batch); clustered bootstrap and leave-one-map-out sensitivity analysis showing resumption advantage heavily concentrated on `ost003d` (+230.00) and negative when omitted (-9.12); mechanistic E4 telemetry explaining plateau ties; qualified answers to approved research questions (RQ1–RQ3). |
| **Phase 8: Offline Replay Interface & Packaging** | **IN PROGRESS — VIEWER IMPLEMENTATION UNBLOCKED ON VERIFIED REPLAYS** | Telemetry exporter, standalone HTML5/JS 2D replay viewer outside timed solver loop, research archive, and final packaging. |

---

## Phase 1 Evidence (Baseline Environment & Verification Gaps)

- **Machine:** MacBook (Apple M3, arm64, 8 GB RAM), macOS 26.3, Apple Clang 17.0.0 (Command Line Tools, SDK MacOSX26.2), CMake 3.31.6, Boost 1.92, Eigen 3.4.0 (MPL2 header-only).
- **Backbone Verification:** `third_party/anytime-mapf` verified byte-identical to upstream commit `47bb25e9ba58b22172e1531cb26f25af8a4531e9` via `scripts/verify_upstream.sh` (SHA-256 hash manifest `UPSTREAM_FILES.sha256`).
- **Toolchain / C++ Standard Verification:**
  - `build/baseline-release-cxx14/balance` (C++14 reference baseline) compiles cleanly.
  - `build/baseline-release-cxx17/balance` (C++17 mode with `-D_LIBCPP_ENABLE_CXX17_REMOVED_RANDOM_SHUFFLE` for Apple libc++) compiles cleanly.
  - `build/baseline-asan-cxx14/balance` (`-fsanitize=address,undefined`) runs with zero memory leaks or errors.
- **Upstream Traps Solved:**
  - Upstream `--maxIterations` defaults to 0; all benchmark harnesses explicitly pass `--maxIterations=1000000`.
  - Non-privileged clang wrapper in `scripts/common.sh` bypasses unaccepted Xcode GUI license prompts without requiring `sudo`.
- **Baseline Fixture Cost Reconciliation:**
  - Upstream BALANCE supports different neighborhood bandit selectors. When executed with `--banditAlgo=Thompson --neighborCandidateSizes=5`, it achieves cost **1147** (`tests/fixtures/real/baseline_50agents_seed0.paths`, SHA256: `1029deda6caf15da5bff5519dcf9dd0826a60aab3c2b0e98ffe2a8569cfbc3a0`, verified independently by `rbl_validate --reported-cost 1147`). With default Random bandit, it achieves cost **1155**. Both runs are valid MAPF solutions; 1147 is pinned as the regression fixture.

---

## Phase 2 Evidence (Data, Validator, Profiling, Audited Gate 1)

### 1. Independent Path & Collision Validator (`rbl_validator.hpp` / `rbl_validate`)
- Completely independent parser and collision checker (zero solver code dependencies).
- Checks:
  - Coordinate bounds, map obstacles, start/destination matching from `.scen`.
  - Valid grid transitions: $\Delta x + \Delta y \in \{0, 1\}$ (Manhattan step or wait; diagonal/jump rejected).
  - Vertex collisions: no two agents occupy the same $(x, y)$ at time $t$.
  - Edge collisions: no two agents traverse the same edge in opposite directions at $t \to t+1$.
  - Stay-at-goal occupancy: finished agents park at their destination and remain physical obstacles for traversing agents.
  - Independent sum-of-costs calculation: $\sum_i \text{arrival\_time}(i)$, verified against solver-reported cost.
- **Coordinate convention discovery:** Upstream solver outputs `(row, col)` rather than `(col, row)`. `rbl_validate` defaults to `(row, col)` for solver paths with `--coords xy` option for fixture/scenario coordinates.
- **Automated Test Suite:**
  - `build/audit-release/rbl_validator_tests` and `build/audit-asan/rbl_validator_tests` run 54 assertions covering valid plans, edge swaps, parked collisions, diagonals, jumps, truncated files, out-of-bounds, duplicate agents, plus 4000 randomized plans matching an exhaustive pairwise oracle (54/54 passed).
  - Real baseline smoke output `tests/fixtures/real/baseline_50agents_seed0.paths` verified: `VALID`, independent cost = 1147 matching solver reported cost.

### 2. Moving AI Benchmark Data & Partition Isolation (DR-01)
- Downloaded official Moving AI zips into `data/raw/` with verified SHA-256 hashes (`mapf-map.zip`, `mapf-scen-random.zip`, `mapf-scen-even.zip`).
- Extracted and verified into strict partition isolation (`data/dataset_manifest.json`):
  - **Training Partition (4 maps, 100 scenarios):** `warehouse-10-20-10-2-1`, `random-32-32-20`, `maze-32-32-2`, `empty-32-32`.
  - **Validation Partition (2 maps, 50 scenarios):** `warehouse-10-20-10-2-2`, `random-64-64-10`.
  - **Held-Out Test Partition (4 maps, 100 scenarios):** `warehouse-20-40-10-2-1`, `random-64-64-20`, `room-64-64-8`, `ost003d`.
- All 10 maps and 250 scenarios verified for valid dimensions, valid characters, and obstacle-free starts/goals via `scripts/verify_datasets.py`.

### 3. Audited Checkpoint Feasibility & Overhead Breakdown
- Feasibility benchmark in `src/profiler/profile_checkpoint_feasibility.cpp` re-audited and stored in `results/profiling/checkpoint_feasibility.json`.
- **Overhead calculations audited:**
  - Macro-Prefix: Snapshot $0.16 - 0.57\ \mu\text{s}$, restore $0.18 - 0.59\ \mu\text{s}$, combined $0.34 - 1.15\ \mu\text{s}$ across $|N| \in [4, 32]$ (**0.003% – 0.012% of a 10 ms slice**), memory footprint $1.4 - 7.6\ \text{KB}$. Live integrated save+restore measures $3.92\ \mu$s (Release) / $15.62\ \mu$s (ASan), with 1024 bytes (1 KB) memory.
  - Micro-Frontier: Snapshot at 10,000 nodes (670 KB) is $678.3\ \mu\text{s}$ (**6.78% of 10 ms slice**, and 429.3 $\mu$s was 4.29%). Snapshot alone does NOT exceed 10%. However, restore is $762.7\ \mu\text{s}$, bringing combined save+restore to **$1,440.9\ \mu\text{s}$ (14.41% of 10 ms, 28.82% of 5 ms)**.
  - Adopting Fallback 1A (Macro-Prefix) is justified by low overhead, small footprint, clean value semantics, and zero dangling pointer hazards.

### 4. Distinct Repair Outcome Profiling Across Training Maps
- Profiled across all 4 training maps (50 and 100 agents) under Unconstrained, 10 ms slice, and 5 ms slice in `src/profiler/profile_repair_outcomes.cpp` (`results/profiling/repair_outcomes_summary.json`):
  - In unconstrained execution, **0% of repairs timed out**. 64%–100% of iterations were non-improving (`COMPLETED_NOT_IMPROVING`). Rejection rate $\ne$ timeout rate.
  - Slices cut off during dense, high-congestion instances (`maze-32-32-2`, 100 agents), where 30%–40% of repairs exceed 5–10 ms.
  - At interruption, across all sampled configurations, in **43 / 43 (100%) of cases**, at least one agent had finished routing ($r_{done} \ge 1$, `has_reusable_prefix = true`). This represents potentially reusable state, not an established performance benefit.

### 5. Gate 1 Verdict
- **Formal Verdict:** **PASSED (CONDITIONAL ON FALLBACK 1A: MACRO-PREFIX CHECKPOINTING)**.
- Documented in `docs/gate1-feasibility-report.md` and `docs/decisions.md` (D5).

---

## Phase 3 Evidence (Macro-Prefix Resumable Repair Engine & Focused E1 Coverage)

### 1. Resumable Repair Engine Architecture (`src/engine/`)
- **State Tuple $C_i$ Contract:** Fully defined in `src/engine/rbl_checkpoint.hpp`:
  $$\langle \text{id}, \text{state}, \mathcal{N}_i, \text{ord}(\mathcal{N}_i), r_{done}, P_{done}, P_{old}, c_{old}, v_{inc}, v_{agents}, \text{seed}_{unfinished}, t_{active}, \text{exp}_{active}, \text{exp}_{repeated} \rangle$$
- **Cooperative Slice Handling:** Implemented in `src/engine/rbl_resumable_engine.cpp`:
  - Checked inside low-level Space-Time $A^*$ expansions (`budget.checkNodeExpansion()`) and between agents (`budget.checkAgentBoundary()`).
  - When budget expires: unfinished agent's open/closed lists are cleanly discarded in macro-prefix mode, completed prefix paths $P_{done}$ are preserved in $C_i$, and incumbent $P_{inc}$ remains unmodified.
- **Resumption Contract:** On resumption under unchanged constraints, reservations for unchanged external agents and completed prefix paths $P_{done}$ are rebuilt into the reservation table, and search restarts cleanly from the unfinished agent with deterministic RNG state. Repeated work upon restarting unfinished search is recorded.
- **Bounded Checkpoint Store:** Configurable $K \in \{0, 1, 2\}$ with lifecycle states (`EMPTY, ACTIVE, SUSPENDED, COMMITTED, DISCARDED, EXPIRED`) and deterministic FIFO eviction. Memory tracked dynamically per checkpoint.
- **Transactional Rollback:** All candidate paths reside in isolated vectors; committed incumbent is only updated when a complete, improving repair is accepted ($c_{new} < c_{old}$).
- **Upstream Buffer Overflow Analysis ($t=0$):** Upstream `PathTable::constrained(from, to, to_time)` accesses `table[to][to_time - 1]` without asserting `to_time > 0`. Calling it at $t=0$ produced out-of-bounds indexing (`data()[-1]`). Arises from querying start-node occupancy via transition checking. Safely handled in `rbl_resumable_engine.cpp` by directly querying `table[loc][0]` and `goals[loc] <= 0`.

### 2. Experiment E1 Focused Coverage (`tests/e1_resumption_tests.cpp`)
- Automated regression suite executing 10 comprehensive test cases on `random-32-32-20`:
  1. `Uninterrupted Baseline`: Baseline cost 101, expansions 432.
  2. `Interruption After 2 Agents & Path Parity`: Interrupted at agent boundary ($r_{done}=2$), resumed under unchanged constraints. Verified exact cell-by-cell path equality against baseline for all agents.
  3. `Interruption Inside Low-Level Search`: Cut off mid-search on agent 1 with 6 active node expansions. Verified completed prefix $r_{done}=1$ survives, unfinished frontier is discarded, agent 1 restarts cleanly with deterministic state, repeated expansions (6) recorded, and final paths match baseline.
  4. `Repeated Interruption on Difficult Agent`: Three consecutive slices too short to finish agent 0. Accurately reports $r_{done}=0$, accumulates 9 discarded expansions, and reports 0 progress without corrupting state.
  5. `Interruption Before Any Prefix`: Interrupted before any agent completes ($r_{done}=0$), candidate discarded, resumed from scratch.
  6. `Multiple Pause/Resume Cycles`: Multiple interruptions and resumptions reach identical solution.
  7. `Bounded Store Eviction ($K=0, K=1, K=2$)`: Verified FIFO eviction order, active/suspended/discarded lifecycle states, and verified that $K=0$ discards state immediately.
  8. `Global Deadline Expiry`: Solver respects global deadline, returning `STOPPED_DEADLINE` with zero state mutations.
  9. `Independent Path Validity`: All final paths independently verified via `rbl_validator`. Status `VALID`, independent cost matches engine reported cost.
  10. `Live Integrated Performance`: Save latency = $0.79\ \mu$s (Release) / $3.75\ \mu$s (ASan), restore latency = $3.12\ \mu$s (Release) / $11.88\ \mu$s (ASan), combined save+restore = $3.92\ \mu$s Release (0.039% of 10 ms slice), retained checkpoint memory = 1024 bytes (1.0 KB).
- **Sanitizer Verification:**
  - `build/audit-release`: Exit code 0, all tests passed (100%).
  - `build/audit-asan`: Exit code 0, all tests passed (100%), 0 memory leaks, 0 heap-buffer-overflows, 0 undefined behavior.

---

## Phase 4 Evidence (Conservative Constraint Compatibility & Experiment E4)

### 1. Two-Stage Validator Architecture (Component 2: `src/engine/rbl_constraint_validator.hpp`)
- Implemented `ConservativeConstraintValidator` and `CompatibilityReport` with explicit diagnostic verdicts:
  - `COMPATIBLE_UNCHANGED`: Fast Stage 1 $O(|A|)$ version check match ($0.29 - 0.42\ \mu$s latency).
  - `COMPATIBLE_PREFIX_VALID` (with `COMPATIBLE_VALIDATED` alias): Stage 2 spatio-temporal reservation check passed against modified external agents.
  - `DISCARD_NEIGHBORHOOD_MUTATED`: Check 1 detected overlapping repair in $\mathcal{N}_i$ in intervening iteration.
  - `DISCARD_COST_BOUND_EXCEEDED`: Check 2 detected prefix accumulated cost $\ge$ current neighborhood incumbent cost.
  - `DISCARD_VERTEX_CONFLICT`: Check 3 detected vertex collision at $(x, y, t)$.
  - `DISCARD_EDGE_SWAP`: Check 3 detected edge swap transition $(u \leftrightarrow v)$.
  - `DISCARD_STAY_AT_GOAL`: Check 3 detected collision with parked external agent at $t \ge t_{goal}$.
  - `DISCARD_POLICY_DISABLED`: Reference Policy 0 (Discard-on-Change) discarded due to incumbent version increment.
- **Explicit Stage Reached Tracking:** `CompatibilityReport` explicitly tracks `stage_reached` (0 = Policy-0 version check only, 1 = Stage 1 version match, 2 = Stage 2 spatio-temporal check) and `modified_external_agents`.
- **Programmatic & Natural Trajectory Update:** `ResumableRepairEngine::commitExternalTrajectory(agent, new_path)` safely verifies start/goal invariants, grid validity, and collision-freedom before updating incumbent paths, bumping agent version, and incrementing incumbent version.
- **Theoretical Scope Justification:** Because macro-prefix mode discards the unfinished search frontier, compatibility validation is strictly defined and proven for the *concrete prefix trajectories actually retained* ($P_0, \dots, P_{r_{done}-1}$). We do NOT claim that this establishes correctness for an unexpanded frontier checkpoint.

### 2. Integration with Resumable Repair Engine
- Updated `rbl_resumable_engine.hpp` and `.cpp` with per-agent trajectory versions (`agent_trajectory_versions`), checkpoint context recording, reservation rebuilding from current external paths and retained prefix, re-evaluation of candidate improvement against the *current* neighborhood cost, and independent final-path validation before commitment.

### 3. Experiment E4 Test Suite Execution (`tests/e4_compatibility_tests.cpp`)
- Automated regression suite executing 8 test categories:
  1. `Unchanged Context`: Stage 1 fast match ($0.29\ \mu$s), compatible under both Policy 0 and Policy 1 (`stage_reached = 1`).
  2. `Irrelevant External Changes`: External agent 8 modified to genuine alternate collision-free trajectory with unchanged start/goal; versions bumped ($V_{inc}: 1 \to 2, v_8: 1 \to 2$); Policy 0 rejects (`DISCARD_POLICY_DISABLED`, `stage_reached = 0`); Policy 1 executes Stage 2 (`stage_reached = 2`), confirms non-conflicting prefix against modified external agent 8, and returns `COMPATIBLE_PREFIX_VALID` ($0.88\ \mu$s); resumption cleanly produces 100% collision-free final solution.
  3. `Conflicting Changes`: Vertex conflict detected at $(x, y, t)$, discarded safely (`DISCARD_VERTEX_CONFLICT`).
  4. `Edge Swap Changes & Removed Reservations`: Edge swap $(u \leftrightarrow v)$ detected and discarded (`DISCARD_EDGE_SWAP`); stale reservations cleanly cleared.
  5. `Changed Goal Occupancy`: Stay-at-goal collision detected and discarded (`DISCARD_STAY_AT_GOAL`).
  6. `Overlapping Neighborhood Repairs`: Intervening repair of neighborhood agent detected and discarded (`DISCARD_NEIGHBORHOOD_MUTATED`).
  7. `Cost Bound Pruning`: Prefix cost $\ge$ current neighborhood cost detected and discarded (`DISCARD_COST_BOUND_EXCEEDED`).
  8. `Comprehensive Policy Comparison`: Evaluated across 20 controlled MAPF scenarios with external perturbations. Policy 0 retained 8 eligible checkpoints; Policy 1 retained 14 eligible checkpoints (75% higher checkpoint retention). Mean validation latency: $0.24\ \mu$s (Policy 0) vs $0.71\ \mu$s (Policy 1). Verified 0 invalid solution commits across all runs.
- **Sanitizer Verification:**
  - `build/audit-release`: Exit code 0, 5/5 tests passed (100%).
  - `build/audit-asan`: Exit code 0, 5/5 tests passed (100%), 0 memory leaks, 0 heap-buffer-overflows, 0 undefined behavior.

---

---

## Phase 5 Evidence (Feature Extraction, Trace Collection, Honest Estimator Evaluation & C++ Inference)

### 1. Controlled Perturbation vs Production Invariant
- Hardened `commitExternalTrajectory(agent, new_path, allow_worsening)` in `src/engine/rbl_resumable_engine.hpp` and `.cpp`:
  - When `allow_worsening = false` (production default), rejects paths that increase solution cost or create collisions.
  - When `allow_worsening = true`, acts as an explicit perturbation testing harness for compatibility evaluation (Experiment E4).

### 2. Feature Contract & Live Open-List Omission
- Implemented `src/engine/rbl_feature_extractor.hpp` defining 13 decision-time features:
  - `action_type`: 0.0 for Fresh repair, 1.0 for Resumed checkpoint [binary].
  - `neighborhood_size`: $|A_c|$ [agent count].
  - `completed_prefix_ratio`: $r_{done} / |A_c| \in [0.0, 1.0]$.
  - `cumulative_expansions`: Node expansions previously spent [count].
  - `cumulative_active_time_s`: Active search time previously spent [seconds].
  - `repeated_expansions`: Node expansions discarded at interruption and needing re-expansion [count].
  - `remaining_agents_count`: $|A_c| - r_{done}$ [agent count].
  - `remaining_agents_lowerbound_cost`: Sum of Manhattan lower bounds for unrouted agents [grid steps].
  - `current_neighborhood_cost`: Sum of incumbent path costs for $A_c$ [grid steps].
  - `prefix_cost_ratio`: Accumulated prefix cost / current neighborhood cost $\in [0.0, 1.0]$.
  - `local_congestion_density`: External trajectories intersecting bounding box / spatial area [agents / cell].
  - `requested_slice_duration_s`: Active search slice allocation $\Delta \in [0.002, 0.050]$ [seconds].
  - `remaining_global_budget_ratio`: Remaining global budget $b_k / B \in [0.0, 1.0]$.
- **Contract Rule on Open-List:** Because Macro-Prefix mode deliberately discards unexpanded open-list nodes upon suspension, reporting a live open-list size for a suspended checkpoint is physically impossible. In strict compliance with the contract, live open list is omitted.

### 3. Trace Collection & Partition Isolation
- Real trace collector `rbl_collect_traces` executed on Moving AI benchmark partitions:
  - **Training Dataset (`results/traces/training_traces.csv`):** 1,280 samples across 4 training maps (`random-32-32-20`, `empty-32-32`, `maze-32-32-2`, `warehouse-10-20-10-2-1`).
    - Action Coverage: Fresh = 1,159 (90.5%), Resumed = 121 (9.5%).
    - Outcomes: Completed & Accepted = 42, Completed Non-Improving = 1,103, Interrupted = 135, Failed = 0.
  - **Validation Dataset (`results/traces/validation_traces.csv`):** 640 samples across 2 validation maps (`random-64-64-10`, `warehouse-10-20-10-2-2`).
    - Action Coverage: Fresh = 529 (82.7%), Resumed = 111 (17.3%).
    - Outcomes: Completed & Accepted = 0, Completed Non-Improving = 516, Interrupted = 124, Failed = 0.
  - Held-out test maps (`warehouse-20-40-10-2-1`, `random-64-64-20`, `room-64-64-8`, `ost003d`) remained 100% untouched.

### 4. Honest Model Evaluation & Zero-Inflation Findings
- Preprocessing (StandardScaler) fit on training data only.
- Evaluated Constant Baseline, Tabular Baseline, and Fitted Ridge Regression ($L_2$ regularized) on held-out validation maps (`scripts/train_estimator.py`):
  - **Target A (Accepted Improvement):**
    - Constant Baseline: MAE = 0.38281, RMSE = 0.38281
    - Tabular Baseline: MAE = 0.42312, RMSE = 0.64305
    - Fitted Ridge: MAE = 0.52418, RMSE = 0.89021
    - *Audit Finding:* 96.72% of training labels and 100% of validation labels have zero improvement due to near-optimal prioritized planning initializations. Trivial zero predictor achieves low MAE simply because of zero-inflation. Linear regression over-predicts improvements on unseen maps.
  - **Target B (Active Search Time $\min(T_{rem}, \Delta)$):**
    - Constant Baseline: MAE = 0.00078 s (0.78 ms), RMSE = 0.00154 s
    - Tabular Baseline: MAE = **0.00066 s (0.66 ms)**, RMSE = 0.00151 s
    - Fitted Ridge: MAE = 0.00094 s (0.94 ms), RMSE = 0.00159 s
    - *Decision:* The simple Tabular baseline outperforms the fitted linear model on held-out validation maps. Per project guidance, the baseline is retained as a first-class estimator option.
  - **Breakdown across slice durations $\Delta$ (Target B Tabular MAE):**
    - $\Delta = 2\ \text{ms}$: MAE = $1.061\ \text{ms}$
    - $\Delta = 5\ \text{ms}$: MAE = $1.153\ \text{ms}$
    - $\Delta = 10\ \text{ms}$: MAE = $0.635\ \text{ms}$
    - $\Delta = 20\ \text{ms}$: MAE = $0.277\ \text{ms}$
    - $\Delta = 50\ \text{ms}$: MAE = $0.003\ \text{ms}$

### 5. C++ Inference Engine & Numerical Parity (`src/engine/rbl_estimator.hpp`)
- Implemented C++ estimator supporting `RIDGE_REGRESSION`, `TABULAR_BASELINE`, and `CONSTANT_BASELINE`.
- Compiled-in weights and scaler parameters with deterministic fallback.
- Explicit non-finite input protection (NaN, Inf) and vector dimension mismatch handling.
- **Python / C++ Parity Test (`tests/estimator_tests.cpp`):**
  - Tested 4 fixed verification cases (fresh and resumed, small and large slices).
  - Absolute error between Python `scikit-learn` and C++ inference: **$< 10^{-5}$**.
- **Measured Inference Latency in Release Build:**
  - Evaluated over 100,000 iterations on Apple M3:
  - **$0.0744\ \mu\text{s}$ per prediction** ($7.44 \times 10^{-5}\ \text{ms}$).
  - Proposal target was $< 0.1\ \text{ms}$ ($100\ \mu\text{s}$); achieved latency is over 1300x faster than the proposal target.
- **Sanitizer Verification:**
  - `build/audit-release`: 6/6 tests passed (100%).
  - `build/audit-asan`: 6/6 tests passed (100%), 0 memory leaks, 0 undefined behavior.

---

## Phase 6 Evidence (Overhead-Aware Controller & Audited Gate 2)

### 1. Proposed Controller Integration (`src/engine/rbl_controller.hpp`)
- Implemented `ResumeOrStartController` supporting Component 4 (O4, FR-05, WP4).
- Evaluates the proposed scoring equation:
  $$\text{Score}(a, \Delta) = \frac{\hat{E}[\text{AcceptedImprovement}(a, \Delta)]}{\hat{E}[\min(T_{\text{rem}}(a), \Delta)] + \widehat{\text{Overhead}}(a)}$$
  subject to strict admissibility:
  $$\Delta + \widehat{\text{Overhead}}(a) + t_{\text{reserve}} \le b_k$$
- **Overhead Accounting & Cost Separation:**
  - Incurred overhead (prior validation, candidate generation, feature extraction, scoring) is treated strictly as elapsed wall-clock time already deducted from remaining budget $b_k$.
  - Prospective overhead $\widehat{\text{Overhead}}(a)$ models future costs only: prospective restore/init latency plus conditional checkpoint-saving cost ($p_{\text{interrupt}} \cdot \hat{t}_{\text{save}}$).
  - Eliminates double-counting of search overheads.
- **Strict Monotonic Wall-Clock Accounting:**
  - Governed by `std::chrono::steady_clock` monotonic time throughout.
  - Remaining budget $b_k$ refreshed immediately before action execution.
  - Recheck before commit: if low-level search or independent validation finishes after deadline $B$, candidate is rejected (`REJECTED_LATE_COMMIT`) and incumbent is strictly preserved.
  - Recheck before saving: checkpoints are not written if global budget is exhausted.

### 2. Fair Policy Controls & Weak Prediction Handling
- Implemented three matched policy modes:
  1. `RESTART_ONLY_K0`: $K=0$, fresh repairs only, 10 ms fixed slice.
  2. `FIXED_FIFO_RESUME`: $K=2$, unconditional FIFO resumption whenever a compatible checkpoint exists, 10 ms fixed slice.
  3. `SCORE_BASED_ADAPTIVE`: $K=2$, overhead-aware score-based selection across candidate actions and candidate slices $\Delta \in \{0.002, 0.005, 0.010, 0.020, 0.050\}$ s.
- **Deterministic Fallback:** When all predicted improvements are zero (reflecting the zero-positive-validation finding from Phase 5), the controller deterministically invokes a documented fallback policy: prioritizes compatible resumed actions with highest completed prefix ratio $r_{\text{done}} / |A_c|$, and allocates the smallest admissible slice $\Delta$ to conserve budget.
- **Bounded Response to Stagnation:** Checkpoints failing to advance $r_{\text{done}}$ for $\ge 2$ consecutive resumption attempts are evicted from active storage (`stagnant_checkpoints_evicted`), bounding wasted computation. All repeated expansions upon restart are measured and recorded.

### 3. Automated Integration Test Suite (`tests/controller_tests.cpp`)
- Automated test suite exercises 6 categories:
  1. Controller initialization & missing initial solution rejection.
  2. Matched policy modes ($K=0$ vs $K=2$ FIFO vs adaptive).
  3. Deterministic fallback on all-zero predicted improvements.
  4. Stagnation eviction after repeated non-advancing resumptions.
  5. Late commit rejection with strict incumbent preservation.
  6. Decision pipeline latency audit.
- **Sanitizer Verification:**
  - `build/audit-release`: 7/7 ctest tests passed (100%).
  - `build/audit-asan`: 7/7 ctest tests passed (100%), 0 memory leaks, 0 undefined behavior.

### 4. Audited Gate 2 Results (`docs/gate2_results.json`)
- Evaluated on training maps (`random-32-32-20` and `warehouse-10-20-10-2-1`, 20 agents, $B = 1.0$ s deadline); held-out test maps kept 100% untouched.
- **Complete Decision Pipeline Latency Audit:**
  - 100 steps over varying budgets, varying checkpoint states, extracting 13 features $\times$ 5 actions $\times$ 5 slices = 25 evaluations per step:
  - Median: **$15.83\ \mu\text{s}$ (0.016 ms)**
  - P90: $39.75\ \mu\text{s}$ (0.040 ms)
  - P95: $74.67\ \mu\text{s}$ (0.075 ms)
  - P99: $200.92\ \mu\text{s}$ (0.201 ms)
  - Max: $200.92\ \mu\text{s}$ (0.201 ms)
  - Proposal target $\le 1.0\ \text{ms}$ is comfortably satisfied (even P99 is $\sim 5\times$ faster than target).
- **Matched Policy Comparison:**
  - `random-32-32-20` (20 agents, $B=1.0$ s):
    - `RESTART_ONLY_K0`: Initial cost 464, Final cost 413, Improvement 51, Valid: YES, Actions: 27710 F / 0 R, Repeated work: 0%, Overshoot: 0.00 ms, Peak Mem: 472 B, Med Lat: 1.0 $\mu$s.
    - `FIXED_FIFO_RESUME`: Initial cost 464, Final cost 413, Improvement 51, Valid: YES, Actions: 28274 F / 17 R, Repeated work: 75.2%, Overshoot: 0.00 ms, Peak Mem: 1340 B, Med Lat: 1.0 $\mu$s.
    - `SCORE_BASED_ADAPTIVE`: Initial cost 464, Final cost 413, Improvement 51, Valid: YES, Actions: 23459 F / 0 R, Repeated work: 0%, Overshoot: 0.00 ms, Peak Mem: 1984 B, Med Lat: 7.9 $\mu$s.
  - `warehouse-10-20-10-2-1` (20 agents, $B=1.0$ s):
    - `RESTART_ONLY_K0`: Initial cost 1616, Final cost 1505, Improvement 111, Valid: YES, Actions: 14724 F / 0 R, Repeated work: 0%, Overshoot: 0.00 ms, Peak Mem: 472 B, Med Lat: 1.0 $\mu$s.
    - `FIXED_FIFO_RESUME`: Initial cost 1616, Final cost 1505, Improvement 111, Valid: YES, Actions: 14650 F / 60 R, Repeated work: 88.7%, Overshoot: 0.00 ms, Peak Mem: 2884 B, Med Lat: 1.0 $\mu$s.
    - `SCORE_BASED_ADAPTIVE`: Initial cost 1616, Final cost 1505, Improvement 111, Valid: YES, Actions: 11328 F / 4 R, Repeated work: 36.1%, Overshoot: 0.00 ms, Peak Mem: 5296 B, Med Lat: 21.5 $\mu$s.
- **Explicit Gate 2 Criteria Evaluation:**
  1. [Correctness & Validity] 100% independent whole-plan collision check: PASS.
  2. [Strict Monotonic Accounting] Bounded deadline overshoot (< 50 ms): PASS (0.00 ms).
  3. [Overhead Target] Complete decision pipeline median <= 1.0 ms: PASS ($15.83\ \mu$s / 0.016 ms).
  4. [Fair Controls & Bounded Response] Stagnation eviction & late commit recheck: PASS.
- **Verdict:** **GATE 2 PASSED** (Confirmed engineering feasibility and overhead compliance).

---

## Phase 7 Evidence (Controlled Experimental Evaluation: E1–E6, RQ1–RQ3)

### 1. Benchmark Binary & Reproducibility Audit
- Benchmarks compiled into fresh untracked directory `build/bench-release/` (`rbl_eval_runner`, SHA256: `a7434190c1f4e1f725a39cbfaeb49e54d89a696bf547477c7c34b6b1580911fe`) using Command Line Tools clang++ (`-O3 -DNDEBUG -std=c++17`).
- Published baseline built in `build/baseline-release-cxx14/balance` (C++14 Release) and `build/baseline-release-cxx17/`.
- Host system: Apple M3 (8 CPU cores), 16 GB unified RAM, Darwin Kernel 25.3.0.
- All 7 test suites passing (100% CTest pass in 2.51s real runtime).

### 2. Validation Substring Flaw Fix & Independent Fixture Revalidation
- **Flaw Detected:** Previous code used `status = 'PASS' if 'VALID' in out else 'FAIL'`, which unsafely accepted `"INVALID"` and `"INVALID_PLAN"`.
- **Correction:** Implemented `scripts/safe_validator.py` enforcing validator exit code == 0, strict JSON decoding, exact `status == "VALID"`, and reported cost match against independent sum of costs.
- **Regression Suite:** Added `tests/test_safe_validation.py` covering 6 test cases (valid pass, invalid fail, substring trap rejection, corrupt/missing output rejection, process error rejection, and real binary integration).
- **Independent Plan Verification:**
  - 24/24 initial plan fixtures in `results/phase7/init_paths/` independently validated as `VALID` via `rbl_validate` (`results/phase7/initial_fixtures_validation_report.json`).
  - 4/4 representative final solution paths across all maps independently validated as `VALID` (`results/phase7/sample_final_validation_report.json`).
  - In manifest records without disk-persisted path files, validation is designated `UNVERIFIED_PATH_NOT_RETAINED`.

### 3. Clock Semantics & Protocol Boundaries
- Audited upstream `anytime-mapf`: confirmed that outer LNS budget cutoff is governed by `std::chrono::high_resolution_clock` (wall-clock time), while `clock()` references are purely internal profiling counters for diagnostic subroutines.
- Both systems operate on monotonic wall-clock time.
- **Protocol A (Controlled Refinement):** Starts timer at entry to `controller.run()` after precomputed initial plan is loaded from SHA-256 verified fixture. Initialization is outside budget.
- **Protocol B (End-to-End Planning):** Starts timer before initial solution search. Initialization is charged against budget. Remaining refinement time refreshed as $B - t_{\text{init}}$.

### 4. Sequential Reference Benchmark Execution
- Executed single-worker sequential reference benchmarks (`scripts/run_phase7_sequential.py`):
  - 4 held-out maps: `warehouse-20-40-10-2-1`, `random-64-64-20`, `room-64-64-8`, `ost003d`.
  - 1 scenario (Scenario 1), 2 agent scales (50, 100), 4 budgets (1.0s, 5.0s, 10.0s, 30.0s) = 32 conditions.
  - 8 configurations: 6 in Protocol A (192 runs) + 2 in Protocol B (64 runs) = 256 runs.
  - 100% completed (256/256), 0 failures, 0 timeouts. Total runtime: 2,966.7 seconds (49.4 minutes).
  - Archived 672-run concurrent batch preserved in `results/phase7/concurrent_batch/`.

### 5. Empirical Results & Hypotheses Testing (E1–E6, RQ1–RQ3)
- **Deadline Compliance & Matched Protocol B Comparison:**
  - Matched Protocol B evaluation ($N=32$ vs $N=32$, tolerance $\le 1.0\ \mu$s):
    * `RBL_END_TO_END`: 0 of 32 runs overran (0.0% overshoot rate); mean overshoot: 0.00 $\mu$s; max overshoot: 0.00 $\mu$s.
    * `BASELINE_BALANCE`: 26 of 32 runs overran (81.2% overshoot rate); mean overshoot across all runs: 184.37 $\mu$s; mean among overrunning runs: 226.92 $\mu$s; max overshoot: 2,100.00 $\mu$s (2.10 ms); P95: 539.5 $\mu$s.
  - Across all 224 RBL runs in the replacement reference benchmark, exactly 0 overran the deadline (100.0% zero-overshoot compliance). In the preliminary batch, one run (`room-64-64-8`, 100 agents, 30.0s) experienced an overshoot of 11.8 ms, demonstrating that while a prospective reserve margin ($t_{\text{reserve}} = 0.5$ ms) reduces overshoot frequency, a hard deadline guarantee has not been established.
- **RQ1 (Checkpoint Feasibility & Equivalence, E1, WP2):**
  - SUPPORTED (within stated scope). Demonstrated exact cell-by-cell equivalence under unchanged constraints with $3.92\ \mu$s live latency and 1024 bytes memory in E1 suite.
- **RQ2 (Constraint Validation Dynamics, E4, WP3):**
  - QUALIFIED. Stage 1 ($0.04 - 0.38\ \mu$s) and Stage 2 ($0.24 - 0.71\ \mu$s) conservative validator detects all conflicts with 0 invalid commits. In benchmark runs, selective compatibility tied with discard-on-change ($\Delta = -0.09$, 29 ties, 1 win, 2 losses) due to low repair yields (0.19 accepted from resumes) and stagnation evictions (mean 3,422 evictions), which prevented marginal retained checkpoints from finding lower-cost global incumbents than fresh repairs.
- **RQ3 (Resume-or-Start Controller Utility, E2, E3, E5, E6, WP5):**
  - **E2 (Resumption vs. Restart, Protocol A):** FIFO resumption achieved a positive average improvement (+50.66 points across the 32-condition sample). However, this advantage is heavily concentrated on organic terrain (`ost003d`, +230.00 points). When `ost003d` is omitted in Leave-One-Map-Out sensitivity analysis, the mean difference drops to **-9.12 points** (resumption is worse on average). Cluster-by-map bootstrap 95% CI spans zero: **[-17.16, +171.38]**. Qualified finding: *"FIFO resumption achieved a positive average improvement in the evaluated sample, concentrated on ost003d."*
  - **E3a & E3b (Controller Scoring & Adaptive Slicing, Protocol A):** Inconclusive. Matched 10 ms scoring yielded -27.19 points difference (CI: [-105.56, +24.75]). Variable slice grids ($\{2, 5, 10, 20, 50\}$ ms) frequently selected 2 ms slices, increasing decision churn without discovering lower-cost global paths (-37.22 points).
  - **E5 (Progress Features vs. Elapsed Time Only, Protocol A):** Inconclusive. Feature-based controller yielded -2.28 points difference (CI: [-5.62, 0.00]) relative to elapsed-time-only scoring.
  - **E6 (Comparison Against Published BALANCE, Protocol B):** Unsupported on solution quality. Published BALANCE achieved lower solution costs on 21 of 32 conditions (mean difference -262.00 points, CI: [-593.84, -42.19]). Under Hypothesis 1 (Uninstrumented Search Depth Advantage), this advantage is hypothesized to arise from uninstrumented monolithic search depth, but BALANCE overran the deadline on 81.2% of runs (up to 2.10 ms), whereas RBL maintained 100% compliance within $\le 1.0\ \mu$s tolerance.
- **Run Accounting & Trajectory Retention:**
  - Preliminary sequential batch (256 runs): completed processes = 256, solver-reported valid = 256, independently validated retained trajectories = 0 (trajectories not persisted to disk; labeled `UNVERIFIED_PATH_NOT_RETAINED`).
  - Verified replacement reference batch: 256 of 256 runs completed, retaining complete trajectories to `results/phase7/verified_reference/paths/` with SHA-256 provenance and independent validation passing `safe_validator.py` (`rbl_validate`) with 100% valid collision-free paths and exact cost matches.
- Full report compiled in `docs/phase7_evaluation_report.md`.

---

## Current Objective & Phase 8 Implementation
**Current Status: Scenario 1 verified evaluation complete; Scenarios 2–3 pending; Phase 8 implementation can proceed.**
1. Implement the reproducible replay exporter (`scripts/export_replays.py`) normalizing BALANCE `(row, col)` and RBL `(col, row)` coordinates to standard `(x, y)` format.
2. Build the local offline HTML5 Canvas replay viewer in `viewer/` with zero CDN dependencies, timeline controls, stay-at-goal support, non-square map rendering, and agent inspection.
3. Verify the viewer across map topologies and coordinate conventions.
4. Execute Scenarios 2 and 3 sequentially under the frozen protocol to complete the full 768-run reference design.


