# RouteBudget Lab: Phase 7 Controlled Experimental Evaluation Report

**Date:** October 2026  
**Environment:** Apple M3 (8-core), Darwin 25.3.0 arm64, Command Line Tools Clang 17.0.0 (`-O3 -DNDEBUG -std=c++17`)  
**Evaluation Git Branch:** `test`  
**Phase 7 Status:** **Scenario 1 verified evaluation complete; Scenarios 2–3 pending; Phase 8 implementation can proceed.**  
*(The 256 Scenario 1 replacement reference records, retained trajectories, validation results, and SHA-256 hashes are verified on disk. Scenarios 2–3 of the authorized 768-run design are pending sequential execution; Phase 8 offline replay viewer development proceeds using the verified Scenario 1 dataset).*

---

## 1. Executive Summary & Audit Resolutions

### 1.1 Resolution of Final-Solution Validation & Trajectory Retention
During the Phase 7 experimental audit, three critical validation constraints were resolved:
1. **Retrospective Validation Fallacy:**
   The four sample solutions evaluated in `scripts/validate_sample_final_solutions.py` originated from separate exploratory reruns and **cannot retroactively validate earlier benchmark runs**, even though their reported costs matched. Independent validation evidence must link strictly to an exact run identity, a disk-persisted trajectory file, and its cryptographic SHA-256 hash.
2. **Trajectory Retention Outside Planning Timers:**
   Both solvers have been configured to retain complete final trajectory files to disk outside the declared planning timer (charging zero overhead to the algorithm's solve time):
   - **Upstream BALANCE:** Native `--outputPaths <file>` argument invokes `LNS::writePathsToFile` after `lns.run()` has completed. Outputs Moving AI grid coordinates in `(row, col)` format.
   - **RouteBudget Lab:** `--dump-final-paths <file>` argument invokes `saveMovingAIPathsToFile` after `controller.run()` has completed. Outputs Moving AI grid coordinates in `(col, row)` format.
3. **Safe Independent Validator:**
   `scripts/safe_validator.py` enforces POSIX return code == 0, strict JSON decoding, exact Boolean equality `status == "VALID"` (eliminating the naive `'VALID' in out` substring flaw which falsely passed `'INVALID_PLAN'`), and verifies reported costs against independent arrival-time sums. All 24 initial plan fixtures in `results/phase7/init_paths/` were independently verified as `VALID` (100.0% pass rate).

### 1.2 Honest Run Category Accounting
To prevent conflating process completion or solver flags with independent verification, all benchmark runs are categorized across four distinct states:

| Run Classification Category | Preliminary Sequential Batch (`results/phase7/sequential_reference/`) | Verified Replacement Batch (`results/phase7/verified_reference/`) | Archived Concurrent Batch (`results/phase7/concurrent_batch/`) |
|---|---|---|---|
| **1. Process-Completed Runs** | 256 / 256 (100.0%) | **256 / 256 (100.0%)** | 672 / 672 (100.0%) |
| **2. Solver-Reported Valid Runs** | 256 / 256 (100.0%) | **256 / 256 (100.0%)** | 672 / 672 (100.0%) |
| **3. Independently Validated Retained Trajectories** | **0 / 256 (0.0%)** *(trajectories not persisted to disk)* | **256 / 256 (100.0%)** *(SHA-256 hashed & validated)* | **0 / 672 (0.0%)** *(trajectories not persisted to disk)* |
| **4. Unavailable Trajectories (`UNVERIFIED_PATH_NOT_RETAINED`)** | **256 / 256 (100.0%)** | **0 / 256 (0.0%)** | **672 / 672 (100.0%)** |

> [!IMPORTANT]
> Process completion and solver internal flags do not constitute independent verification. The preliminary 256-run batch is strictly reported as having unverified retained trajectories, while verified replacement runs retain complete `.paths` files with SHA-256 hashes and independent validator passes.

### 1.3 Scenario Coverage Transparency & Protocol Reference Design
- **Previously Authorized Reference Design:**
  $4\ \text{maps} \times 3\ \text{scenarios} \times 2\ \text{agent counts} \times 4\ \text{budgets} \times 8\ \text{configurations} = 768\ \text{runs}$, assuming one random seed per condition.
- **Reason for Preliminary Single-Scenario Batch:**
  In `scripts/run_phase7_sequential.py`, line 31 hardcoded `SCENARIO_IDS = [1]`. This deviation was introduced specifically to limit sequential single-worker runtime to ~49.4 minutes rather than executing all three scenarios (~2.5 hours).
- **Protocol Reconciliation:**
  The 256-run batch is strictly designated as a **Preliminary Reduced-Scenario Benchmark (Scenario 1)**. It is never merged or combined with concurrent runs. The replacement reference benchmark `scripts/run_phase7_verified_reference.py` is executed with full trajectory retention and independent validation. Scenario identifiers (`scenario_id = 1`) and random seeds (`seed = 42` for RBL, `seed = 0` for BALANCE) are recorded separately in all manifest records.

---

## 2. Clock Semantics & Deadline Accounting Audit

### 2.1 Upstream BALANCE Timing & Clock Monotonicity Verification
A source-level inspection of upstream `anytime-mapf` (`third_party/anytime-mapf`) clarified clock behavior:
- In `inc/common.h` and `src/LNS.cpp`:
  ```cpp
  typedef std::chrono::high_resolution_clock Time;
  typedef std::chrono::duration<float> fsec;
  ...
  start_time = Time::now();
  ...
  while (runtime < time_limit && iteration_stats.size() <= num_of_iterations) {
      runtime = ((fsec)(Time::now() - start_time)).count();
  ```
- **Monotonicity Verification on Target Build:**
  The property `is_steady` was inspected on Apple Clang 17 (macOS arm64 libc++):
  - `std::chrono::steady_clock::is_steady == 1`
  - `std::chrono::high_resolution_clock::is_steady == 1`
  - In libc++, `std::chrono::high_resolution_clock` is a direct typedef alias for `std::chrono::steady_clock`. Both are strictly monotonic.
- Internal references to ANSI C `clock()` in `anytime-mapf` (`SIPP.cpp`, `CBS/PBS.cpp`, `MutexReasoning.cpp`) are purely diagnostic counters for logging component breakdowns (`runtime_build_CT`, `runtime_build_CAT`) and do not govern budget cutoff. Both BALANCE and RBL operate on wall-clock monotonic time.

### 2.2 Correction of Unsupported Deadline Claims
The following premature claims from earlier drafts have been corrected:
1. *Claim that sequential execution eliminates jitter, preemption, or core migration:*
   **Correction:** Sequential execution reduces benchmark-process contention on the CPU, but operating system thread scheduling, background service preemption, and platform power/thermal management remain active.
2. *Claim that RBL guarantees deadline compliance:*
   **Correction:** RBL does not mathematically guarantee deadline compliance. On `room-64-64-8` at 30.0s (100 agents), `SCORE_BASED_ADAPTIVE` experienced an overshoot of **11.8 ms** (30.0118s runtime) due to tail latency in an active repair slice during severe agent crowding.
3. *Claim that a 0.5 ms reserve guarantees timely completion:*
   **Correction:** The prospective safety reserve margin $t_{\text{reserve}} = 0.5$ ms substantially reduces overshoot frequency, but does not provide a hard mathematical guarantee under operating system scheduling. In the preliminary sequential batch, 223 of 224 RBL runs complied with deadlines while one run exhibited an 11.8 ms tail overshoot. In the verified replacement reference batch, all 224 RBL runs complied with deadlines within a $\le 1.0\ \mu$s tolerance (0 overrunning runs $> 1.0\ \mu$s). Sequential execution and prospective reserve margins mitigate process contention, but cannot eliminate OS scheduling preemption.

### 2.3 Protocol Boundary Specifications
| Dimension | Protocol A: Controlled Refinement | Protocol B: End-to-End Planning |
|---|---|---|
| **Intended Comparison** | Internal algorithmic ablation (E2–E5) | Systems-level baseline comparison (E6) |
| **Initial Plan Source** | Precomputed shared fixture (`results/phase7/init_paths/*.paths`) | Generated on-the-fly at runtime |
| **Initial Plan Provenance** | Verified byte-identical via SHA-256 hash | Distinct solver initialization routines |
| **Initialization Charging** | **Excluded** from refinement budget $B$ | **Charged** against total planning budget $B$ |
| **Timer Start Point** | At entry to `ResumeOrStartController::run()` | Before initial solution generation |
| **Timer Stop Point** | When remaining budget $b_k \le 0$ | When total runtime $\ge B$ |
| **In-Run Operations Charged** | Active search, controller scoring, feature extraction, save/restore latency, in-memory validation | Initial plan search + all refinement search, controller work, validation |
| **Excluded Operations** | Map/scenario I/O, process startup, post-run serialization, external validation | Map/scenario I/O, process startup, post-run serialization, external validation |
| **Overshoot Handling** | Prospective reserve margin $t_{\text{reserve}} = 0.5$ ms ($\Delta + \hat{O} + t_{\text{reserve}} \le b_k$) | RBL uses $t_{\text{reserve}} = 0.5$ ms; BALANCE checks retrospectively between iterations |

---

## 3. Protocol Separation and Execution Verification

### 3.1 Evaluated Benchmark Configurations
- **Held-Out Test Maps (4):** `warehouse-20-40-10-2-1`, `random-64-64-20`, `room-64-64-8`, `ost003d`.
- **Agent Scales (2):** 50, 100 agents.
- **Budgets (4):** 1.0s, 5.0s, 10.0s, 30.0s.
- **Protocol A Configurations (6 configs $\times$ 32 conditions = 192 runs):**
  1. `RESTART_ONLY_K0`: Matched control ($K=0$, fixed 10 ms slice).
  2. `FIXED_FIFO_RESUME`: Matched control ($K=2$, fixed 10 ms slice, FIFO selection).
  3. `SCORE_BASED_FIXED`: Matched control ($K=2$, fixed 10 ms slice, score-based selection).
  4. `SCORE_BASED_ADAPTIVE`: Proposed method ($K=2$, adaptive $\{2, 5, 10, 20, 50\}$ ms slices).
  5. `ELAPSED_TIME_ONLY`: Feature ablation ($K=2$, adaptive slices, progress features masked).
  6. `DISCARD_ON_CHANGE`: Compatibility ablation ($K=2$, adaptive slices, discard-on-change policy).
- **Protocol B Configurations (2 configs $\times$ 32 conditions = 64 runs):**
  7. `RBL_END_TO_END`: Proposed method with initialization charged to budget.
  8. `BASELINE_BALANCE`: Upstream BALANCE C++14 Release binary.

---

## 4. Empirical Statistical Evaluation

All comparisons are paired across identical problem conditions. Cost differences are reported as:
$$\Delta \text{Cost} = \text{Cost}(\text{Control}) - \text{Cost}(\text{Treatment})$$
A positive value indicates that Treatment achieved a lower (better) solution cost than Control.

### 4.1 Clustered Bootstrap Resampling Protocol
Conditions sharing a map and scenario across multiple budgets are not independent replicates. To respect instance clustering, non-parametric 95% Confidence Intervals are computed via **Clustered Bootstrap** (resampling entire map clusters with replacement, $B = 5,000$ iterations).

### 4.2 Protocol A: Controlled Refinement Comparisons (E2–E5)
$N = 32$ paired conditions. Initial plans verified identical by SHA-256 fixture hash.

| Exp | Comparison (Control $\to$ Treatment) | Wins | Losses | Ties | Mean $\Delta$ Cost | Median $\Delta$ Cost | Mean % Imp | Cluster-by-Map 95% CI | Qualified Finding |
|---|---|---|---|---|---|---|---|---|---|
| **E2** | `RESTART_ONLY_K0` $\to$ `FIXED_FIFO_RESUME` | 11 | 5 | 16 | **+50.66** | 0.00 | +0.559% | **[-17.16, +171.38]** | Positive sample improvement, concentrated on `ost003d` |
| **E3a** | `FIXED_FIFO_RESUME` $\to$ `SCORE_BASED_FIXED` | 12 | 7 | 13 | -27.19 | 0.00 | -0.144% | [-105.56, +24.75] | Inconclusive (CI spans zero) |
| **E3b** | `SCORE_BASED_FIXED` $\to$ `SCORE_BASED_ADAPTIVE` | 8 | 8 | 16 | -37.22 | 0.00 | -0.485% | [-122.66, +10.50] | Inconclusive (CI spans zero) |
| **E4** | `DISCARD_ON_CHANGE` $\to$ `SCORE_BASED_ADAPTIVE` | 1 | 2 | 29 | -0.09 | 0.00 | -0.008% | [-0.75, +0.47] | Inconclusive (CI spans zero) |
| **E5** | `ELAPSED_TIME_ONLY` $\to$ `SCORE_BASED_ADAPTIVE` | 2 | 5 | 25 | -2.28 | 0.00 | -0.039% | [-5.62, +0.00] | Inconclusive (CI spans zero) |

### 4.3 Protocol B: End-to-End Baseline Comparison (E6)
Matched comparison: $N = 32$ paired conditions. Both systems generate initial solutions charged to budget.

| Exp | Comparison (Control $\to$ Treatment) | Wins | Losses | Ties | Mean $\Delta$ Cost | Median $\Delta$ Cost | Mean % Imp | Cluster-by-Map 95% CI | Qualified Finding |
|---|---|---|---|---|---|---|---|---|---|
| **E6** | `BASELINE_BALANCE` $\to$ `RBL_END_TO_END` | 8 | 21 | 3 | **-262.00** | -99.00 | -2.160% | **[-593.84, -42.19]** | Baseline achieves lower cost |

> [!NOTE]
> A confidence interval spanning zero indicates that the observed sample difference is not statistically distinguishable from zero under clustered resampling; it does **not** prove equivalence between methods.

---

## 5. Topology Breakdown & Sensitivity Analysis

### 5.1 Paired Cost Reduction by Map Topology ($\Delta \text{Cost}$)
| Comparison | `warehouse` ($n=8$) | `random` ($n=8$) | `room` ($n=8$) | `ost003d` ($n=8$) | Overall ($N=32$) |
|---|---|---|---|---|---|
| **E2 (Resumption Effect)** | -22.88 | 0.00 | -4.50 | **+230.00** | +50.66 |
| **E3a (Controller Scoring, 10ms)** | +35.00 | +4.50 | -6.00 | -142.25 | -27.19 |
| **E3b (Adaptive Slicing)** | 0.00 | +1.00 | +14.00 | -163.88 | -37.22 |
| **E4 (Selective Compatibility)** | 0.00 | 0.00 | -1.00 | +0.62 | -0.09 |
| **E5 (Progress Features)** | 0.00 | 0.00 | -1.62 | -7.50 | -2.28 |
| **E6 (End-to-End Comparison)** | -198.12 | -5.50 | -78.88 | -765.50 | -262.00 |

### 5.2 Leave-One-Map-Out (LOMO) Sensitivity Analysis for E2
To evaluate how strongly the resumption advantage depends on individual map topologies, a Leave-One-Map-Out (LOMO) analysis was conducted:

| Omitted Map | Remaining Conditions | Mean $\Delta \text{Cost}$ Without Omitted Map | Resumption Status |
|---|---|---|---|
| *None (Full Evaluation Sample)* | $N = 32$ | **+50.66** | Positive sample improvement |
| Omitting `warehouse-20-40-10-2-1` | $N = 24$ | +75.17 | Positive sample improvement |
| Omitting `random-64-64-20` | $N = 24$ | +67.54 | Positive sample improvement |
| Omitting `room-64-64-8` | $N = 24$ | +69.04 | Positive sample improvement |
| **Omitting `ost003d`** | $N = 24$ | **-9.12** | **Net negative (Restart outperforms Resumption)** |

**Critical Finding:**
The positive overall average improvement (+50.66 points) is overwhelmingly driven by the organic bottleneck topology `ost003d` (+230.00 points). On open grids (`random-64-64-20`), resumption and restart tie identically (0.00 points). On warehouse and room topologies, resumption incurs minor average losses (-22.88 and -4.50 points) due to repeated node expansion overhead upon restarting unfinished search. Omitting `ost003d` reverses the sign of the overall mean to **-9.12 points**. Therefore, findings on `ost003d` cannot be generalized to all complex terrain.

---

## 6. Telemetry, Overhead, and Matched Deadline Accounting

### 6.1 Telemetry Profiles (Averages across all 32 sequential conditions)
| Metric | `RESTART_K0` | `FIFO_RESUME` | `SCORE_FIXED` | `SCORE_ADAPTIVE` | `DISCARD_ON_CHANGE` | `BALANCE` |
|---|---|---|---|---|---|---|
| **Total Decisions** | 12,854 | 12,987 | 13,012 | 74,055 | 74,055 | 18,240 |
| **Fresh Actions** | 12,854 | 7,589 | 7,907 | 66,958 | 66,958 | 18,240 |
| **Resumed Actions** | 0 | 5,398 | 5,105 | 7,096 | 7,096 | 0 |
| **Accepted Repairs** | 2.1 | 2.4 | 2.3 | 14.8 | 14.8 | 5.8 |
| **Accepted from Resumed** | 0.0 | **0.8** | **1.0** | 0.19 | 0.19 | 0.0 |
| **Repeated Work Ratio** | 0.0000 | 0.8315 | 0.8323 | 0.7824 | 0.7818 | 0.0000 |
| **Median Decision Latency ($\mu$s)** | 0.8 | 1.1 | 14.8 | 16.2 | 16.2 | N/A |
| **Stagnant Evictions** | 0 | 0 | 0 | 3,422 | 3,422 | 0 |

### 6.2 Mechanistic Telemetry Explanation for E4 Ties
In Experiment E4, `SCORE_BASED_ADAPTIVE` and `DISCARD_ON_CHANGE` achieved nearly identical final solution costs across all 32 conditions (29 exact ties, 1 win, 2 losses, net difference $\Delta \text{Cost} = -0.09$). Telemetry inspection revealed that their internal execution paths were not identical:
- Internal decision counts differed between the policies (e.g. on `random-64-64-20` at 10s: 102,542 decisions vs 103,603 decisions; 898 vs 919 resumed actions).
- Checkpoint discards differed: `DISCARD_ON_CHANGE` discarded checkpoints on version changes, whereas selective retention preserved compatible prefixes.
- **Why final costs tied:** Across the evaluated benchmark instances, repair acceptance rates plateaued early (mean 14.8 total accepted repairs over 10s–30s runs). Of the thousands of resumptions executed, only a tiny fraction (mean 0.19 accepted repairs from resumed actions) yielded strictly improving paths. The vast majority of retained checkpoints reached stagnation age and were evicted (mean 3,422 evictions per run) without finding lower-cost global incumbents than fresh repairs.

### 6.3 Matched Protocol B Deadline Compliance Comparison
To ensure measurement fairness, Protocol B deadline performance is compared strictly between matched runs ($N = 32$ runs of `RBL_END_TO_END` vs $N = 32$ runs of `BASELINE_BALANCE`). Compliance tolerance is set at $\le 1.0\ \mu$s.

| Measurement Dimension | `BASELINE_BALANCE` (Protocol B) | `RBL_END_TO_END` (Protocol B) |
|---|---|---|
| **Measured Runs** | 32 | 32 |
| **Overrunning Runs (> 1.0 $\mu$s)** | **26 of 32 (81.2%)** | **0 of 32 (0.0%)** |
| **Zero-Overshoot Compliance Rate** | **18.8%** (6 of 32) | **100.0%** (32 of 32) |
| **Mean Overshoot (All Runs)** | **184.37 $\mu$s** | **0.00 $\mu$s** |
| **Mean Overshoot (Overrunning Runs Only)** | **226.92 $\mu$s** | **0.00 $\mu$s** |
| **Maximum Overshoot** | **2,100.00 $\mu$s (2.10 ms)** | **0.00 $\mu$s (0.00 ms)** |
| **Quantile P50 (Median)** | 100.00 $\mu$s | 0.00 $\mu$s |
| **Quantile P90** | 298.00 $\mu$s | 0.00 $\mu$s |
| **Quantile P95** | 539.50 $\mu$s | 0.00 $\mu$s |
| **Quantile P99** | 1,669.10 $\mu$s | 0.00 $\mu$s |
| **Mean Final Solution Cost** | **8,124.62** | **8,386.62** |

**Trade-off Visibility & Hypothesis Testing:**
Published BALANCE achieved lower final solution costs (mean advantage of 262.00 points) on the evaluated sample. Under **Hypothesis 1 (Uninstrumented Search Depth Advantage)**, it is hypothesized that BALANCE's advantage arises because its monolithic LNS loop avoids interruption checkpoints, feature extraction, and safety reserve margins. However, BALANCE overran the declared deadline on 81.2% of runs (26 of 32, with tail overshoots up to 2.10 ms). In contrast, RBL complied with the deadline on all 32 Protocol B conditions within the $\le 1.0\ \mu$s tolerance (0 runs overrunning $> 1.0\ \mu$s).

---

## 7. Answers to Approved Research Questions (RQ1–RQ3)

The project research questions are evaluated against their original approved wording from `docs/source_text/report.txt`:

### RQ1 (Checkpoint Feasibility & Equivalence)
> *"Can a low-level MAPF-LNS repair search be suspended at an arbitrary cutoff and resumed under unchanged external constraints to produce valid, collision-free solutions consistent with uninterrupted execution, and what memory and latency overheads are incurred?"*

- **Status: SUPPORTED (within evaluated scope).**
- Evaluated in E1 (`tests/e1_resumption_tests.cpp`, 10 test categories). Under unchanged external constraints, macro-prefix resumption restores search invariants, restarts the unfinished agent deterministically, and produces valid, collision-free paths with cell-by-cell equivalence to uninterrupted execution.
- Measured live integrated overhead: save latency $0.79\ \mu$s (Release) / $3.75\ \mu$s (ASan); restore latency $3.12\ \mu$s (Release) / $11.88\ \mu$s (ASan); combined latency $3.92\ \mu$s (<0.04% of a 10 ms slice). Checkpoint memory footprint: 1,024 bytes (1 KB).

### RQ2 (Constraint Validation Dynamics)
> *"What fraction of saved repair checkpoints remain compatible with evolving external agent reservations across subsequent LNS iterations, and does conservative constraint validation prevent invalid solution commits compared with unvalidated reuse?"*

- **Status: EVALUATED & QUALIFIED.**
- Evaluated in E4 unit test suites (`tests/e4_compatibility_tests.cpp`) and benchmark runs. The two-stage validator checks version counters in Stage 1 ($0.04 - 0.38\ \mu$s) and evaluates vertex, edge swap, stay-at-goal, and neighborhood mutations in Stage 2 ($0.24 - 0.71\ \mu$s), successfully detecting all simulated conflicts with 0 invalid commits.
- In benchmark execution, while selective retention preserved checkpoints across intervening updates, repair yield from retained checkpoints was very low (mean 0.19 accepted repairs), and final solution quality tied with discard-on-change due to incumbent plateauing.

### RQ3 (Resume-or-Start Controller Utility)
> *"Does an overhead-aware resume-or-start heuristic controller informed by lightweight search-progress features achieve lower deadline solution cost (Sum of Costs / Total Delay) than restart-only LNS, fixed round-robin resumption, and published adaptive baselines within identical wall-clock deadlines?"*

- **Status: QUALIFIED / UNSUPPORTED against Published Baseline.**
- **Resumption vs Restart (E2):** FIFO resumption achieved a positive average improvement in the evaluated sample (+50.66 points), but this finding is overwhelmingly concentrated on bottleneck terrain (`ost003d`, +230.00 points). When `ost003d` is omitted, the average improvement becomes negative (-9.12 points). Clustered bootstrap 95% CI spans zero ([-17.16, +171.38]).
- **Controller Scoring & Adaptive Slicing (E3a, E3b, E5):** Inconclusive. Under matched 10 ms slices, score-based selection yielded -27.19 points difference (CI: [-105.56, +24.75]). Variable slice grids ($\{2, 5, 10, 20, 50\}$ ms) frequently selected 2 ms slices, increasing decision churn without discovering lower-cost global paths (-37.22 points). Progress features yielded -2.28 points difference compared to elapsed-time-only scoring (CI: [-5.62, 0.00]).
- **Comparison Against Published BALANCE (E6):** Unsupported on solution quality. Under Protocol B where initialization is charged against the budget, published BALANCE achieved lower solution costs on 21 of 32 conditions (mean difference -262.00 points). Under Hypothesis 1, BALANCE's cost advantage is hypothesized to stem from monolithic search depth, but this came at the expense of deadline non-compliance on 81.2% of runs (up to 2.10 ms), where RBL maintained 100.0% compliance within $\le 1.0\ \mu$s tolerance.

---

## 8. Remaining Limitations & Tested Hypotheses

1. **Hypothesis 2 (Macro-Prefix Repeated Work Overhead):**
   Because macro-prefix mode discards the unfinished agent's open-list frontier, resuming search incurs repeated node expansions (repeated work ratio 78%–83%). On maps with short, simple paths (`warehouse`, `random`), the cost of repeated expansions appears to exceed the benefit of prefix reuse, explaining why resumption underperformed restart on non-bottleneck terrain.
2. **Hypothesis 3 (Sparse Improvement & Plateau Regime):**
   In near-optimal initial plans, accepted improvements occur in fewer than 3% of repair iterations. Regression models predicting accepted improvement suffer from severe zero-inflation, rendering feature-based scoring only marginally distinguishable from heuristic elapsed-time baselines.
3. **Hypothesis 1 (Uninstrumented Search Depth Advantage vs Overhead):**
   The explanation that BALANCE's solution quality advantage is caused by uninstrumented search depth is supported by telemetry (18,240 iterations vs 12,854 decisions) but remains an observational hypothesis rather than an isolated single-variable proof. Statements attributing performance to "zero preemption checks" or "100% time window utilization" are explicitly categorized as hypotheses.

---

## 9. Current Status & Phase 8 Transition

**Current Status:** **Scenario 1 verified evaluation complete; Scenarios 2–3 pending; Phase 8 implementation can proceed.**

1. **Scenario 1 Verified Dataset (Available):** All 256 Scenario 1 replacement records, retained trajectory files (`results/phase7/verified_reference/paths/*.paths`), and cryptographic SHA-256 hashes are available on disk. 256 of 256 runs (100.0%) were independently validated as collision-free with exact arrival-time cost matches.
2. **Scenarios 2–3 Evaluation (Pending):** The complete reference design (4 maps $\times$ 3 scenarios $\times$ 2 agent counts $\times$ 4 budgets $\times$ 8 configurations = 768 runs) continues under the frozen protocol without tuning.
3. **Phase 8 Replay Viewer (Unblocked):** Phase 8 offline replay viewer development proceeds immediately using the 256 verified Scenario 1 replays.
