# RouteBudget Lab

Constraint-validated resumption of interrupted repairs for deadline-aware MAPF (final-year project).
Early stage: only the upstream baseline is set up. See `IMPLEMENTATION_STATUS.md`.

## Build and run the baseline
```
scripts/build_baseline.sh Release      # or: asan
build/release/balance -m data/sample/random-32-32-20.map \
  -a data/sample/random-32-32-20-random-1.scen -k 50 -t 10 -o out \
  --outputPaths=paths.txt --banditAlgo=Thompson --neighborCandidateSizes=5 \
  --seed=0 --maxIterations=1000000
```
Requires CMake, Boost (program_options, filesystem) and a C++ compiler. Eigen 3.4 is vendored.

Upstream: https://github.com/thomyphan/anytime-mapf (USC research licence, see `third_party/anytime-mapf/license.txt`).
