#!/usr/bin/env python3
"""
RouteBudget Lab — Selective Recovery Development Pilot Runner (Section 12)

Executes a 192-run matched development pilot across 5 selective recovery policies
and a terminal-reserve control ablation on development instances:
  - Maps: random-64-64-10, warehouse-10-20-10-2-2
  - Scenarios: random-1, random-2
  - Scales: 50, 100 agents
  - Budgets: 1.0 s, 5.0 s
  - Seeds: 0, 1
  - Policies: RESUMPTION_NO_PA, PA_EVERY_INTERRUPTION_FILTERED, PA_EVICTION_ONLY,
              PA_TERMINAL_ONLY, PA_EVICTION_AND_TERMINAL, TERMINAL_RESERVE_CONTROL

Features:
  - Sequential execution for clean wall-clock timing.
  - Cyclic Latin-square rotation to eliminate thermal/ordering bias.
  - Reuses shared initial solution fixtures.
  - Independent validation of 100% of generated paths via rbl_validate.
  - Cryptographic checksums and versioned provenance.
"""

import argparse
import hashlib
import json
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser(description="Run Selective Recovery Development Pilot")
    parser.add_argument("--config", type=str, default="configs/2026-11-01_selective_recovery/selective_recovery_pilot.json")
    parser.add_argument("--output-dir", type=str, default="results/2026-11-01_selective_recovery")
    parser.add_argument("--repo-root", type=str, default=".")
    args = parser.parse_args()

    repo_root = Path(args.repo_root).resolve()
    config_path = (repo_root / args.config).resolve()
    out_dir = (repo_root / args.output_dir).resolve()
    raw_dir = out_dir / "raw"
    paths_dir = out_dir / "paths"
    raw_dir.mkdir(parents=True, exist_ok=True)
    paths_dir.mkdir(parents=True, exist_ok=True)

    with open(config_path, "r") as f:
        config = json.load(f)

    profiler_bin = repo_root / "build" / "bench-release" / "rbl_profile_partial_acceptance"
    validator_bin = repo_root / "build" / "bench-release" / "rbl_validate"

    if not profiler_bin.exists():
        sys.exit(f"FATAL: Profiler binary not found at {profiler_bin}")
    if not validator_bin.exists():
        sys.exit(f"FATAL: Validator binary not found at {validator_bin}")

    # Build 32 matched problem cells
    cells = []
    grid = config["grid"]
    for m in grid["maps"]:
        map_name = m["name"]
        map_path = m["path"]
        for scen_path in m["scenarios"]:
            scen_name = Path(scen_path).stem
            for agents in grid["agent_counts"]:
                for budget in grid["budgets_seconds"]:
                    for seed in grid["seeds"]:
                        cells.append({
                            "map_name": map_name,
                            "map_path": map_path,
                            "scen_name": scen_name,
                            "scen_path": scen_path,
                            "agents": agents,
                            "budget": budget,
                            "seed": seed,
                        })

    policies = config["policies"]
    total_runs = len(cells) * len(policies)
    print("=" * 70)
    print(f"RouteBudget Lab — Selective Recovery Pilot (192 Runs)")
    print(f"Cells: {len(cells)} | Policies: {len(policies)} | Total Planned Runs: {total_runs}")
    print(f"Output Directory: {out_dir}")
    print("=" * 70)

    init_fixtures_dir = repo_root / "results" / "partial_acceptance_pilot" / "init_paths"
    all_results = []
    manifest_entries = []
    t_start_all = time.time()

    run_index = 0
    for cell_idx, cell in enumerate(cells):
        # Cyclic rotation of policy variants to prevent thermal / cache order bias
        shift = cell_idx % len(policies)
        rotated_policies = policies[shift:] + policies[:shift]

        map_stem = Path(cell["map_path"]).stem
        scen_stem = Path(cell["scen_path"]).stem
        agents = cell["agents"]
        budget = cell["budget"]
        seed = cell["seed"]

        init_path_file = init_fixtures_dir / f"{map_stem}__{scen_stem}__a{agents}.paths"
        if not init_path_file.exists():
            sys.exit(f"FATAL: Required initial path fixture not found: {init_path_file}")

        for pol in rotated_policies:
            run_index += 1
            pol_name = pol["name"]
            pol_arg = pol["policy_arg"]
            is_term_ctrl = pol.get("terminal_control", False)

            run_id = f"{map_stem}__{scen_stem}__a{agents}__s{seed}__b{budget}__p{pol_name}"
            raw_json = raw_dir / f"{run_id}.json"
            final_paths = paths_dir / f"{run_id}.paths"

            print(f"[{run_index:03d}/{total_runs:03d}] Cell {cell_idx+1:02d}/32 | Map={map_stem[:14]} A={agents} B={budget}s S={seed} | {pol_name} ... ", end="", flush=True)

            cmd = [
                str(profiler_bin),
                "--mode", "online",
                "--map", str(repo_root / cell["map_path"]),
                "--scen", str(repo_root / cell["scen_path"]),
                "--agents", str(agents),
                "--seed", str(seed),
                "--budget", str(budget),
                "--slice", str(config["base_parameters"]["slice_duration_seconds"]),
                "--neighborhood-size", str(config["base_parameters"]["neighborhood_size"]),
                "--policy", pol_arg,
                "--terminal-reserve", str(config["base_parameters"]["terminal_reserve_seconds"]),
                "--load-init-paths", str(init_path_file),
                "--dump-final-paths", str(final_paths),
                "--output", str(raw_json)
            ]
            if is_term_ctrl:
                cmd.append("--terminal-reserve-control")

            t0 = time.time()
            proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            elapsed = time.time() - t0

            if proc.returncode != 0 or not raw_json.exists():
                print(f"FAILED (code {proc.returncode})")
                print("STDOUT:", proc.stdout[:500])
                print("STDERR:", proc.stderr[:500])
                sys.exit(1)

            with open(raw_json, "r") as f:
                res = json.load(f)

            # Override policy label in result for terminal control distinction
            res["run_id"] = run_id
            res["experiment_policy"] = pol_name
            res["is_terminal_reserve_control"] = is_term_ctrl
            res["cell_index"] = cell_idx
            res["rotation_shift"] = shift
            res["cell_parameters"] = cell

            # Independent validation via rbl_validate
            val_cmd = [
                str(validator_bin),
                "--map", str(repo_root / cell["map_path"]),
                "--scen", str(repo_root / cell["scen_path"]),
                "--agents", str(agents),
                "--paths", str(final_paths),
                "--reported-cost", str(res["final_cost"])
            ]
            val_proc = subprocess.run(val_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            if val_proc.returncode != 0:
                print(f"VALIDATION FAILED!")
                print(val_proc.stderr)
                sys.exit(1)

            res["independent_validation"] = "PASSED"
            res["paths_sha256"] = sha256_file(final_paths)
            res["raw_json_sha256"] = sha256_file(raw_json)

            # Re-save with enriched provenance
            with open(raw_json, "w") as f:
                json.dump(res, f, indent=2)

            all_results.append(res)
            manifest_entries.append(f"{res['paths_sha256']}  paths/{run_id}.paths\n")
            manifest_entries.append(f"{res['raw_json_sha256']}  raw/{run_id}.json\n")

            gain_str = f"SoC={res['final_cost']} (Δ={res['cost_reduction_at_deadline']})"
            overshoot_str = f"over={res['deadline_overshoot_s']*1e6:.1f}us"
            print(f"VALID {gain_str} {overshoot_str} in {elapsed:.2f}s")

    t_total = time.time() - t_start_all
    print("=" * 70)
    print(f"All 192 runs completed and independently validated in {t_total:.1f}s ({t_total/60:.2f} min).")
    print("=" * 70)

    # Save compiled all_runs.json
    all_runs_file = out_dir / "all_runs.json"
    with open(all_runs_file, "w") as f:
        json.dump(all_results, f, indent=2)

    # Save SHA-256 manifest
    manifest_file = out_dir / "manifest.sha256"
    with open(manifest_file, "w") as f:
        f.writelines(manifest_entries)

    print(f"Wrote compiled dataset to {all_runs_file}")
    print(f"Wrote SHA-256 manifest to {manifest_file}")


if __name__ == "__main__":
    main()
