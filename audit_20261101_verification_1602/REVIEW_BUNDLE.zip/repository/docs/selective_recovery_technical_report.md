# Constraint-Validated Resumption and Selective Recovery of Interrupted Repairs for Deadline-Aware Multi-Agent Path Finding

**Author:** P. G. Disas Sethnada (IIT: 20231323, UoW: w2119964)  
**Project:** RouteBudget Lab  
**Date:** 2026-11-01  
**Target Branch:** `research/selective-recovery`  

---

## Abstract

Anytime Multi-Agent Path Finding (MAPF) based on Large Neighborhood Search (MAPF-LNS) iteratively destroys and replans paths for small subsets of conflicting agents. When bounded planning time slices are enforced under strict monotonic wall-clock deadlines, repairs are frequently interrupted before all neighborhood agents are replanned. Prior work in RouteBudget Lab established that saving completed route prefixes in a bounded macro-prefix checkpoint store ($K \in \{0, 1, 2\}$) and resuming search on subsequent slices captures substantial optimization progress. However, when an interrupted repair contains completed replacement routes that already yield lower arrival costs for a subset of agents, normal resumption leaves those improvements uncommitted until the entire neighborhood completes.

In this work, we investigate **Selective Recovery**: whether extracting feasible subsets of completed replacement routes from interrupted repairs—triggering recovery exclusively at natural checkpoint eviction or during a measured terminal reserve before the planning deadline—can improve the final complete solution available at the deadline beyond ordinary checkpoint resumption alone. To address the 10.49% overhead of previous un-filtered partial acceptance, we introduce an inexpensive optimistic gain filter ($U = \sum \max(w_i, 0)$) that proves the non-existence of strictly positive subsets in 14.3 nanoseconds.

In a controlled 192-run matched development pilot across 32 cells (2 maps, 2 scenarios, 50 and 100 agents, 1.0s and 5.0s budgets, 2 random seeds, and 6 policy variants) executed with cyclic Latin-square balanced rotation, all 192 final solutions were independently verified as collision-free. The cheap optimistic filter eliminated dependency graph construction on **98.83%** of interruptions. However, selective recovery policies achieved an exact tie with normal checkpoint resumption across 100% of cells (**0 wins / 32 ties / 0 losses**, mean $\Delta\text{SoC} = +0.00 \pm 0.00$). Frequent recovery evaluated on every interruption yielded **0 wins / 28 ties / 4 losses** (mean $\Delta\text{SoC} = +13.56 \pm 9.36$). Analysis reveals that under standard $K=2$ stores, resumed repairs drain checkpoints before capacity eviction occurs, while at the terminal deadline, suspended checkpoints almost exclusively carry non-improving prefixes ($U == 0$). Meanwhile, reserving 2.0 ms before the deadline empirically eliminated all deadline overshoots (0.0 $\mu$s vs 2,524.0 $\mu$s baseline max) with zero solution quality penalty. We conclude that while the cheap filter and terminal reserve provide sound overhead reduction and strict deadline discipline, selective recovery does not provide an additive solution quality improvement over checkpoint resumption alone; checkpoint resumption (`RESUMPTION_NO_PA`) should remain the default solver configuration.

---

## 1. Problem Formulation & Research Question

### 1.1 Multi-Agent Path Finding (MAPF) Formulation
Given a discrete grid graph $G = (V, E)$ and a set of $m$ agents $A = \{1, \dots, m\}$, each agent $i$ has a start vertex $s_i \in V$ and a goal vertex $g_i \in V$. Time is discretized into integer timesteps $t \in \{0, 1, \dots\}$. A route for agent $i$ is a sequence of vertices $P_i = \langle p_i(0), p_i(1), \dots, p_i(T_i) \rangle$ such that $p_i(0) = s_i$, $p_i(T_i) = g_i$, and for all $t < T_i$, $(p_i(t), p_i(t+1)) \in E$ (Manhattan move) or $p_i(t+1) = p_i(t)$ (wait step). For $t \ge T_i$, the agent remains parked at its goal: $p_i(t) = g_i$ (**persistent stay-at-goal physical occupancy**).

A complete solution $P = \{P_1, \dots, P_m\}$ is valid if and only if:
1. **No Vertex Collisions:** $\forall i \ne j, \forall t \ge 0: p_i(t) \ne p_j(t)$.
2. **No Edge Swaps:** $\forall i \ne j, \forall t \ge 0: (p_i(t) \ne p_j(t+1) \lor p_i(t+1) \ne p_j(t))$.

The optimization objective is the **Sum of Costs (SoC)**, defined as the sum of individual arrival times:
$$\text{SoC}(P) = \sum_{i=1}^m T_i, \quad T_i = \min \{ t \ge 0 \mid \forall t' \ge t, p_i(t') = g_i \}$$

### 1.2 The Research Question
In anytime MAPF-LNS under a fixed global wall-clock deadline $B$ and cooperative slice duration $\Delta$:
> **Can completed replacement routes from interrupted repair checkpoints improve the complete valid solution available at a fixed deadline, beyond ordinary checkpoint resumption alone, when recovery is attempted selectively and its entire computational cost is charged to the original planning budget?**

---

## 2. Related-Work Verification Matrix

The closest published and publicly available MAPF and anytime planning literature was audited to determine the precise boundaries of prior art:

| Source | Verified Citation & Venue | Scope & Method | Overlap with This Work | Critical Distinctions & Differences |
|---|---|---|---|---|
| **Likhachev et al. (2005)** | *Anytime Dynamic A\**: An Anytime, Replanning Algorithm. *Annals of Mathematics and AI*, 2005. | Single-agent anytime search updating $\epsilon$-suboptimality bounds over inconsistent states. | Anytime planning under bounded computation budgets. | Single-agent heuristic search; does not address multi-agent conflict graphs, LNS neighborhood repairs, or subset closure acceptance. |
| **Boyarski et al. (2019)** | Using Incremental Search for the Low Level of Conflict-Based Search. *SoCS 2019*. | Incremental search inside the low-level search nodes of CBS. | Reusing low-level search trees across search iterations. | Operates inside CBS low-level tree structures; does not handle LNS destroy/repair cycles, macro-prefix checkpointing, or dependency closures. |
| **Vedder & Biswas (2021)** | X\*: Anytime Multi-Agent Path Finding for Sparse Domains using Window-Based Iterative Repairs. *Artificial Intelligence*, 2021. | Window-based iterative repair of localized conflicts in sparse domains. | Anytime iterative route repair in MAPF. | Focuses on spatial window decomposition; does not support preemption checkpointing, resumption of interrupted neighborhoods, or selective subset extraction. |
| **Morag, Stern & Felner (2023)** | Adapting to Planning Failures in Lifelong Multi-Agent Path Finding. *SoCS 2023*. | Failure handling in lifelong MAPF when online replanning fails to find complete paths. | Recovery from planning failure under online constraints. | Focuses on agent prioritization and delay injection in lifelong execution; does not address partial recovery of interrupted anytime LNS repairs. |
| **Lim et al. (2024)** | Lazy Incremental Search for Efficient Replanning with Bounded Suboptimality Guarantees. *IJRR*, 2024. | Lazy heuristic updates and edge evaluation in incremental graphs. | Reducing replanning overhead via lazy evaluation. | Focuses on single-agent kinematic graph edges; does not formulate multi-agent dependency graphs or maximum-weight closures. |
| **Chen et al. (2024)** | Cooperative Parallel Large Neighborhood Search for Large-Scale Multi-Agent Path Finding. *IEEE TPDS*, 2024. | Asynchronous multi-worker parallel MAPF-LNS (CPLNS) with shared incumbent updates. | Anytime MAPF-LNS repair optimization. | Employs multi-threaded workers discarding interrupted repairs; does not investigate checkpoint resumption, preemption recovery, or cheap optimistic bounds. |
| **Chan et al. (2025)** | Operation Parallelism in Large Neighborhood Search for Anytime Multi-Agent Path Finding. *IEEE MRS*, 2025. | Pipelined concurrent destroy-repair iterations using GPU/multi-core parallelism. | Parallelizing MAPF-LNS operations. | Parallel pipelining of independent neighborhoods; interrupted repairs are dropped rather than saved or selectively recovered. |
| **Tan et al. (2025)** | Reevaluation of Large Neighborhood Search for MAPF: Findings and Opportunities. *SoCS 2025*. | Comprehensive empirical evaluation of neighborhood sizes, destroy heuristics, and baselines. | Empirical analysis of MAPF-LNS behavior. | Evaluates unconstrained MAPF-LNS; does not address wall-clock preemption, checkpoint storage, or partial route acceptance. |
| **Phan et al. (2026)** | Truncated Counterfactual Learning for Anytime Multi-Agent Path Finding. *AAAI 2026*. | Reinforcement learning with counterfactual baseline for neighborhood seed-agent selection. | Optimizing MAPF-LNS neighborhood selection. | Focuses on which agents to destroy; uses standard non-resumable sequential repairs without checkpoint resumption or partial acceptance. |

**Originality Demarcation:** Prior work provides either uninterrupted sequential LNS, parallel multi-threaded search, or single-agent incremental replanning. No existing published work investigates deadline-governed selective recovery of completed replacement route subsets from interrupted macro-prefix checkpoints under bounded stores.

---

## 3. Algorithm Architecture & Method

### 3.1 The Inexpensive Optimistic Gain Filter
Let an interrupted repair checkpoint contain $r_{\text{done}}$ completed replacement routes $\{Q_1, \dots, Q_{r_{\text{done}}}\}$ replacing old routes $\{P_1, \dots, P_{r_{\text{done}}}\}$. For each candidate $i$, we compute its individual arrival cost reduction:
$$w_i = c(P_i) - c(Q_i) = \text{arrival}(P_i) - \text{arrival}(Q_i)$$
The optimistic upper bound $U$ is defined as:
$$U = \sum_{i=1}^{r_{\text{done}}} \max(w_i, 0)$$

**Theorem (Inexpensive Optimistic Bound):**
*Under the additive Sum of Costs objective, for any eligible selected subset of replacement routes $S \subseteq \{1, \dots, r_{\text{done}}\}$, the net reduction in total solution cost is $\Delta\text{SoC}(S) = \sum_{i \in S} w_i$. Because $w_i \le \max(w_i, 0)$ for all $i$, we have $\Delta\text{SoC}(S) \le U$. Consequently, if $U = 0$, no subset $S$ can yield a strictly positive cost reduction ($\Delta\text{SoC}(S) \le 0$).*

*Proof:*
$$\Delta\text{SoC}(S) = \sum_{i \in S} w_i \le \sum_{i \in S} \max(w_i, 0) \le \sum_{i=1}^{r_{\text{done}}} \max(w_i, 0) = U$$
If $U = 0$, then $\max(w_i, 0) = 0$ for all $i \in \{1, \dots, r_{\text{done}}\}$, meaning $w_i \le 0$ for every candidate. Since every element is non-positive, any subset sum is non-positive. Thus, strictly improving subsets ($\Delta\text{SoC}(S) > 0$) cannot exist. $\blacksquare$

**Implementation:**
The filter is implemented in checked 64-bit integer arithmetic in [`computeOptimisticUpperBound`](file:///Users/disasgamage/Documents/GitHub/RouteBudgetLab/src/engine/rbl_partial_acceptance.cpp#L104-L125). If $U == 0$, evaluation aborts immediately, bypassing all $O(m^2 \cdot T)$ collision checks, dependency graph construction, and max-flow closure selection.

### 3.2 Selective Triggering Policies
1. **`RESUMPTION_NO_PA` (Baseline):** Standard macro-prefix resumption under $K=2$ FIFO store. Interrupted repairs remain suspended until resumed.
2. **`PA_EVERY_INTERRUPTION_FILTERED`:** Evaluates partial acceptance on every slice cutoff, using the cheap filter to bypass non-improving interruptions.
3. **`PA_EVICTION_ONLY`:** Normal resumption during execution. When a checkpoint is about to be evicted from the store ($K=2$), [`findEvictionVictimSlot()`](file:///Users/disasgamage/Documents/GitHub/RouteBudgetLab/src/engine/rbl_checkpoint.hpp#L150) identifies the victim, and [`attemptEvictionRecovery`](file:///Users/disasgamage/Documents/GitHub/RouteBudgetLab/src/engine/rbl_resumable_engine.cpp#L455) evaluates recovery before slot overwrite.
4. **`PA_TERMINAL_ONLY`:** Normal resumption until the monotonic clock reaches $T_{\text{deadline}} - R$ (where $R = 2.0\text{ ms}$). Normal search stops, and [`attemptTerminalRecovery`](file:///Users/disasgamage/Documents/GitHub/RouteBudgetLab/src/engine/rbl_resumable_engine.cpp#L495) evaluates eligible suspended checkpoints in descending gain order.
5. **`PA_EVICTION_AND_TERMINAL`:** Evaluates selective recovery at both natural eviction and terminal reserve.
6. **`TERMINAL_RESERVE_CONTROL`:** Control ablation that stops normal search at $T_{\text{deadline}} - 2.0\text{ ms}$ with zero recovery.

### 3.3 Transactional Commit & Safety Invariants
- **Version Checking:** Incumbent state publishes an integer version counter $v_{\text{inc}}$. Candidate evaluation records $v_{\text{source}}$. Commit succeeds only if $v_{\text{inc}} == v_{\text{source}}$.
- **Independent Full-Plan Validation:** Prior to updating incumbent paths, candidate mixtures are independently validated by `validateIncumbent` with $O(m \cdot T)$ discrete space-time occupancy checks.
- **Atomic State Update:** Incumbent paths, arrival costs, reservations, and agent version counters update in a single atomic transaction.

---

## 4. Empirical Evaluation & Findings

### 4.1 Experimental Protocol
- **Hardware:** Apple Silicon M3 (arm64, 8 GB RAM), macOS 26.3.
- **Compiler:** AppleClang 17.0.0 (`-O3 -DNDEBUG`).
- **Benchmark Instances:** 32 matched cells from the development partition:
  * Maps: `random-64-64-10`, `warehouse-10-20-10-2-2`.
  * Scenarios: Scenario 1 and Scenario 2.
  * Agent Scales: 50 agents and 100 agents.
  * Planning Budgets: 1.0 second and 5.0 seconds.
  * Random Seeds: Seed 0 and Seed 1.
- **Design:** 32 cells $\times$ 6 policies = **192 matched sequential runs**.
- **Rotation:** Cyclic Latin-square balanced rotation order per cell to eliminate thermal drift and cache biases.
- **Validation:** Every run verified independently by `rbl_validate` (**192 / 192 valid, 0 failures**).

### 4.2 Paired Statistical Comparison Against Resumption

| Policy Variant | Win / Tie / Loss | Win Rate | Mean ΔCost (All Pairs) | Mean ΔCost (Non-Ties) | Median ΔCost [IQR] | SEM | Sign Test $p$ | Wilcoxon $p$ | Clustered Inst ΔCost (16 Groups) | Mean Iter Diff |
|---|---|---|---|---|---|---|---|---|---|---|
| `PA_EVERY_INTERRUPTION_FILTERED` | **0W / 28T / 4L** | 0.0% | **+13.56** | +108.50 | 0.0 [0.0] | ±9.36 | 0.1250 | 1.0000 | +13.56 ±9.26 | -61.4 |
| `PA_EVICTION_ONLY` | **0W / 32T / 0L** | 0.0% | **+0.00** | N/A (32T) | 0.0 [0.0] | ±0.00 | 1.0000 | 1.0000 | +0.00 ±0.00 | -91.1 |
| `PA_TERMINAL_ONLY` | **0W / 32T / 0L** | 0.0% | **+0.00** | N/A (32T) | 0.0 [0.0] | ±0.00 | 1.0000 | 1.0000 | +0.00 ±0.00 | -112.4 |
| `PA_EVICTION_AND_TERMINAL` | **0W / 32T / 0L** | 0.0% | **+0.00** | N/A (32T) | 0.0 [0.0] | ±0.00 | 1.0000 | 1.0000 | +0.00 ±0.00 | -214.1 |
| `TERMINAL_RESERVE_CONTROL` | **0W / 32T / 0L** | 0.0% | **+0.00** | N/A (32T) | 0.0 [0.0] | ±0.00 | 1.0000 | 1.0000 | +0.00 ±0.00 | +1.3 |

*Notes:* Under SoC minimization, lower cost is better ($\Delta\text{Cost} = \text{Cost}_{\text{policy}} - \text{Cost}_{\text{resumption}}$; positive means policy performed worse than resumption). Clustered instance analysis groups runs by underlying problem condition $(Map, Scen, Agents, Budget)$, averaging across random seeds.

### 4.3 Opportunity Funnel & Filter Efficiency
- **Total Online Filter Invocations:** 162,396
- **Filter Skips ($U == 0$):** 160,496 (**98.83%** bypassed before dependency graph construction)
- **Non-Skipped Evaluated ($U > 0$):** 1,900 (**1.17%**)
- **Zero-Gain Evaluated Closures:** 1,724 (closures containing cycles, colliding with agents without replacements, or outweighed by negative dependencies)
- **Feasible Improving Closures Committed:** 176 (100% committed successfully)
- **Total Harvested SoC Gain:** 3,254 SoC across 176 commits
- **Natural Store Evictions Observed ($K=2$):** **0**
- **Terminal Checkpoints Examined ($T - 2.0\text{ ms}$):** **23** (22 skipped with $U == 0$, 1 non-skipped with zero gain; **0 commits**)

### 4.4 High-Resolution Timing Breakdown
- **Filter Inner Loop (`computeOptimisticUpperBound`):** **14.3 nanoseconds** average latency across 162,396 calls (bounded by the 41.7 ns Apple Silicon timer resolution).
- **Candidate Extraction & Kinematics Validation:** **2.70 microseconds** per interruption.
- **Combined Preparation Latency:** **2.71 microseconds**.
- **Overhead Impact:** In un-filtered partial acceptance, building dependency graphs and Dinic min-cut consumed ~62 $\mu$s per slice (10.49% of planning time). The cheap filter reduces per-interruption latency by ~95.6%. However, evaluating extraction across all 162,396 interruptions accumulated 0.438s of CPU time across 32 runs, displacing ~61 iterations.

### 4.5 Deadline Discipline & Overshoot Breakdown

| Budget | Metric | `RESUMPTION_NO_PA` | `PA_EVERY_FILTERED` | `PA_EVICTION_ONLY` | `PA_TERMINAL_ONLY` | `TERMINAL_RESERVE_CONTROL` |
|---|---|---|---|---|---|---|
| **1.0s** | Mean Solve Time | 0.9998 s | 0.9996 s | 0.9997 s | 0.9981 s | 0.9981 s |
| | Max Overshoot | 2,232.0 $\mu$s (2.23 ms) | 0.0 $\mu$s | 1,056.0 $\mu$s (1.06 ms) | **0.0 $\mu$s** | **0.0 $\mu$s** |
| | Overrunning Runs | **1 / 16 (6.2%)** | 0 / 16 (0.0%) | 1 / 16 (6.2%) | **0 / 16 (0.0%)** | **0 / 16 (0.0%)** |
| **5.0s** | Mean Solve Time | 4.9998 s | 4.9996 s | 4.9996 s | 4.9981 s | 4.9982 s |
| | Max Overshoot | 2,524.0 $\mu$s (2.52 ms) | 0.0 $\mu$s | 0.0 $\mu$s | **0.0 $\mu$s** | **0.0 $\mu$s** |
| | Overrunning Runs | **2 / 16 (12.5%)** | 0 / 16 (0.0%) | 0 / 16 (0.0%) | **0 / 16 (0.0%)** | **0 / 16 (0.0%)** |

- Reserving 2.0 ms before the planning deadline completely eliminated deadline overruns across 100% of runs in terminal-reserve policies (**0.0 $\mu$s overshoot**).
- Stopping normal search 2.0 ms early imposed **zero cost penalty** across all 32 paired cells (**0W / 32T / 0L**, mean $\Delta\text{SoC} = 0.00$).

---

## 5. Discussion & Scientific Decision

### 5.1 Why Selective Recovery Does Not Outperform Checkpoint Resumption
1. **Resumption Already Captures the Work:** When an interrupted repair carries an improving route prefix, macro-prefix checkpoint resumption preserves that prefix and completes the remaining neighborhood agents on the next slice. Once completed as a full repair, the entire improvement is committed without paying dependency closure overhead.
2. **Natural Eviction Absence:** Under $K=2$ store capacity, the resumption manager prioritizes resuming suspended checkpoints on the immediately following slice. Because suspended checkpoints are resumed before a 3rd repair is initiated, checkpoints are almost never naturally evicted.
3. **Terminal Sparsity:** At the terminal deadline, the 1–2 checkpoints suspended in the store almost invariably have $U == 0$ (95.7% of examined checkpoints had $U == 0$; none yielded feasible positive gain).
4. **Displaced Search Penalty:** Evaluating partial acceptance on every slice interruption, even with the 98.83% filter skip rate, incurs 2.70 $\mu$s of extraction overhead per call. Across tens of thousands of interruptions, this accumulated latency displaced ~61 search iterations, causing 4 warehouse instances under tight 1.0s budgets to miss an improving full repair.

### 5.2 Formal Decision
In accordance with Stopping Rule B and Rule C (Prompt Section 16):
> **Verdict: `OVERHEAD REDUCTION & SAFE TERMINAL DEADLINE COMPLIANCE ONLY; NOT BENEFICIAL AS A RECOVERY ACCELERATOR; RETAIN RESUMPTION AS DEFAULT`.**

- The cheap optimistic gain filter ($U = \sum \max(w_i, 0)$) and the 2.0 ms terminal reserve are verified engineering contributions that successfully reduce overhead and enforce strict deadline compliance.
- Selective recovery does not provide an additive solution quality improvement over checkpoint resumption alone. Ordinary checkpoint resumption (`RESUMPTION_NO_PA`) is retained as the default solver recommendation.

---

## 6. Exact Reproduction Commands

```bash
# 1. Build and verify all 10 CTest suites (Release mode)
cmake -B build/bench-release -DCMAKE_BUILD_TYPE=Release
cmake --build build/bench-release -j8
ctest --test-dir build/bench-release --output-on-failure

# 2. Build and verify all 10 CTest suites (AddressSanitizer + UndefinedBehaviorSanitizer)
cmake -B build/audit-asan -DCMAKE_BUILD_TYPE=Debug -DENABLE_SANITIZERS=ON
cmake --build build/audit-asan -j8
ctest --test-dir build/audit-asan --output-on-failure

# 3. Execute matched 192-run balanced sequential development pilot (~9.8 min)
python3 scripts/run_selective_recovery_pilot.py

# 4. Generate statistical analysis, paired Wilcoxon, sign test, and markdown summary
python3 scripts/analyze_selective_recovery.py
```
