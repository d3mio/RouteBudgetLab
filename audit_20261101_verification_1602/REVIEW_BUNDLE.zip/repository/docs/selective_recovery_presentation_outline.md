# RouteBudget Lab — Selective Recovery Presentation Outline

**Topic:** Constraint-Validated Resumption and Selective Recovery of Interrupted Repairs for Deadline-Aware MAPF  
**Presenter:** P. G. Disas Sethnada (IIT: 20231323, UoW: w2119964)  
**Target Duration:** 15 Minutes (10 Slides)  

---

## Slide 1: Title & Research Motivation
- **Title:** Deadline-Aware MAPF-LNS: Checkpoint Resumption vs. Selective Recovery of Interrupted Repairs
- **Problem:** Anytime Multi-Agent Path Finding (MAPF) under hard computation deadlines frequently interrupts Large Neighborhood Search (LNS) repairs mid-neighborhood.
- **Core Research Question:** *Can recovering completed replacement routes from interrupted repairs improve the final solution quality at a planning deadline beyond ordinary checkpoint resumption alone?*
- **Speaker Notes:**
  * Welcome everyone. Today I'm presenting our investigation into selective recovery for deadline-aware Multi-Agent Path Finding.
  * In real-time robotics and automated warehousing, path planning must return valid collision-free routes before hard computation deadlines expire.
  * When time slices cut off an LNS repair before all agents in a neighborhood finish routing, what should we do with the completed routes?

---

## Slide 2: The Baseline — Macro-Prefix Checkpoint Resumption
- **Macro-Prefix Checkpoints ($K \in \{0, 1, 2\}$):**
  * Preserves completed routes $P_{1..r_{\text{done}}}$ in a FIFO store.
  * Discards unfinished search frontiers to maintain clean value semantics (< 1.0 KB memory).
  * Resumes routing from agent $r_{\text{done}}$ on subsequent slices.
- **The Recovery Hypothesis:**
  * If completed replacement routes already yield lower arrival costs, can we commit them immediately instead of waiting for full resumption?
- **The Historical Hurdle:**
  * In prior work, un-filtered partial acceptance consumed **10.49%** of planning time building dependency graphs, resulting in a slight net loss against resumption ($0\text{W} / 42\text{T} / 6\text{L}$).
- **Speaker Notes:**
  * RouteBudget Lab previously developed macro-prefix checkpoint resumption.
  * However, when we previously tried to extract partial improvements on every interruption, building dependency graphs on 99.6% non-improving slices wasted 10.5% of our budget.
  * This raised our new research question: can we make recovery selective and filter out non-improving interruptions cheaply?

---

## Slide 3: The Method — Cheap Optimistic Bound & Selective Triggering
- **Cheap Optimistic Gain Filter:**
  $$w_i = c(P_i) - c(Q_i), \quad U = \sum_{i=1}^{r_{\text{done}}} \max(w_i, 0)$$
  * **Theorem:** Under the additive Sum of Costs objective, any subset has gain $\le U$. If $U == 0$, strictly positive gain is mathematically impossible!
  * Evaluated in **14.3 nanoseconds** using checked 64-bit integer arithmetic.
- **Selective Triggering Policies:**
  1. *Natural Eviction Recovery:* Evaluate only when a checkpoint is about to be evicted from the store ($K=2$).
  2. *Terminal Reserve Recovery:* Normal search stops at $T_{\text{deadline}} - 2.0\text{ ms}$; recovery evaluates eligible checkpoints before deadline.
- **Speaker Notes:**
  * We introduced an inexpensive optimistic upper-bound filter.
  * By summing only the positive arrival-time gains, if $U == 0$, no subset of routes can possibly improve the solution.
  * This allows us to abort in 14 nanoseconds before constructing expensive dependency graphs.
  * Furthermore, rather than evaluating on every slice, we test selective triggering at natural store evictions and during a 2.0 ms terminal reserve.

---

## Slide 4: Correctness & Verification Architecture
- **Requirements-to-Tests Matrix (22 Dedicated Categories):**
  * 100% passing across all 22 required test categories in `tests/selective_recovery_tests.cpp`.
  * Release Mode: Custom active assertion macros verified via intentional failure injection (`ctest` exit code 8).
  * Sanitizer Mode: AddressSanitizer + UndefinedBehaviorSanitizer running cleanly with zero diagnostics.
- **Core Invariants Verified:**
  * 100% collision-free solutions (vertex collisions, edge swaps, persistent stay-at-goal occupancy).
  * Strict transactional commit with cached incumbent version verification.
- **Speaker Notes:**
  * Scientific integrity demands rigorous verification before benchmarking.
  * We implemented an exhaustive 22-category test suite covering boundary cases, cyclic dependencies, missing replacements, extreme arithmetic overflow, and deadline aborts.
  * All tests pass 100% in both Release and AddressSanitizer/UBSan builds with zero diagnostics.

---

## Slide 5: Controlled Experimental Design (192 Matched Runs)
- **32 Matched Problem Cells:**
  * Maps: `random-64-64-10` (random obstacle grid), `warehouse-10-20-10-2-2` (narrow warehouse aisles).
  * Scenarios: Scenario 1 and Scenario 2.
  * Agent Scales: 50 agents and 100 agents.
  * Planning Budgets: 1.0 second and 5.0 seconds.
  * Random Seeds: Seed 0 and Seed 1.
- **Six Comparative Policy Variants:**
  1. `RESUMPTION_NO_PA` (Main Resumption Baseline)
  2. `PA_EVERY_INTERRUPTION_FILTERED` (Filtered recovery on every slice)
  3. `PA_EVICTION_ONLY` (Recovery on natural store eviction)
  4. `PA_TERMINAL_ONLY` (Recovery during 2.0 ms terminal reserve)
  5. `PA_EVICTION_AND_TERMINAL` (Both selective triggers)
  6. `TERMINAL_RESERVE_CONTROL` (Ablation: stop 2.0 ms early with no recovery)
- **Latin-Square Balanced Rotation:**
  * Sequential single-worker execution with cyclic rotation per cell to eliminate thermal drift and cache biases.
- **Speaker Notes:**
  * We evaluated the six policies across a strictly matched factorial design of 32 development cells, totaling 192 runs.
  * Every run executed sequentially with cyclic Latin-square rotation, and every output path was independently verified by our standalone collision checker.

---

## Slide 6: Results — Cheap Filter Efficiency
- **Filter Evaluation Accounting:**
  * Total online filter evaluations: **162,396**
  * Filter skips ($U == 0$): **160,496** (**98.83%** skip rate!)
  * Non-skipped evaluations passed to graph ($U > 0$): **1,900** (1.17%)
- **Timing Audit:**
  * Filter inner loop latency: **14.3 nanoseconds** per call.
  * Candidate extraction & validation: **2.70 microseconds** per interruption.
  * Overall per-interruption latency reduced by **~95.6%** (from ~62 $\mu$s down to 2.71 $\mu$s).
- **Speaker Notes:**
  * The cheap filter performed remarkably well.
  * In 98.83% of all interrupted repairs, the optimistic bound proved that no improvement was possible, bypassing dependency graphs in 14 nanoseconds.
  * However, our high-resolution timing audit revealed that extracting and validating candidate routes still took 2.7 microseconds per slice, accumulating 0.44 seconds of CPU time across 32 runs.

---

## Slide 7: Results — Paired Solution Quality at Deadline
- **Paired Comparisons vs `RESUMPTION_NO_PA` Baseline ($N = 32$ Cells):**
  * `PA_EVERY_INTERRUPTION_FILTERED`: **0W / 28T / 4L** (Mean $\Delta\text{SoC} = +13.56 \pm 9.36$, sign test $p = 0.1250$, Wilcoxon $p = 1.0000$).
  * `PA_EVICTION_ONLY`: **0W / 32T / 0L** (Mean $\Delta\text{SoC} = +0.00 \pm 0.00$, $p = 1.0000$).
  * `PA_TERMINAL_ONLY`: **0W / 32T / 0L** (Mean $\Delta\text{SoC} = +0.00 \pm 0.00$, $p = 1.0000$).
  * `PA_EVICTION_AND_TERMINAL`: **0W / 32T / 0L** (Mean $\Delta\text{SoC} = +0.00 \pm 0.00$, $p = 1.0000$).
  * `TERMINAL_RESERVE_CONTROL`: **0W / 32T / 0L** (Mean $\Delta\text{SoC} = +0.00 \pm 0.00$, $p = 1.0000$).
- **Clustered Instance Analysis (16 Independent Groups):**
  * Grouping by $(Map, Scen, Agents, Budget)$ confirms mean $\Delta\text{SoC} = +13.56 \pm 9.26$ for every-interruption recovery, and $+0.00 \pm 0.00$ for all selective policies.
- **Speaker Notes:**
  * Here are the headline paired findings.
  * Selective policies (`PA_EVICTION_ONLY`, `PA_TERMINAL_ONLY`, and `PA_EVICTION_AND_TERMINAL`) tied the resumption baseline on 100% of paired cells: 0 wins, 32 ties, 0 losses.
  * Evaluating on every slice resulted in 0 wins, 28 ties, and 4 losses.
  * In the 4 loss cells (dense warehouse with 100 agents under a tight 1.0s budget), the 61 displaced search iterations prevented the solver from finding an additional improving full repair.

---

## Slide 8: Results — The Opportunity Funnel Decoded
- **Why Did Selective Policies Tie Resumption Exactly?**
  1. *Natural Evictions Were Zero:* Under $K=2$ FIFO capacity, suspended checkpoints were almost immediately resumed on the next slice, draining the store before capacity eviction occurred (**0 natural evictions**).
  2. *Terminal Checkpoints Carried Zero Gain:* Across all terminal runs, only 23 checkpoints were found suspended at the 2.0 ms reserve. **22 of the 23 had $U == 0$**; the 1 non-skipped checkpoint had zero feasible net gain (**0 terminal commits**).
  3. *Resumption Already Captures the Value:* When an interrupted repair has a positive prefix, normal resumption simply finishes the remaining agents on the next slice and commits the entire neighborhood improvement cleanly!
- **Speaker Notes:**
  * Why did selective recovery tie resumption so consistently?
  * The opportunity funnel explains it completely.
  * In standard sequential LNS, checkpoints don't sit around waiting to be evicted—resumption immediately picks them back up.
  * And by the time the global deadline arrives, any checkpoint left in the store is almost guaranteed to be a non-improving slice ($U == 0$).
  * Normal resumption already harvests the useful work from interrupted repairs without paying any triggering overhead.

---

## Slide 9: Results — Monotonic Deadline Discipline
- **Deadline Overshoot Comparison:**
  * `RESUMPTION_NO_PA`: Max overshoot of **2,524.0 $\mu$s** (2.52 ms); 3 out of 32 runs overran deadline (up to 12.5% overrunning).
  * `PA_TERMINAL_ONLY` & `TERMINAL_RESERVE_CONTROL`: **0.0 $\mu$s overshoot across 100% of runs** (0 / 32 runs overran).
- **The Terminal Reserve Finding:**
  * Stopping search 2.0 ms early imposes **zero solution quality penalty** (mean $\Delta\text{SoC} = 0.00$ across 32 pairs; 15,243 vs 15,241 iterations).
  * Reserving safe headroom guarantees strict wall-clock deadline compliance on general-purpose hardware.
- **Speaker Notes:**
  * While selective recovery did not improve solution quality, the 2.0 ms terminal reserve yielded a major engineering benefit: hard deadline discipline.
  * Normal resumption overran deadlines by up to 2.5 milliseconds.
  * In contrast, all terminal-reserve policies achieved zero overshoots across 100% of runs, without sacrificing a single point of solution quality.

---

## Slide 10: Conclusion & Scientific Contribution
- **Final Decision:**
  * **`OVERHEAD REDUCTION & SAFE TERMINAL DEADLINE COMPLIANCE ONLY; NOT BENEFICIAL AS A RECOVERY ACCELERATOR; RETAIN RESUMPTION AS DEFAULT`**
- **Verified Contributions:**
  1. *Mathematical Gain Filter:* Inexpensive upper bound $U = \sum \max(w_i, 0)$ proves non-existence of improving subsets in 14.3 ns, skipping 98.83% of interruptions.
  2. *Monotonic Terminal Reserve:* 2.0 ms cutoff achieves strict 0.0 $\mu$s deadline compliance with zero solution quality degradation.
  3. *Definitive Negative Finding:* Rigorous empirical proof that in sequential MAPF-LNS ($k=8$), checkpoint resumption alone captures available improvement without recovery overhead.
- **Speaker Notes:**
  * In conclusion, RouteBudget Lab provides a definitive, evidence-backed answer to our research question.
  * Selective recovery of interrupted routes does not outperform checkpoint resumption alone, because resumption already captures that progress on subsequent slices.
  * Our verified contributions are the cheap 14-nanosecond optimistic gain filter, the monotonic terminal reserve for deadline discipline, and an honest, reproducible negative result that clarifies the design of anytime MAPF algorithms.
  * Thank you. I welcome your questions.
