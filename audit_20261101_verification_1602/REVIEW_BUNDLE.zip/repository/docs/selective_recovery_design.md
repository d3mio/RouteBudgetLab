# Selective Recovery of Interrupted Repairs: Algorithm Specification & Safety Architecture

**Date:** 2026-11-01  
**Working Title:** Constraint-Validated Resumption and Selective Recovery of Interrupted Repairs for Deadline-Aware Multi-Agent Path Finding  
**Target Branch:** `research/selective-recovery`  

---

## 1. System Model & Correctness Contract (Section 3)

### 1.1 Problem Formulation & Kinematics
- **Environment:** 4-connected grid graph $G = (V, E)$. Vertices represent traversable grid cells; edges represent transitions between adjacent cardinal neighbors.
- **Agents:** A set of $m$ agents $A = \{0, 1, \dots, m-1\}$, each with an assigned start location $s_i \in V$ and goal location $g_i \in V$.
- **Permitted Moves:** At each discrete timestep $t \to t+1$, an agent may move to an adjacent vertex $v \in \text{Adj}(u)$ or wait at its current vertex $u$. Diagonal movements and multi-cell jumps are strictly disallowed.
- **Collisions:**
  1. *Vertex Collision:* No two agents occupy the same vertex $v \in V$ at the same timestep $t$.
  2. *Edge-Swap Collision:* No two agents traverse the same edge in opposite directions across the same transition $(u \to v$ and $v \to u)$ from $t \to t+1$.
  3. *Stay-at-Goal Permanent Occupancy:* Once an agent reaches its destination $g_i$ at its arrival timestep $\tau_i$, it parks permanently at $g_i$. It remains a physical obstacle for all traversing agents at all subsequent timesteps $t \ge \tau_i$.
- **Authoritative Arrival Cost & Objective:**
  The authoritative arrival cost of agent trajectory $P_i$ is its arrival timestep at goal without counting terminal padding waits:
  $$c(P_i) = \max \{ t \mid P_i[t] \ne g_i \} + 1 \quad (\text{or } 0 \text{ if } s_i = g_i)$$
  The global objective is minimizing the Sum of Costs across all agents:
  $$\text{SoC}(P) = \sum_{i=0}^{m-1} c(P_i)$$
- **Environment Scope:** In the supported benchmark experiment, maps, start locations, and goal locations are fixed for each problem instance. Trajectories are planned and repaired under a hard planning-computation deadline.

### 1.2 The Correctness Contract
1. **Incumbent Invariant:** The incumbent solution $P$ is always complete ($m$ paths), fully collision-free, kinematically valid, and strictly non-worsening.
2. **Strict Improvement on Commit:** Any committed recovery or resumption transaction must strictly decrease the authoritative Sum of Costs:
   $$\text{SoC}(P_{\text{new}}) < \text{SoC}(P_{\text{old}}) \iff \Delta \text{SoC} > 0$$
3. **Resumption vs Recovery Distinction:**
   - *Resuming an unfinished search frontier* requires restoring open lists, closed lists, reservation tables, and search heuristics. This is valid only when constraints have not changed since the checkpoint was saved.
   - *Selective recovery of completed replacement routes* treats completed paths $Q_i$ as candidate trajectory updates. Completed routes reaching their goals can be recovered even if the search frontier cannot be resumed, provided they are revalidated against the current incumbent.
4. **Independent Full-Plan Verification:** No candidate solution is ever accepted into the incumbent without passing whole-plan collision verification by the independent validator (`rbl_validate` / `validateCompletePlanIndependently`).

---

## 2. Cheap Optimistic Gain Filter (Section 5)

### 2.1 Theoretical Foundation
Let $R$ denote the set of agents with completed replacement routes $Q_i$ produced before interruption.
For each candidate $i \in R$, its authoritative cost against the current incumbent path $P_i$ is recomputed:
$$w_i = c(P_i) - c(Q_i)$$
The optimistic upper bound $U$ across all subsets $S \subseteq R$ is:
$$U = \sum_{i \in R} \max(w_i, 0)$$

**Theorem (Soundness of the Cheap Filter):**
Under an additive Sum of Costs objective, if $U = 0$, no non-empty subset $S \subseteq R$ can achieve strictly positive gain ($\Delta \text{SoC}(S) > 0$).

*Proof:*
For any subset $S \subseteq R$, the net cost reduction is:
$$\Delta \text{SoC}(S) = \sum_{i \in S} (c(P_i) - c(Q_i)) = \sum_{i \in S} w_i$$
Since $w_i \le \max(w_i, 0)$ for all $i$:
$$\sum_{i \in S} w_i \le \sum_{i \in S} \max(w_i, 0) \le \sum_{i \in R} \max(w_i, 0) = U$$
If $U = 0$, then $\sum_{i \in S} w_i \le 0$ for every subset $S \subseteq R$.
Because feasibility constraints (conflict avoidance, dependency closures) can only restrict the set of admissible subsets without increasing individual weights, restricting to feasible subsets cannot yield positive gain. Therefore, when $U = 0$, evaluating pairwise collisions, building dependency graphs, and solving min-cut or greedy selections cannot produce an improving subset. $\blacksquare$

### 2.2 Checked Arithmetic & Fail-Closed Safety
- Weight subtractions $c(P_i) - c(Q_i)$ and bound additions $\sum \max(w_i, 0)$ are computed using checked 64-bit signed integer arithmetic (`checkedSub`, `checkedAdd`).
- If integer overflow occurs, the filter fails closed by returning `INVALID_INPUT`; overflow can never produce a false zero.
- When $U > 0$, negative-gain candidates ($w_i < 0$) are strictly preserved because a positive candidate may depend on replacing a negative candidate to resolve a conflict.

---

## 3. Selective Triggering Policies (Section 7, 8, 9)

RouteBudget Lab defines five matched policy identifiers:

| Policy Identifier | Resumption | Recovery on Slice Interrupt | Eviction Recovery | Terminal Recovery |
|---|---|---|---|---|
| `RESUMPTION_NO_PA` | Yes ($K=2$, FIFO) | Disabled | Disabled | Disabled |
| `PA_EVERY_INTERRUPTION_FILTERED` | Yes ($K=2$, FIFO) | Evaluated with cheap filter | Disabled | Disabled |
| `PA_EVICTION_ONLY` | Yes ($K=2$, FIFO) | Disabled (normal save) | Attempted before victim overwrite | Disabled |
| `PA_TERMINAL_ONLY` | Yes ($K=2$, FIFO) | Disabled (normal save) | Disabled | Attempted during 2.0 ms reserve |
| `PA_EVICTION_AND_TERMINAL` | Yes ($K=2$, FIFO) | Disabled (normal save) | Attempted before victim overwrite | Attempted during 2.0 ms reserve |

### 3.1 Natural Eviction Recovery Lifecycle (Section 8)
When the bounded checkpoint store ($K=2$) is full and a newly interrupted slice requires storage:
1. `findEvictionVictimSlot()` identifies the oldest suspended checkpoint $V$ selected for replacement.
2. If $V$ has completed paths ($r_{\text{done}} \ge 1$), candidate routes are extracted.
3. Gains are recomputed against the *current* incumbent solution.
4. The cheap optimistic filter is applied. If $U = 0$, recovery is skipped in $< 0.1\,\mu\text{s}$.
5. If $U > 0$, dependency-aware selection and independent whole-plan validation execute.
6. If strictly improving, the candidate paths are committed atomically.
7. Checkpoint slot $V$ is overwritten by the new checkpoint, ensuring zero duplicate commits, zero memory leaks, and no recursive eviction loops.

### 3.2 Terminal Reserve Recovery Lifecycle (Section 9)
- Normal anytime LNS search stops when remaining planning time reaches the frozen safety cutoff ($t_{\text{reserve}} = 2.0\text{ ms}$).
- Suspended checkpoints in the store are examined in deterministic FIFO order (ascending `checkpoint_id`).
- For each checkpoint, gains and compatibility are recomputed against the latest incumbent (including changes made by prior terminal commits).
- If an improving subset is validated, it is committed atomically.
- Terminal-reserve control ablation (`TERMINAL_RESERVE_CONTROL`) stops normal search at the same 2.0 ms cutoff but performs no recovery, isolating the cost of stopping early.

---

## 4. Related-Work Verification Matrix (Section 14)

| Method / Paper | Interrupted Repair Resumption | Partial Route Acceptance | Cheap Gain Filter ($U$) | Eviction / Terminal Triggering | Planning Deadline Focus |
|---|---|---|---|---|---|
| **Likhachev et al. (2005)** — Anytime Dynamic A* | Incremental replanning for single agent | None (single agent) | None | None | Replanning efficiency |
| **Boyarski et al. (2019)** — Incremental Search in CBS | Low-level search tree reuse across conflicts | None (all-or-nothing low-level) | None | None | Search tree reuse |
| **Vedder & Biswas (2021)** — X* | Windowed iterative repairs | None (window replanning) | None | None | Sparse domain replanning |
| **Morag et al. (2023)** — Failure Adaptation in Lifelong MAPF | Failure-triggered rerouting | None (complete replan of failed agents) | None | None | Lifelong throughput |
| **Lim et al. (2024)** — Lazy Incremental Search | Incremental updates with suboptimality bounds | None (replan-or-restart) | None | None | Suboptimality bounds |
| **Chen et al. (2024)** — CPLNS | Parallel neighborhood repairs | None (neighborhood accepted or rolled back) | None | None | Core parallel speedup |
| **Chan et al. (2025)** — Operation Parallelism in LNS | Parallel neighborhood destruction/construction | None (all-or-nothing neighborhood commits) | None | None | Lock-free anytime speedup |
| **Tan et al. (2025)** — Reevaluation of MAPF-LNS | Standard LNS evaluation; identifies preemption waste | None (discards interrupted repairs) | None | None | Empirical baseline analysis |
| **Phan et al. (2026)** — Truncated Counterfactual Learning | Neighborhood seed selection via reinforcement learning | None (all-or-nothing repairs) | None | None | ML neighborhood selection |
| **RouteBudget Lab (This Work)** | **Macro-prefix state preservation & validation** | **Feasible subset recovery via closure/greedy** | **$O(\|R\|)$ bound check before collision analysis** | **Natural store eviction & terminal reserve** | **Strict monotonic planning deadline** |

---

## 5. Algorithmic Complexity

1. **Candidate Extraction & Kinematic Validation:**
   $$O(|R| \cdot L)$$
   where $|R| \le k$ (typically $k=8$) and $L$ is path makespan. (Measured: $\approx 1.2\,\mu\text{s}$).
2. **Cheap Optimistic Upper Bound Filter:**
   $$O(|R|)$$
   Checked arithmetic addition across $|R|$ weights. (Measured: $\approx 0.015\,\mu\text{s}$).
3. **Dependency Graph Construction (Only when $U > 0$):**
   $$O(|R| \cdot |A| \cdot L)$$
   where $|A| = m$ is the total agent fleet (50 or 100). (Measured: median $42\,\mu\text{s}$).
4. **Subset Selection:**
   - Greedy Selection: $O(|R|^2)$ (Measured: $< 2\,\mu\text{s}$).
   - Exact Min-Cut Closure: $O(|V|^2 |E|) = O(|R|^3)$ via Dinic's algorithm (Measured: $< 5\,\mu\text{s}$).
5. **Independent Whole-Plan Validation:**
   $$O(m \cdot L)$$
   Spatio-temporal reservation simulation verifying vertex, edge, and goal collisions. (Measured: $\approx 85\,\mu\text{s}$).
