# RouteBudget Lab — Record of AI Assistance and Reused Sources

**Project:** RouteBudget Lab  
**Author:** P. G. Disas Sethnada (IIT: 20231323, UoW: w2119964)  
**Date:** 2026-11-01  
**Scope:** Transparent disclosure of all artificial intelligence assistance, third-party libraries, benchmarks, and external sources used throughout the engineering and empirical evaluation of RouteBudget Lab.

---

## 1. Declaration of AI Assistance

In strict compliance with academic integrity guidelines and Section 17 (Item 10) of the project specification, this record accurately describes the substantial role of AI assistance in RouteBudget Lab. AI assistance was **not** limited to high-level brainstorming; it actively participated across code implementation, test development, statistical analysis, debugging, and technical documentation:

### 1.1 Architecture & Code Implementation
- **C++ Resumable Engine & Partial Acceptance:**
  - AI assisted in designing and implementing the `computeOptimisticUpperBound` 64-bit checked arithmetic filter in `src/engine/rbl_partial_acceptance.cpp`.
  - AI assisted in implementing the bounded checkpoint store eviction hook (`attemptEvictionRecovery`) and terminal reserve recovery hook (`attemptTerminalRecovery`) in `src/engine/rbl_resumable_engine.cpp`.
  - AI assisted in extending the command-line profiler (`src/profiler/profile_partial_acceptance.cpp`) to support the 5 matched selective policies and terminal-reserve control.

### 1.2 Automated Test Engineering
- **Section 11 / 12 Correctness Suites:**
  - AI assisted in authoring the 22-category automated test suite in `tests/selective_recovery_tests.cpp`.
  - AI implemented the test assertion macros (`ASSERT_EQ`, `ASSERT_TRUE`, `ASSERT_FALSE`) that remain active under `-O3 -DNDEBUG`, and verified them via intentional failure injection.
  - AI developed edge-case tests including cyclic dependencies, duplicate agent rejection, 64-bit arithmetic overflow detection, and deadline boundary cutoffs.

### 1.3 Experimental Scripts & Statistical Analysis
- **Automation & Statistical Pipelines:**
  - AI authored the cyclic Latin-square balanced benchmark runner `scripts/run_selective_recovery_pilot.py`.
  - AI authored the statistical analysis script `scripts/analyze_selective_recovery.py`, implementing exact two-sided binomial sign tests, Wilcoxon signed-rank tests, clustered instance aggregation, high-resolution timing breakdowns, and opportunity funnel accounting.

### 1.4 Technical Documentation & Review
- AI assisted in drafting, reviewing, and auditing the technical reports, correction ledger (`docs/correction_ledger.md`), requirements-to-tests matrix (`docs/requirements_to_tests_matrix.md`), decisions log (`docs/decisions.md`), and research log (`docs/research-log.md`).
- All empirical claims, numerical tables, and statistical results were programmatically generated from actual C++ execution outputs and raw JSON telemetry files on the author's local machine.

---

## 2. Reused Third-Party Libraries & Software Backbones

| Component | Pinned Version / Commit | License | Description & Modifications |
|---|---|---|---|
| **`thomyphan/anytime-mapf` (BALANCE)** | Pinned commit `47bb25e9ba58b22172e1531cb26f25af8a4531e9` | USC Research License (`third_party/anytime-mapf/license.txt`) | Core MAPF-LNS solver backbone, including Prioritized Planning, Space-Time A*, and SIPP single-agent solvers. Vendored in `third_party/anytime-mapf/` and verified byte-exact via `scripts/verify_upstream.sh` (SHA-256 manifest `UPSTREAM_FILES.sha256`). Modifications are isolated to RouteBudget Lab engine wrappers. |
| **Eigen 3** | Pinned version 3.4.0 | Mozilla Public License 2.0 (MPL2) | Linear algebra library vendored header-only in `third_party/anytime-mapf/inc/Eigen/` to support feature vector operations without external package manager dependencies. |
| **Boost C++ Libraries** | Version 1.92.0 | Boost Software License 1.0 | Provides `boost::program_options` for CLI flag parsing and `boost::filesystem` for platform-independent path manipulation. |
| **NumPy & SciPy** | Python 3 standard scientific packages | BSD Licenses | Used in offline statistical analysis scripts (`scipy.stats.wilcoxon`, exact binomial combinations). |

---

## 3. Benchmarks & Datasets

- **Moving AI Benchmark Repository:**
  - Standard 2D grid maps and benchmark scenarios downloaded from the official Moving AI MAPF benchmark collection (Stern et al., 2019).
  - Evaluated benchmark instances:
    * `data/training/maps/random-32-32-20.map`
    * `data/validation/maps/random-64-64-10.map`
    * `data/validation/maps/warehouse-10-20-10-2-2.map`
  - All maps, scenarios, and agent coordinates verified obstacle-free and bounds-compliant by `scripts/verify_datasets.py`.
