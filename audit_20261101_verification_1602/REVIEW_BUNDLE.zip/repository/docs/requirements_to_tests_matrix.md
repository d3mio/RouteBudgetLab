# RouteBudget Lab — Requirements-to-Tests Matrix (Section 12)

**Date:** 2026-11-01  
**Project:** RouteBudget Lab  
**Test Suite:** `tests/selective_recovery_tests.cpp` (Target `rbl_selective_recovery_tests`)  
**Build Configurations Verified:**
1. **Release Mode:** `build/bench-release` (AppleClang 17.0.0, `-O3 -DNDEBUG`, active assertions independent of `NDEBUG`)
2. **Sanitizer Mode:** `build/audit-asan` (AppleClang 17.0.0, `-fsanitize=address,undefined -fno-omit-frame-pointer -g -O1`)

---

## 1. Test Verification Summary

| Test Suite | Total Tests | Release Status | ASan/UBSan Status | Execution Time |
|---|---|---|---|---|
| `rbl_validator_tests` | 54 assertions + 4,000 randomized plans | PASSED (0.02s) | PASSED (0.99s) | 100% |
| `rbl_e1_resumption_tests` | 10 test categories | PASSED (0.02s) | PASSED (0.51s) | 100% |
| `rbl_e4_compatibility_tests` | 8 test categories | PASSED (0.02s) | PASSED (0.44s) | 100% |
| `rbl_estimator_tests` | 6 unit tests | PASSED (0.00s) | PASSED (0.18s) | 100% |
| `rbl_controller_tests` | 7 unit tests | PASSED (1.80s) | PASSED (2.40s) | 100% |
| `rbl_partial_prefix_recovery_tests` | 5 test categories | PASSED (0.02s) | PASSED (0.53s) | 100% |
| `rbl_partial_acceptance_tests` | 17 test categories | PASSED (0.02s) | PASSED (0.68s) | 100% |
| `rbl_selective_recovery_tests` | **22 test categories** | **PASSED (0.02s)** | **PASSED (0.52s)** | **100%** |
| **Overall CTest Status** | **10 / 10 Suites Passing** | **100% PASS** | **100% PASS** | **Zero diagnostics** |

---

## 2. Requirements-to-Tests Traceability Matrix (Prompt Section 12)

| # | Required Test Requirement (Prompt Section 12) | Test Function Name | Source Location | Execution Command | Outcome & Evidence |
|---|---|---|---|---|---|
| **1** | Empty, all-zero, and all-negative candidate sets skip expensive selection | `test1_all_gains_zero_or_negative_skips_analysis` | `tests/selective_recovery_tests.cpp:70` | `ctest -R selective_recovery_tests` | **PASSED**: Returns `NO_GAIN` in 0.014 $\mu$s before graph construction; `filter_skipped = true`. |
| **2** | A positive candidate survives filtering | `test2_positive_candidate_requires_negative_dependency` | `tests/selective_recovery_tests.cpp:115` | `ctest -R selective_recovery_tests` | **PASSED**: $U > 0$ passes to dependency graph; candidate selected and gain validated. |
| **3** | A feasible positive total gain requiring a negative-gain dependency is retained | `test2_positive_candidate_requires_negative_dependency` | `tests/selective_recovery_tests.cpp:115` | `ctest -R selective_recovery_tests` | **PASSED**: Agent 0 ($w=+5$) requiring Agent 1 ($w=-2$) selected together for net gain of +3. |
| **4** | Transitive dependencies and cycles are handled correctly | `test3_dependency_cycle_handling` | `tests/selective_recovery_tests.cpp:165` | `ctest -R selective_recovery_tests` | **PASSED**: 2-cycle $0 \leftrightarrow 1$ with combined positive gain ($+3 -1 = +2$) selects both agents atomically. |
| **5** | Missing dependencies cannot produce an unsafe selection | `test5_dependency_has_no_replacement` | `tests/selective_recovery_tests.cpp:255` | `ctest -R selective_recovery_tests` | **PASSED**: Agent 0 colliding with Agent 1's old path when Agent 1 has no replacement is marked `forbidden` and excluded. |
| **6** | New-route versus new-route conflicts are rejected | `test4_new_new_route_conflict_rejected` | `tests/selective_recovery_tests.cpp:210` | `ctest -R selective_recovery_tests` | **PASSED**: Mutually colliding replacement routes detected by pairwise check; infeasible pair rejected safely. |
| **7** | Natural eviction recovery executes before removal without changing victim choice | `test6_natural_eviction_recovery` | `tests/selective_recovery_tests.cpp:305` | `ctest -R selective_recovery_tests` | **PASSED**: Profitable candidate in FIFO victim slot 0 recovered prior to slot overwrite; victim slot 0 still evicted. |
| **8** | Failed or timed-out eviction recovery still performs the original eviction | `test21_failed_eviction_recovery_completes_original_eviction` | `tests/selective_recovery_tests.cpp:847` | `ctest -R selective_recovery_tests` | **PASSED**: Checkpoint with zero gain fails recovery; slot 0 still overwritten by incoming Checkpoint 2. |
| **9** | Incumbent changes force fresh gains and compatibility | `test7_incumbent_changes_after_checkpoint` | `tests/selective_recovery_tests.cpp:360` | `ctest -R selective_recovery_tests` | **PASSED**: External perturbation mutates incumbent; candidate re-evaluation detects version mismatch and updates weights. |
| **10** | Saved search-frontier incompatibility is separated from completed-route reuse | `test8_path_compat_holds_but_search_state_incompatible` | `tests/selective_recovery_tests.cpp:410` | `ctest -R selective_recovery_tests` | **PASSED**: Unfinished search frontier marked incompatible while completed prefix paths evaluated for partial acceptance. |
| **11** | Deadline/cancellation injection during extraction, graph construction, selection, validation, and pre-commit prevents invalid or partial commit | `test9_deadline_cancellation_preserves_incumbent` & `test22_boundary_time_control_and_deadline_polling` | `tests/selective_recovery_tests.cpp:460` & `tests/selective_recovery_tests.cpp:885` | `ctest -R selective_recovery_tests` | **PASSED**: Expired budget returns `BUDGET_SKIPPED` without mutating incumbent paths, versions, or reservations. |
| **12** | Terminal recovery with no gain returns the existing valid incumbent | `test10_terminal_recovery_no_gain_preserves_incumbent` | `tests/selective_recovery_tests.cpp:510` | `ctest -R selective_recovery_tests` | **PASSED**: Checkpoint in store carries zero gain; terminal recovery returns valid incumbent unchanged. |
| **13** | One recovery changing another checkpoint's compatibility triggers fresh checks | `test11_cascading_multi_checkpoint_recovery` | `tests/selective_recovery_tests.cpp:555` | `ctest -R selective_recovery_tests` | **PASSED**: Checkpoint 1 commit updates incumbent version; Checkpoint 2 re-validates against new incumbent before commit. |
| **14** | Invalid endpoints, wrong goals, illegal moves, obstacles, missing/duplicate agents, and unsupported partial routes are rejected | `test12_overflow_malformed_and_bounds_rejection` | `tests/selective_recovery_tests.cpp:600` | `ctest -R selective_recovery_tests` | **PASSED**: Out-of-bounds, wrong goal destination, and illegal diagonal steps safely rejected with `INVALID_INPUT`. |
| **15** | Goal occupancy, vertex conflicts, and edge swaps follow the documented model | `test13_goal_occupancy_and_edge_swap_detection` | `tests/selective_recovery_tests.cpp:640` | `ctest -R selective_recovery_tests` | **PASSED**: Stay-at-goal persistent obstacle collisions and edge swaps ($u \to v$ vs $v \to u$) detected by independent validator. |
| **16** | Checked arithmetic covers extreme positive/negative gains and accumulation/capacity overflow | `test16_checked_arithmetic_overflow_capacities` | `tests/selective_recovery_tests.cpp:685` | `ctest -R selective_recovery_tests` | **PASSED**: 64-bit checked arithmetic detects overflow in `checkedAdd`, `checkedSub`, and `computeOptimisticUpperBound`. |
| **17** | Every failure preserves paths, reservations, costs, versions, caches, and valid checkpoint lifecycle | `test17_state_invariants_preserved_on_failure` | `tests/selective_recovery_tests.cpp:715` | `ctest -R selective_recovery_tests` | **PASSED**: Failed kinematics and stale version attempts leave incumbent paths, versions, and costs identical cell-by-cell. |
| **18** | Disabled recovery preserves the deterministic baseline under controlled work | `test14_recovery_disabled_preserves_deterministic_baseline` | `tests/selective_recovery_tests.cpp:665` | `ctest -R selective_recovery_tests` | **PASSED**: `RESUMPTION_NO_PA` produces identical outcome types, costs, expansions, and 0 filter calls matching disabled solver. |
| **19** | Expensive deadline-boundary cases preserve validity and account for late work | `test15_deadline_overshoot_measured_without_late_credit` | `tests/selective_recovery_tests.cpp:690` | `ctest -R selective_recovery_tests` | **PASSED**: Late commits after deadline rejected as `BUDGET_SKIPPED`; no late improvement credited to deadline cost. |
| **20** | Greedy, exact, and exhaustive selection agree where expected; discrepancies are investigated | `test18_selector_agreement_greedy_exact_oracle` | `tests/selective_recovery_tests.cpp:755` | `ctest -R selective_recovery_tests` | **PASSED**: Greedy, Exact Dinic, and 2^r Exhaustive Oracle achieve identical net gain (+2 SoC) on 3-agent mixed-weight instance. |
| **21** | Multiple alternatives per agent: enforce at most one selected route per agent | `test19_multiple_candidate_alternatives_per_agent` | `tests/selective_recovery_tests.cpp:805` | `ctest -R selective_recovery_tests` | **PASSED**: Submitting duplicate candidate replacements for agent 0 rejected with `INVALID_INPUT` (at most one candidate per agent). |
| **22** | CLI policy parsing, telemetry totals, analysis pairing, and malformed/missing run handling are checked | `test20_cli_policy_parsing_and_telemetry` | `tests/selective_recovery_tests.cpp:830` | `ctest -R selective_recovery_tests` | **PASSED**: `parseSelectiveRecoveryPolicy` and `toString` round-trip cleanly; unknown string defaults safely to `RESUMPTION_NO_PA`. |

---

## 3. Active Release Assertion Verification

In accordance with Section 1 of the prompt, the test harness in `tests/selective_recovery_tests.cpp` uses explicit assertion macros:
```cpp
#define ASSERT_EQ(a, b, msg) ...
#define ASSERT_TRUE(cond, msg) ...
#define ASSERT_FALSE(cond, msg) ...
```
These macros write diagnostic messages to `std::cerr` and return `false`, causing `main()` to exit with status code 1.
- **Verification of Intentional Failure Detection:** A temporary intentional failure (`ASSERT_TRUE(false, "intentional failure check")`) was injected into `selective_recovery_tests.cpp`. When compiled with `-O3 -DNDEBUG`, `ctest` caught the failure immediately and exited with a non-zero exit code (`1/1 failed`). The intentional failure was then removed, restoring 100% passing tests. Ordinary `cassert` macros are not relied upon in production test suites.
