# Supervisor Decision Brief: RouteBudget Lab & Partial-Prefix Recovery Investigation

**Student:** P. G. Disas Sethnada (IIT ID: 20231323, UoW ID: w2119964)  
**Module:** 6SENG010C Software Engineering Final Year Project  
**Date:** October 2026  
**Document Purpose:** Academic status briefing and strategic decision roadmap for project completion  

---

## 1. Approved Research Problem & Intended Contribution

As formulated in the approved Final Year Project Proposal (`RouteBudget_Lab_PP_Formative_Report_Final_DisasGamage_20231323:w2119964.pdf`, Section 4.7), RouteBudget Lab addresses the challenge of **strict wall-clock deadline discipline in anytime Multi-Agent Path Finding via Large Neighborhood Search (MAPF-LNS)**.

Standard MAPF-LNS repair operators (e.g. monolithic CBS or prioritized planning) lack fine-grained checkpointing and budget awareness. When an anytime search deadline or iteration slice expires mid-repair, existing solvers either abort the repair (discarding all intermediate search expansions) or overrun the wall-clock deadline to complete the current neighborhood.

### Intended Project Contributions:
1. **Macro-Prefix Checkpointing:** Suspending low-level prioritized repairs at agent boundaries, saving routed sub-prefixes ($P_{0 \dots r_{done}-1}$) alongside search state.
2. **Conservative Constraint Validation:** Verifying suspended checkpoints against modified incumbents before resumption to prevent invalid plan commits.
3. **Adaptive Resume-or-Start Budget Controller:** Using lightweight search-progress features to predict repair viability and allocate search budgets dynamically under hard deadlines.

---

## 2. Summary of Implemented System (Phases 1–8)

The core RouteBudget Lab software platform is fully implemented, verified, and packaged:
- **Core Engine (C++17):** Resumable Space-Time $A^*$ and Prioritized Planning with deterministic cooperative interruption checks inside low-level node expansion loops (`rbl_resumable_engine.cpp`, `rbl_search_budget.hpp`).
- **Checkpoint Store & Validator:** Two-stage conservative constraint validator (`rbl_constraint_validator.hpp`) verifying vertex, edge-swap, stay-at-goal clearance, and neighborhood membership with microsecond-scale latency ($0.2 - 5.0\ \mu\text{s}$).
- **Feature Extractor & Estimator:** Online progress feature extractor ($15 - 30\ \mu\text{s}$) paired with an offline-trained Ridge regression progress estimator (`rbl_progress_estimator.hpp`).
- **Adaptive Controller:** Score-based resume-or-start controller with dynamic reserve margins ($t_{reserve} = 0.5$ ms) enforcing monotonic wall-clock accounting via `std::chrono::steady_clock` (`rbl_controller.hpp`).
- **Independent Validation & Tooling:** Multi-stage whole-plan validator (`rbl::checkPlan`) detecting invalid moves, collisions, and kinematic anomalies; offline 2D HTML5/JS replay viewer and packaging scripts.
- **Automated Verification:** 8 test suites (including resumption, compatibility, controller, and partial-prefix tests) passing with 100% CTest success.

---

## 3. Strongest Verified Findings from Original Evaluation (Phase 7: 768 Runs)

The primary empirical evaluation was executed across 768 sequential runs on Moving AI benchmarks, comparing 4 policies across 2 protocols, 2 maps, 3 scenarios, 2 agent scales (50, 100), 4 budgets (1s, 5s, 10s, 30s), and 2 seeds ($N=96$ paired conditions):

1. **Strict Wall-Clock Deadline Discipline (Protocol B):**
   - Published uninstrumented baseline (BALANCE) violated wall-clock deadlines on **79.2% of runs**, with overruns up to **5.65 ms** (mean overshoot 224.79 $\mu$s).
   - RouteBudget Lab (`RBL_END_TO_END`) achieved **0.00 $\mu$s mean overshoot** (100.0% deadline compliance within $\le 1.0\ \mu$s tolerance).
2. **Resumption vs Restart Trade-offs (Protocol A):**
   - Across all 96 conditions, FIFO resumption achieved an average cost improvement of **+13.36 points** over restart-only LNS.
   - However, Leave-One-Map-Out (LOMO) sensitivity revealed that this gain was concentrated heavily on a single map (`ost003d`, +71.46 points). When `ost003d` is excluded, the mean difference drops to **-6.00 points**.
   - Clustered bootstrap resampling at the map level ($B = 5,000$) yields a 95% confidence interval spanning zero: `[-9.30, +52.15]`.
3. **Plateauing Yield of Adaptive Resumption:**
   - In unconstrained MAPF-LNS, repair acceptance rates are low (~1.5%). Checkpoints frequently reach stagnation age before discovering lower-cost global incumbents than fresh repairs, resulting in tied plateau costs between selective compatibility and discard-on-change in 86 of 96 conditions.
   - Adaptive slicing and feature-based adaptation yielded negligible differences (-16.97 and -2.49 points).
4. **Academic Characterization:** The original evaluation establishes a defensible, rigorous engineering characterization of deadline discipline and LNS repair dynamics, *not* a generalized cost-reduction breakthrough over unconstrained search.

---

## 4. Partial-Prefix Recovery: Added Scope and Evidence Limitations

Investigated on branch `research/partial-prefix-recovery` as an extension to salvage sub-prefixes when external incumbent updates collide with intermediate agents ($P_k$).

### What the Extension Adds:
- **Theoretical Scope:** Formulates the **Retained-Prefix Validity Proposition** under 7 explicit assumptions (map identity, start/goal invariance, neighborhood identity, internal/external non-collision, edge-swap freedom, persistent goal occupancy). Demonstrates with an explicit 2D grid counterexample that feasible retained paths are not guaranteed to remain optimal.
- **Mechanistic Diagnostic:** In controlled 5-agent neighborhood tests ($m=5, r_{done}=4$) on `random-32-32-20` and `warehouse-10-20-10-2-1`, Policy C cleanly salvages collision-free sub-prefixes. Within each matched condition, it reduces resumption expansions compared to full discard (e.g. 432 vs 466 in Condition 3; 389 vs 455 in Condition 4 on random).
- **Independent Validation:** All legal candidate repairs pass independent whole-plan collision checks (`rbl::checkPlan`) with microsecond-scale validation overhead ($0.2 - 5.0\ \mu\text{s}$).

### Evidence Limitations:
- **Zero Natural Benchmark Occurrences:** In 72 unconstrained sequential solver runs ($N=24$ paired conditions), the natural occurrence rate of partial recoveries was **exactly 0**.
- **Combinatorial Root Cause:** In single-threaded sequential LNS, small neighborhoods ($|\mathcal{N}| \le 8$) and low acceptance rates mean external incumbent updates rarely intersect the middle of a suspended neighborhood while leaving earlier agents intact.
- **Empirical Utility Unexercised:** The extension provides no measured performance advantage over whole-checkpoint selective validation in standard sequential MAPF-LNS.

---

## 5. Unresolved Reporting & Verification Limitations

To maintain full transparency, the following limitations are documented:
1. **Prior Data Exposure:** During Phase 5 estimator fitting, Scenario 1 on both benchmark maps was used for offline trace collection. Scenarios 1 represent development/validation data, while Scenarios 2 and 3 represent previously unexposed validation splits. All 72 runs are reported as validation evidence.
2. **Synthetic Fault Injections in Diagnostic:** In Conditions 2 and 3 of the mechanism diagnostic, external conflicts were generated via single-timestep coordinate mutations because legal multi-agent Space-Time paths could not be found without extensive rerouting. These cases stress-test prefix collision detection, but produce invalid test incumbents rejected by final plan verification.
3. **No Demonstrated Async/Dynamic Workload:** The conceptual setting where partial recovery would be most valuable—parallel asynchronous MAPF-LNS or dynamic online MAPF—is not implemented in this repository.

---

## 6. Two Clearly Distinguished Strategic Directions

### Direction A: Complete the Final Year Project Around the Existing Evaluated System (Recommended)
- **Scope:** Freeze implementation and benchmarks. Focus all remaining effort on the final dissertation (10,000–12,000 words), software documentation, and project defense.
- **Core Narrative:**
  - RouteBudget Lab successfully solves the problem of strict wall-clock deadline discipline in anytime MAPF-LNS (100% compliance vs 79.2% violations in BALANCE).
  - Thorough empirical evaluation (768 reference runs) reveals the plateauing yield of repair resumption in sequential LNS, documented with clustered bootstrap statistics and LOMO sensitivity.
  - Partial-prefix recovery is presented as a supporting architectural diagnostic and theoretical characterization, with honest reporting of its 0-occurrence rate in sequential LNS.
- **Feasibility & Risk:** Low risk, fully aligned with project deadlines, backed by completed software, verified datasets, and reproducible replays.

### Direction B: Pursue Additional Publication-Oriented Research Under a New Agreed Scope (Alternative)
- **Scope:** Extend the research toward an external conference or workshop paper by evaluating a domain where partial recovery is hypothesized to be active.
- **Required New Work:**
  - Design and implement an Asynchronous Multi-Threaded MAPF-LNS architecture (multiple worker threads proposing repairs concurrently against a shared incumbent), or an Online Dynamic MAPF simulation with high-frequency external obstacle streams.
  - Formulate a new, pre-registered hypothesis and freeze evaluation conditions before inspecting outcomes.
  - Run extensive new benchmark campaigns and conduct multi-thread concurrency audits.
- **Feasibility & Risk:** High risk, substantial implementation scope, significant danger of derailing FYP submission deadlines.

---

## 7. Recommendation

**Recommendation: Adopt Direction A.**

The software development, verification, and empirical evaluation phases of RouteBudget Lab are complete. The project possesses a complete, clean-building C++17 codebase, 768 independently validated benchmark records, an interactive replay viewer, and an honest, methodologically rigorous body of evidence.

In academic computer science, thoroughly characterizing an engineering mechanism—including showing where it succeeds (deadline discipline, controlled sub-prefix salvage) and honestly documenting where it is inactive (sequential LNS plateauing, zero natural partial recoveries)—is the hallmark of rigorous research.

Pursuing Direction B introduces substantial scope creep and concurrency complexity that threatens final submission deadlines. Direction A allows the student to deliver a high-quality dissertation grounded in verified facts, complete requirements traceability, and transparent scientific honesty.

*(Note: In accordance with academic guidelines, this brief does not guarantee a specific degree classification, rubric grade, or publication outcome.)*
