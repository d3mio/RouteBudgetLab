# RouteBudget Lab — Reproducibility Checklist

**Date:** 2026-11-01  
**Project:** RouteBudget Lab  
**Evaluation:** Phase 11 — Selective Recovery of Interrupted Repairs  
**Host Environment:** Apple Silicon M3 (arm64, 8 GB RAM), macOS 26.3, AppleClang 17.0.0, CMake 3.31.6, Boost 1.92  

---

## Reproducibility Verification Checklist

### 1. Codebase & Toolchain Integrity
- [x] **No External Network Dependencies:** Upstream solver backbone (`third_party/anytime-mapf`) and Eigen 3.4.0 are vendored and verified by SHA-256 manifests.
- [x] **Compiler Compliance:** Compiles cleanly under AppleClang 17.0.0 with `-std=c++17` in both Release and Debug sanitizer modes.
- [x] **Active Test Assertions:** Test assertions (`ASSERT_EQ`, `ASSERT_TRUE`, `ASSERT_FALSE`) remain active under `-O3 -DNDEBUG`; verified via intentional failure injection.

### 2. Automated Test Suites (10/10 CTest Targets)
- [x] **Validator Unit Tests (`rbl_validator_tests`):** 54 assertions + 4,000 randomized plans passing 100%.
- [x] **Real Solver Output Validation (`real_solver_output_is_valid`):** Pinned baseline cost 1147 verified.
- [x] **Coordinate Convention Checks (`real_solver_output_misread_as_xy_is_rejected`):** Rejects inverted coordinates.
- [x] **Experiment E1 Resumption Tests (`rbl_e1_tests`):** 10 categories passing 100%.
- [x] **Experiment E4 Constraint Compatibility Tests (`rbl_e4_tests`):** 8 categories passing 100%.
- [x] **Remaining-Work Estimator Tests (`rbl_estimator_tests`):** 6 tests passing 100%.
- [x] **Controller Tests (`rbl_controller_tests`):** 7 tests passing 100%.
- [x] **Partial-Prefix Recovery Tests (`rbl_partial_recovery_tests`):** 5 categories passing 100%.
- [x] **Maximum-Gain Partial Acceptance Tests (`rbl_partial_acceptance_tests`):** 17 categories passing 100%.
- [x] **Selective Recovery Tests (`rbl_selective_recovery_tests`):** **22 categories passing 100%**.
- [x] **Sanitizer Verification:** All 10 test suites pass with 0 diagnostics under AddressSanitizer and UndefinedBehaviorSanitizer (`build/audit-asan`).

### 3. Matched Development Pilot (192 Runs Across 32 Cells)
- [x] **Deterministic Factorial Design:** 2 Maps × 2 Scenarios × 2 Agent Counts (50, 100) × 2 Budgets (1.0s, 5.0s) × 2 Seeds (0, 1) × 6 Policies = 192 runs.
- [x] **Balanced Order Schedule:** Cyclic Latin-square rotation per cell stored in run configuration.
- [x] **Sequential Single-Worker Execution:** Zero multi-threading or process contention during benchmark collection.
- [x] **Independent Collision Checking:** 192/192 runs (100.0%) verified collision-free by standalone `rbl_validate`.
- [x] **Cryptographic Manifest:** Every trajectory and raw JSON output tracked in `results/2026-11-01_selective_recovery/manifest.sha256`.

### 4. Paired Statistical Analysis
- [x] **Authoritative Sum of Costs:** Recomputed directly from trajectory arrival times.
- [x] **Non-Zero P-Value Reporting:** Exact two-sided binomial sign test and Wilcoxon signed-rank test computed with scipy and exact binomial formulas.
- [x] **Clustered Instance-Level Aggregation:** Evaluated across the 16 unique underlying instance groups, averaging over random seeds.
- [x] **High-Resolution Timing Audit:** Scalar filter loop latency (14.3 ns) rigorously separated from candidate extraction and kinematics validation (2.70 $\mu$s).
- [x] **Per-Budget Breakdown:** 1.0s and 5.0s solve times and overshoots reported separately with 90th/99th percentiles.

### 5. Documentation & Historical Preservation
- [x] **Preserved Baselines:** Phase 7 768-run dataset, 43,166 offline snapshots, and historical 192-run pilot remain completely untouched.
- [x] **Correction Ledger (`docs/correction_ledger.md`):** Itemized audit and correction of previously reported narrative claims.
- [x] **Requirements-to-Tests Matrix (`docs/requirements_to_tests_matrix.md`):** 22-category mapping with source locations, commands, and outcomes.
- [x] **Technical Report (`docs/selective_recovery_technical_report.md`):** Formal academic report with prior-art matrix and empirical conclusions.
- [x] **Presentation Outline (`docs/selective_recovery_presentation_outline.md`):** 10-slide outline with speaker notes using verified figures.
- [x] **AI Assistance Record (`docs/ai_assistance_and_sources.md`):** Transparent declaration of AI contributions.
- [x] **Implementation Status & Decisions:** `IMPLEMENTATION_STATUS.md`, `docs/decisions.md` (D16), and `docs/research-log.md` updated.
